"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ShoppingCart, Plus, Minus, Trash2, Clock, MapPin, CreditCard, Banknote, Smartphone } from "lucide-react"

interface Product {
  id: string
  name: string
  description: string
  price: number
  image: string
}

interface Category {
  id: string
  name: string
  icon: string
  products: Product[]
}

interface CartItem {
  product: Product
  quantity: number
}

interface Message {
  id: string
  type: "bot" | "user"
  content: string
  timestamp: Date
  data?: any
}

const menuData: Category[] = [
  {
    id: "burgers",
    name: "Hambúrguers",
    icon: "🍔",
    products: [
      {
        id: "classic-burger",
        name: "Hambúrguer Clássico",
        description: "Pão, carne 180g, queijo, alface, tomate, cebola",
        price: 25.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "bacon-burger",
        name: "Bacon Burger",
        description: "Pão, carne 180g, bacon, queijo, alface, tomate",
        price: 29.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "veggie-burger",
        name: "Veggie Burger",
        description: "Pão integral, hambúrguer de grão-de-bico, queijo vegano",
        price: 27.9,
        image: "/placeholder.svg?height=100&width=100",
      },
    ],
  },
  {
    id: "pizzas",
    name: "Pizzas",
    icon: "🍕",
    products: [
      {
        id: "margherita",
        name: "Pizza Margherita",
        description: "Molho de tomate, mussarela, manjericão, azeite",
        price: 32.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "pepperoni",
        name: "Pizza Pepperoni",
        description: "Molho de tomate, mussarela, pepperoni",
        price: 36.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "quattro-formaggi",
        name: "Quattro Formaggi",
        description: "Mussarela, gorgonzola, parmesão, provolone",
        price: 38.9,
        image: "/placeholder.svg?height=100&width=100",
      },
    ],
  },
  {
    id: "drinks",
    name: "Bebidas",
    icon: "🥤",
    products: [
      {
        id: "coca-cola",
        name: "Coca-Cola 350ml",
        description: "Refrigerante de cola gelado",
        price: 5.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "orange-juice",
        name: "Suco de Laranja",
        description: "Suco natural de laranja 300ml",
        price: 8.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "water",
        name: "Água Mineral",
        description: "Água mineral sem gás 500ml",
        price: 3.9,
        image: "/placeholder.svg?height=100&width=100",
      },
    ],
  },
  {
    id: "desserts",
    name: "Sobremesas",
    icon: "🍰",
    products: [
      {
        id: "chocolate-cake",
        name: "Bolo de Chocolate",
        description: "Fatia de bolo de chocolate com cobertura",
        price: 12.9,
        image: "/placeholder.svg?height=100&width=100",
      },
      {
        id: "ice-cream",
        name: "Sorvete 2 Bolas",
        description: "Escolha 2 sabores: chocolate, baunilha, morango",
        price: 9.9,
        image: "/placeholder.svg?height=100&width=100",
      },
    ],
  },
]

const paymentMethods = [
  { id: "credit", name: "Cartão de Crédito", icon: CreditCard },
  { id: "debit", name: "Cartão de Débito", icon: CreditCard },
  { id: "pix", name: "PIX", icon: Smartphone },
  { id: "cash", name: "Dinheiro", icon: Banknote },
]

const deliveryMethods = [
  {
    id: "delivery",
    name: "Entrega",
    description: "Entregamos em sua casa",
    time: "30-45 min",
    price: 5.0,
    icon: MapPin,
  },
  { id: "pickup", name: "Retirada", description: "Retire no balcão", time: "15-20 min", price: 0, icon: Clock },
]

export default function RestaurantChatbot() {
  const [messages, setMessages] = useState<Message[]>([])
  const [cart, setCart] = useState<CartItem[]>([])
  const [currentStep, setCurrentStep] = useState<
    "menu" | "category" | "product" | "cart" | "payment" | "delivery" | "confirmation"
  >("menu")
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null)
  const [selectedPayment, setSelectedPayment] = useState<string>("")
  const [selectedDelivery, setSelectedDelivery] = useState<string>("")
  const [customerInfo, setCustomerInfo] = useState({ name: "", phone: "", address: "" })
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Mensagem inicial
    addBotMessage(
      "Olá! Bem-vindo ao nosso restaurante! 🍽️\n\nEu sou seu assistente virtual e vou te ajudar a fazer seu pedido. Vamos começar?",
    )
    showMainMenu()
  }, [])

  const addBotMessage = (content: string, data?: any) => {
    const message: Message = {
      id: Date.now().toString(),
      type: "bot",
      content,
      timestamp: new Date(),
      data,
    }
    setMessages((prev) => [...prev, message])
  }

  const addUserMessage = (content: string) => {
    const message: Message = {
      id: Date.now().toString(),
      type: "user",
      content,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, message])
  }

  const showMainMenu = () => {
    setCurrentStep("menu")
    addBotMessage("Aqui está nosso menu principal. Escolha uma categoria:", {
      type: "categories",
      categories: menuData,
    })
  }

  const showCategory = (category: Category) => {
    setSelectedCategory(category)
    setCurrentStep("category")
    addUserMessage(`Ver ${category.name}`)
    addBotMessage(`Ótima escolha! Aqui estão nossos ${category.name.toLowerCase()}:`, {
      type: "products",
      products: category.products,
    })
  }

  const addToCart = (product: Product) => {
    addUserMessage(`Adicionar ${product.name}`)
    setCart((prev) => {
      const existingItem = prev.find((item) => item.product.id === product.id)
      if (existingItem) {
        return prev.map((item) => (item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [...prev, { product, quantity: 1 }]
    })
    addBotMessage(`${product.name} adicionado ao carrinho! 🛒\n\nDeseja continuar comprando ou finalizar o pedido?`, {
      type: "continue-shopping",
    })
  }

  const updateCartQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity === 0) {
      setCart((prev) => prev.filter((item) => item.product.id !== productId))
    } else {
      setCart((prev) => prev.map((item) => (item.product.id === productId ? { ...item, quantity: newQuantity } : item)))
    }
  }

  const showCart = () => {
    setCurrentStep("cart")
    addUserMessage("Ver carrinho")
    if (cart.length === 0) {
      addBotMessage("Seu carrinho está vazio. Que tal escolher alguns produtos deliciosos?")
      showMainMenu()
    } else {
      addBotMessage("Aqui está seu carrinho:", { type: "cart", items: cart })
    }
  }

  const proceedToPayment = () => {
    setCurrentStep("payment")
    addUserMessage("Finalizar pedido")
    addBotMessage("Perfeito! Agora escolha a forma de pagamento:", { type: "payment", methods: paymentMethods })
  }

  const selectPayment = (paymentId: string) => {
    setSelectedPayment(paymentId)
    setCurrentStep("delivery")
    const payment = paymentMethods.find((p) => p.id === paymentId)
    addUserMessage(`Pagamento: ${payment?.name}`)
    addBotMessage("Ótimo! Agora escolha como deseja receber seu pedido:", {
      type: "delivery",
      methods: deliveryMethods,
    })
  }

  const selectDelivery = (deliveryId: string) => {
    setSelectedDelivery(deliveryId)
    setCurrentStep("confirmation")
    const delivery = deliveryMethods.find((d) => d.id === deliveryId)
    addUserMessage(`${delivery?.name}`)

    const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
    const deliveryFee = delivery?.price || 0
    const finalTotal = total + deliveryFee

    addBotMessage("Resumo do seu pedido:", {
      type: "confirmation",
      cart,
      payment: selectedPayment,
      delivery: selectedDelivery,
      total: finalTotal,
      deliveryFee,
    })
  }

  const confirmOrder = () => {
    addUserMessage("Confirmar pedido")
    addBotMessage(
      "🎉 Pedido confirmado com sucesso!\n\nSeu pedido foi enviado para a cozinha. Você receberá atualizações sobre o status da preparação.\n\nObrigado por escolher nosso restaurante!",
    )

    // Reset do sistema
    setTimeout(() => {
      setCart([])
      setSelectedPayment("")
      setSelectedDelivery("")
      setCurrentStep("menu")
      addBotMessage("Gostaria de fazer um novo pedido?")
      showMainMenu()
    }, 3000)
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.product.price * item.quantity, 0)
  }

  const renderMessageContent = (message: Message) => {
    if (!message.data) return message.content

    switch (message.data.type) {
      case "categories":
        return (
          <div className="space-y-3">
            <p>{message.content}</p>
            <div className="grid grid-cols-2 gap-2">
              {message.data.categories.map((category: Category) => (
                <Button
                  key={category.id}
                  variant="outline"
                  className="h-auto p-3 flex flex-col items-center gap-2 bg-transparent"
                  onClick={() => showCategory(category)}
                >
                  <span className="text-2xl">{category.icon}</span>
                  <span className="text-sm">{category.name}</span>
                </Button>
              ))}
            </div>
            {cart.length > 0 && (
              <Button onClick={showCart} className="w-full mt-3">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Ver Carrinho ({cart.length})
              </Button>
            )}
          </div>
        )

      case "products":
        return (
          <div className="space-y-3">
            <p>{message.content}</p>
            <div className="space-y-3">
              {message.data.products.map((product: Product) => (
                <Card key={product.id} className="p-3">
                  <div className="flex gap-3">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold">{product.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{product.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-green-600">R$ {product.price.toFixed(2)}</span>
                        <Button size="sm" onClick={() => addToCart(product)}>
                          <Plus className="w-4 h-4 mr-1" />
                          Adicionar
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={showMainMenu}>
                ← Voltar ao Menu
              </Button>
              {cart.length > 0 && (
                <Button onClick={showCart}>
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Carrinho ({cart.length})
                </Button>
              )}
            </div>
          </div>
        )

      case "continue-shopping":
        return (
          <div className="space-y-3">
            <p>{message.content}</p>
            <div className="flex gap-2">
              <Button variant="outline" onClick={showMainMenu}>
                Continuar Comprando
              </Button>
              <Button onClick={showCart}>
                <ShoppingCart className="w-4 h-4 mr-2" />
                Ver Carrinho ({cart.length})
              </Button>
            </div>
          </div>
        )

      case "cart":
        return (
          <div className="space-y-3">
            <p>{message.content}</p>
            <div className="space-y-3">
              {message.data.items.map((item: CartItem) => (
                <Card key={item.product.id} className="p-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.product.image || "/placeholder.svg"}
                      alt={item.product.name}
                      className="w-12 h-12 rounded object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm">{item.product.name}</h4>
                      <p className="text-green-600 font-bold">R$ {item.product.price.toFixed(2)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => updateCartQuantity(item.product.id, 0)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            <Separator />
            <div className="flex justify-between items-center font-bold text-lg">
              <span>Total:</span>
              <span className="text-green-600">R$ {getTotalPrice().toFixed(2)}</span>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={showMainMenu}>
                Continuar Comprando
              </Button>
              <Button onClick={proceedToPayment} className="flex-1">
                Finalizar Pedido
              </Button>
            </div>
          </div>
        )

      case "payment":
        return (
          <div className="space-y-3">
            <p>{message.content}</p>
            <div className="grid grid-cols-2 gap-2">
              {message.data.methods.map((method: any) => {
                const Icon = method.icon
                return (
                  <Button
                    key={method.id}
                    variant="outline"
                    className="h-auto p-3 flex flex-col items-center gap-2 bg-transparent"
                    onClick={() => selectPayment(method.id)}
                  >
                    <Icon className="w-6 h-6" />
                    <span className="text-sm">{method.name}</span>
                  </Button>
                )
              })}
            </div>
          </div>
        )

      case "delivery":
        return (
          <div className="space-y-3">
            <p>{message.content}</p>
            <div className="space-y-2">
              {message.data.methods.map((method: any) => {
                const Icon = method.icon
                return (
                  <Card key={method.id} className="p-3">
                    <Button
                      variant="ghost"
                      className="w-full h-auto p-0 flex items-center gap-3 justify-start"
                      onClick={() => selectDelivery(method.id)}
                    >
                      <Icon className="w-6 h-6" />
                      <div className="flex-1 text-left">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold">{method.name}</span>
                          {method.price > 0 && <Badge variant="secondary">+R$ {method.price.toFixed(2)}</Badge>}
                        </div>
                        <p className="text-sm text-gray-600">{method.description}</p>
                        <p className="text-sm text-blue-600">{method.time}</p>
                      </div>
                    </Button>
                  </Card>
                )
              })}
            </div>
          </div>
        )

      case "confirmation":
        const paymentMethod = paymentMethods.find((p) => p.id === message.data.payment)
        const deliveryMethod = deliveryMethods.find((d) => d.id === message.data.delivery)

        return (
          <div className="space-y-4">
            <p>{message.content}</p>

            <Card className="p-4">
              <h4 className="font-semibold mb-3">Itens do Pedido:</h4>
              {message.data.cart.map((item: CartItem) => (
                <div key={item.product.id} className="flex justify-between items-center py-1">
                  <span>
                    {item.quantity}x {item.product.name}
                  </span>
                  <span>R$ {(item.product.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}

              <Separator className="my-3" />

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>R$ {(message.data.total - message.data.deliveryFee).toFixed(2)}</span>
                </div>
                {message.data.deliveryFee > 0 && (
                  <div className="flex justify-between">
                    <span>Taxa de entrega:</span>
                    <span>R$ {message.data.deliveryFee.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-lg">
                  <span>Total:</span>
                  <span className="text-green-600">R$ {message.data.total.toFixed(2)}</span>
                </div>
              </div>

              <Separator className="my-3" />

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Pagamento:</span>
                  <span>{paymentMethod?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Entrega:</span>
                  <span>{deliveryMethod?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tempo estimado:</span>
                  <span>{deliveryMethod?.time}</span>
                </div>
              </div>
            </Card>

            <Button onClick={confirmOrder} className="w-full">
              Confirmar Pedido
            </Button>
          </div>
        )

      default:
        return message.content
    }
  }

  return (
    <div className="max-w-md mx-auto h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b p-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
          <span className="text-white font-bold">🍽️</span>
        </div>
        <div>
          <h1 className="font-bold">Restaurante Bot</h1>
          <p className="text-sm text-gray-600">Sempre online</p>
        </div>
        {cart.length > 0 && (
          <div className="ml-auto">
            <Button size="sm" variant="outline" onClick={showCart}>
              <ShoppingCart className="w-4 h-4 mr-1" />
              {cart.length}
            </Button>
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.type === "user" ? "bg-blue-500 text-white" : "bg-white border shadow-sm"
              }`}
            >
              <div className="whitespace-pre-wrap">{renderMessageContent(message)}</div>
              <div className={`text-xs mt-1 ${message.type === "user" ? "text-blue-100" : "text-gray-500"}`}>
                {message.timestamp.toLocaleTimeString("pt-BR", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      <div className="bg-white border-t p-4">
        <div className="flex gap-2 flex-wrap">
          <Button size="sm" variant="outline" onClick={showMainMenu}>
            🏠 Menu Principal
          </Button>
          {cart.length > 0 && (
            <Button size="sm" variant="outline" onClick={showCart}>
              🛒 Carrinho ({cart.length})
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
