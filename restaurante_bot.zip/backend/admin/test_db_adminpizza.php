<?php
require_once 'includes/header.php';

$establishment_id = 2; // ID do admin pizza

// Buscar categorias
$categories_stmt = $db->prepare("SELECT * FROM categories WHERE establishment_id = :establishment_id ORDER BY sort_order ASC");
$categories_stmt->bindParam(':establishment_id', $establishment_id);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar produtos
$products_stmt = $db->prepare("SELECT * FROM products WHERE establishment_id = :establishment_id ORDER BY name ASC");
$products_stmt->bindParam(':establishment_id', $establishment_id);
$products_stmt->execute();
$products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="p-3">
    <h4>Categorias do Estabelecimento #<?= $establishment_id ?></h4>
    <table class="table table-bordered table-sm">
        <thead><tr><th>ID</th><th>Nome</th><th>Ícone</th><th>Ativo</th></tr></thead>
        <tbody>
        <?php foreach ($categories as $cat): ?>
            <tr>
                <td><?= $cat['id'] ?></td>
                <td><?= htmlspecialchars($cat['name']) ?></td>
                <td><?= htmlspecialchars($cat['icon']) ?></td>
                <td><?= $cat['active'] ? 'Sim' : 'Não' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <h4>Produtos do Estabelecimento #<?= $establishment_id ?></h4>
    <table class="table table-bordered table-sm">
        <thead><tr><th>ID</th><th>Nome</th><th>Categoria</th><th>Ativo</th></tr></thead>
        <tbody>
        <?php foreach ($products as $prod): ?>
            <tr>
                <td><?= $prod['id'] ?></td>
                <td><?= htmlspecialchars($prod['name']) ?></td>
                <td><?= $prod['category_id'] ?></td>
                <td><?= $prod['active'] ? 'Sim' : 'Não' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require_once 'includes/footer.php'; ?> 