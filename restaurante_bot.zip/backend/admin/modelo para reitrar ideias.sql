-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 18/07/2025 às 18:58
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `robot`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `estabelecimento_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `estabelecimento_id`) VALUES
(1, 'Almoço', 1),
(2, 'Jantar', 1),
(3, 'Lanche', 1),
(4, 'Bebida', 1),
(5, 'Produtos em Destaque', 2),
(6, 'Promoções', 2),
(7, 'Mais Vendidos', 2),
(8, 'Produtos em Destaque', 3),
(9, 'Promoções', 3),
(10, 'Mais Vendidos', 3),
(11, 'Produtos em Destaque', 4),
(12, 'Promoções', 4),
(13, 'Mais Vendidos', 4),
(14, 'Produtos em Destaque', 5),
(15, 'Promoções', 5),
(16, 'Mais Vendidos', 5),
(17, 'Produtos em Destaque', 6),
(18, 'Promoções', 6),
(19, 'Mais Vendidos', 6);

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `data_nascimento` date DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `estabelecimento_id` int(11) DEFAULT NULL,
  `is_entregador` tinyint(1) DEFAULT 0,
  `is_funcionario` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `telefone`, `email`, `endereco`, `data_nascimento`, `observacoes`, `estabelecimento_id`, `is_entregador`, `is_funcionario`) VALUES
(3, 'osmano brito', '63992893682', 'osmanobr@hotmail.com', '605 norte', '2025-05-03', 'não', 1, 0, 0),
(4, 'Daniel', '63992465660', 'daniel@gmail.com', 'palmas', '0000-00-00', 'não', 1, 0, 0),
(5, 'Asmano Torres', '63991219187', 'asmano@gmail.com', 'rua gonçalves Ledo, 636 Centro Araguaina Tocantins', '0000-00-00', 'não', 1, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `entregadores`
--

CREATE TABLE `entregadores` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `modalidade` enum('MOTO','CARRO','BIKE','A PE','CAMINHAO') NOT NULL,
  `documento` varchar(50) DEFAULT NULL,
  `status` enum('ATIVO','INATIVO') DEFAULT 'ATIVO',
  `data_cadastro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `estabelecimento`
--

CREATE TABLE `estabelecimento` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `ramo_atividade` varchar(100) DEFAULT NULL,
  `foto_local` varchar(255) DEFAULT NULL,
  `info_adicional` text DEFAULT NULL,
  `chave_pix` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `estabelecimento`
--

INSERT INTO `estabelecimento` (`id`, `nome`, `telefone`, `email`, `endereco`, `ramo_atividade`, `foto_local`, `info_adicional`, `chave_pix`) VALUES
(1, 'Pizzaria Saborosa', '62999998888', 'contato@saborosa.com', 'Rua das Flores, 123, Centro', 'Pizzaria', 'https://exemplo.com/fotos/pizzaria.jpg', 'Aberto todos os dias das 18h às 23h. Ambiente familiar e aconchegante.', 'osmanobrito@gmail.com'),
(2, 'Interdados Informatica', '63991219187', 'interdados@gmail.com', 'av. neblina 888', 'Outro', 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 'Loja criada automaticamente pelo sistema.', NULL),
(3, 'Rensoftware', '6934281121', 'ren@gmail.com', 'avenida filadelphia', 'Outro', 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 'Loja criada automaticamente pelo sistema.', NULL),
(4, 'Antonio Cezar Voltolini', '63985001011', 'cezar@viatechinfo.com.br', '103 Norte Rua NO 7 s/n', 'Restaurante', 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 'Loja criada automaticamente pelo sistema.', NULL),
(5, 'TECHINFO', '63991296741', 'rodrigo@gmail.com', 'rua das flores 150', 'Outro', 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 'Loja criada automaticamente pelo sistema.', NULL),
(6, 'DENILSON ARTES', '63991919191', 'denilsonquir@gmail.com', 'RUA DAS CAMELIAS', 'Outro', 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=600&q=80', 'Loja criada automaticamente pelo sistema.', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `forma_pagamento`
--

CREATE TABLE `forma_pagamento` (
  `id` int(11) NOT NULL,
  `estabelecimento_id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `status` enum('ATIVA','INATIVA') DEFAULT 'ATIVA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `forma_pagamento`
--

INSERT INTO `forma_pagamento` (`id`, `estabelecimento_id`, `nome`, `status`) VALUES
(1, 1, 'Dinheiro', 'ATIVA'),
(2, 1, 'Cartão de Crédito', 'ATIVA'),
(3, 1, 'Cartão de Débito', 'ATIVA'),
(4, 1, 'Pix', 'ATIVA'),
(5, 3, 'Pix (celular): 6934281121', 'ATIVA'),
(6, 4, 'Pix (celular): 63985001011', 'ATIVA'),
(7, 5, 'Pix (celular): 63991296741', 'ATIVA'),
(8, 6, 'Pix (celular): 63991919191', 'ATIVA');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens`
--

CREATE TABLE `itens` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `descricao` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `itens`
--

INSERT INTO `itens` (`id`, `nome`, `preco`, `categoria_id`, `foto`, `video`, `descricao`) VALUES
(1, 'Pizza Margherita', 39.90, 1, 'https://exemplo.com/fotos/margherita.jpg', 'https://exemplo.com/videos/margherita.mp4', 'Clássica pizza italiana com molho de tomate, mussarela e manjericão fresco.'),
(2, 'Pizza Calabresa', 44.90, 1, 'https://exemplo.com/fotos/calabresa.jpg', 'https://exemplo.com/videos/calabresa.mp4', 'Pizza com calabresa fatiada, cebola e azeitonas pretas.'),
(3, 'Produtos em Destaque Produto 1', 12.90, 5, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(4, 'Produtos em Destaque Produto 2', 73.90, 5, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(5, 'Produtos em Destaque Produto 3', 41.90, 5, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(6, 'Promoções Produto 1', 84.90, 6, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(7, 'Promoções Produto 2', 12.90, 6, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(8, 'Promoções Produto 3', 83.90, 6, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(9, 'Mais Vendidos Produto 1', 52.90, 7, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(10, 'Mais Vendidos Produto 2', 55.90, 7, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(11, 'Mais Vendidos Produto 3', 84.90, 7, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(12, 'Produtos em Destaque Produto 1', 70.90, 8, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(13, 'Produtos em Destaque Produto 2', 52.90, 8, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(14, 'Produtos em Destaque Produto 3', 90.90, 8, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(15, 'Promoções Produto 1', 70.90, 9, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(16, 'Promoções Produto 2', 21.90, 9, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(17, 'Promoções Produto 3', 87.90, 9, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(18, 'Mais Vendidos Produto 1', 83.90, 10, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(19, 'Mais Vendidos Produto 2', 70.90, 10, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(20, 'Mais Vendidos Produto 3', 79.90, 10, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(21, 'Produtos em Destaque Produto 1', 81.90, 11, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(22, 'Produtos em Destaque Produto 2', 10.90, 11, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(23, 'Produtos em Destaque Produto 3', 49.90, 11, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(24, 'Promoções Produto 1', 54.90, 12, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(25, 'Promoções Produto 2', 23.90, 12, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(26, 'Promoções Produto 3', 59.90, 12, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(27, 'Mais Vendidos Produto 1', 64.90, 13, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(28, 'Mais Vendidos Produto 2', 51.90, 13, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(29, 'Mais Vendidos Produto 3', 34.90, 13, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(30, 'Produtos em Destaque Produto 1', 83.90, 14, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(31, 'Produtos em Destaque Produto 2', 81.90, 14, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(32, 'Produtos em Destaque Produto 3', 71.90, 14, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(33, 'Promoções Produto 1', 93.90, 15, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(34, 'Promoções Produto 2', 98.90, 15, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(35, 'Promoções Produto 3', 13.90, 15, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(36, 'Mais Vendidos Produto 1', 63.90, 16, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(37, 'Mais Vendidos Produto 2', 49.90, 16, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(38, 'Mais Vendidos Produto 3', 48.90, 16, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(39, 'Produtos em Destaque Produto 1', 46.90, 17, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(40, 'Produtos em Destaque Produto 2', 61.90, 17, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(41, 'Produtos em Destaque Produto 3', 92.90, 17, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(42, 'Promoções Produto 1', 42.90, 18, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(43, 'Promoções Produto 2', 17.90, 18, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(44, 'Promoções Produto 3', 21.90, 18, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(45, 'Mais Vendidos Produto 1', 97.90, 19, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(46, 'Mais Vendidos Produto 2', 69.90, 19, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.'),
(47, 'Mais Vendidos Produto 3', 17.90, 19, 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=400&q=80', NULL, 'Produto fictício gerado automaticamente.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `remetente` enum('cliente','estabelecimento') NOT NULL,
  `mensagem` text NOT NULL,
  `data_envio` datetime DEFAULT current_timestamp(),
  `lida` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `data_pedido` datetime DEFAULT current_timestamp(),
  `tipo_entrega` enum('RETIRADA','ENTREGA') DEFAULT 'RETIRADA',
  `status` enum('PENDENTE','ACEITO','PREPARANDO','ENTREGANDO','ENTREGUE','CANCELADO','EXTRAVIADO') DEFAULT 'PENDENTE',
  `endereco_entrega` varchar(255) DEFAULT NULL,
  `estabelecimento_id` int(11) DEFAULT NULL,
  `forma_pagamento_id` int(11) DEFAULT NULL,
  `arquivo_comprovante` varchar(255) DEFAULT NULL,
  `data_pagamento` datetime DEFAULT NULL,
  `cancelado_por` enum('CLIENTE','ESTABELECIMENTO') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `cliente_id`, `data_pedido`, `tipo_entrega`, `status`, `endereco_entrega`, `estabelecimento_id`, `forma_pagamento_id`, `arquivo_comprovante`, `data_pagamento`, `cancelado_por`) VALUES
(2, 4, '2025-07-01 12:53:31', 'RETIRADA', 'ENTREGUE', '', 1, NULL, NULL, NULL, NULL),
(3, 3, '2025-07-01 13:03:09', 'RETIRADA', 'CANCELADO', '', 1, NULL, NULL, NULL, NULL),
(4, 3, '2025-07-01 13:05:48', 'RETIRADA', 'ENTREGUE', '', 1, NULL, NULL, NULL, NULL),
(5, 3, '2025-07-01 13:29:54', 'RETIRADA', 'CANCELADO', '', 1, NULL, NULL, NULL, NULL),
(6, 3, '2025-07-01 13:55:10', 'RETIRADA', 'CANCELADO', '', 1, NULL, NULL, NULL, NULL),
(7, 4, '2025-07-01 14:18:53', 'RETIRADA', 'CANCELADO', '', 1, NULL, NULL, NULL, NULL),
(8, 3, '2025-07-02 10:41:47', 'RETIRADA', 'CANCELADO', '', 1, 2, NULL, NULL, NULL),
(9, 3, '2025-07-02 13:46:20', 'RETIRADA', 'CANCELADO', '', 1, 4, NULL, NULL, NULL),
(10, 3, '2025-07-02 13:58:01', 'RETIRADA', 'CANCELADO', '', 1, 4, NULL, NULL, NULL),
(11, 3, '2025-07-02 13:59:58', 'RETIRADA', 'CANCELADO', '', 1, 4, NULL, NULL, NULL),
(12, 3, '2025-07-02 14:01:20', 'RETIRADA', 'ENTREGUE', '605 norte', 1, 1, NULL, NULL, NULL),
(13, 3, '2025-07-02 14:42:59', 'RETIRADA', 'CANCELADO', '', 1, 4, 'upload/comprovante_13_1751478211.webp', NULL, NULL),
(14, 3, '2025-07-02 14:50:43', 'RETIRADA', 'CANCELADO', '', 1, 4, 'upload/comprovante_14_1751479038.jfif', NULL, NULL),
(15, 3, '2025-07-02 15:45:29', 'RETIRADA', 'CANCELADO', '', 1, 4, 'upload/comprovante_15_1751482170.jfif', NULL, NULL),
(16, 3, '2025-07-03 13:28:34', 'RETIRADA', 'CANCELADO', '', 1, 4, NULL, NULL, NULL),
(17, 3, '2025-07-04 09:09:29', 'RETIRADA', 'CANCELADO', 'Rua Teste', 1, 1, NULL, NULL, NULL),
(18, 3, '2025-07-04 09:09:34', 'RETIRADA', 'CANCELADO', 'Rua Teste', 1, 1, NULL, NULL, NULL),
(19, 3, '2025-07-04 09:12:04', 'RETIRADA', 'CANCELADO', 'Rua Teste', 3, 1, NULL, NULL, NULL),
(20, 3, '2025-07-04 09:13:40', 'RETIRADA', 'CANCELADO', '', 3, 5, NULL, NULL, NULL),
(21, 3, '2025-07-04 10:00:00', 'RETIRADA', 'CANCELADO', '', 5, 7, NULL, NULL, NULL),
(22, 3, '2025-07-04 10:13:07', 'RETIRADA', 'CANCELADO', '', 1, 4, 'upload/comprovante_22_1751634822.PNG', NULL, NULL),
(23, 5, '2025-07-16 08:26:50', 'RETIRADA', 'PENDENTE', '', 1, 4, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedido_itens`
--

CREATE TABLE `pedido_itens` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `quantidade` int(11) DEFAULT 1,
  `preco_unitario` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `pedido_itens`
--

INSERT INTO `pedido_itens` (`id`, `pedido_id`, `item_id`, `quantidade`, `preco_unitario`) VALUES
(3, 2, 2, 1, 44.90),
(4, 3, 2, 1, 44.90),
(5, 4, 1, 1, 39.90),
(6, 5, 1, 1, 39.90),
(7, 6, 2, 1, 44.90),
(8, 7, 1, 1, 39.90),
(9, 8, 1, 1, 39.90),
(10, 9, 1, 1, 39.90),
(11, 9, 2, 1, 44.90),
(12, 10, 1, 1, 39.90),
(13, 11, 2, 1, 44.90),
(14, 12, 1, 1, 39.90),
(15, 13, 1, 1, 39.90),
(16, 14, 1, 1, 39.90),
(17, 15, 1, 1, 39.90),
(18, 16, 1, 1, 39.90),
(19, 20, 20, 1, 79.90),
(20, 21, 31, 1, 81.90),
(21, 22, 2, 1, 44.90),
(22, 23, 2, 1, 44.90);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vagas`
--

CREATE TABLE `vagas` (
  `id` int(11) NOT NULL,
  `estabelecimento_id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `tipo_vaga` varchar(50) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `quantidade` int(11) DEFAULT 1,
  `data_criacao` datetime DEFAULT current_timestamp(),
  `status` enum('ABERTA','FECHADA') DEFAULT 'ABERTA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `vagas_interessados`
--

CREATE TABLE `vagas_interessados` (
  `id` int(11) NOT NULL,
  `vaga_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `data_interesse` datetime DEFAULT current_timestamp(),
  `mensagem` text DEFAULT NULL,
  `contratado` tinyint(1) DEFAULT 0,
  `data_contratacao` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `estabelecimento_id` (`estabelecimento_id`);

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `telefone` (`telefone`),
  ADD KEY `estabelecimento_id` (`estabelecimento_id`);

--
-- Índices de tabela `entregadores`
--
ALTER TABLE `entregadores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Índices de tabela `estabelecimento`
--
ALTER TABLE `estabelecimento`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `forma_pagamento`
--
ALTER TABLE `forma_pagamento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `estabelecimento_id` (`estabelecimento_id`);

--
-- Índices de tabela `itens`
--
ALTER TABLE `itens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Índices de tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `estabelecimento_id` (`estabelecimento_id`),
  ADD KEY `forma_pagamento_id` (`forma_pagamento_id`);

--
-- Índices de tabela `pedido_itens`
--
ALTER TABLE `pedido_itens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Índices de tabela `vagas`
--
ALTER TABLE `vagas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `estabelecimento_id` (`estabelecimento_id`);

--
-- Índices de tabela `vagas_interessados`
--
ALTER TABLE `vagas_interessados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vaga_id` (`vaga_id`),
  ADD KEY `cliente_id` (`cliente_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `entregadores`
--
ALTER TABLE `entregadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `estabelecimento`
--
ALTER TABLE `estabelecimento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `forma_pagamento`
--
ALTER TABLE `forma_pagamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `itens`
--
ALTER TABLE `itens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `pedido_itens`
--
ALTER TABLE `pedido_itens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `vagas`
--
ALTER TABLE `vagas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `vagas_interessados`
--
ALTER TABLE `vagas_interessados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `categorias`
--
ALTER TABLE `categorias`
  ADD CONSTRAINT `categorias_ibfk_1` FOREIGN KEY (`estabelecimento_id`) REFERENCES `estabelecimento` (`id`);

--
-- Restrições para tabelas `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`estabelecimento_id`) REFERENCES `estabelecimento` (`id`);

--
-- Restrições para tabelas `entregadores`
--
ALTER TABLE `entregadores`
  ADD CONSTRAINT `entregadores_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);

--
-- Restrições para tabelas `forma_pagamento`
--
ALTER TABLE `forma_pagamento`
  ADD CONSTRAINT `forma_pagamento_ibfk_1` FOREIGN KEY (`estabelecimento_id`) REFERENCES `estabelecimento` (`id`);

--
-- Restrições para tabelas `itens`
--
ALTER TABLE `itens`
  ADD CONSTRAINT `itens_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Restrições para tabelas `mensagens`
--
ALTER TABLE `mensagens`
  ADD CONSTRAINT `mensagens_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`);

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`estabelecimento_id`) REFERENCES `estabelecimento` (`id`),
  ADD CONSTRAINT `pedidos_ibfk_forma_pagamento` FOREIGN KEY (`forma_pagamento_id`) REFERENCES `forma_pagamento` (`id`);

--
-- Restrições para tabelas `pedido_itens`
--
ALTER TABLE `pedido_itens`
  ADD CONSTRAINT `pedido_itens_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`),
  ADD CONSTRAINT `pedido_itens_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `itens` (`id`);

--
-- Restrições para tabelas `vagas`
--
ALTER TABLE `vagas`
  ADD CONSTRAINT `vagas_ibfk_1` FOREIGN KEY (`estabelecimento_id`) REFERENCES `estabelecimento` (`id`);

--
-- Restrições para tabelas `vagas_interessados`
--
ALTER TABLE `vagas_interessados`
  ADD CONSTRAINT `vagas_interessados_ibfk_1` FOREIGN KEY (`vaga_id`) REFERENCES `vagas` (`id`),
  ADD CONSTRAINT `vagas_interessados_ibfk_2` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
