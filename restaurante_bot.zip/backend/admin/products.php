<?php
include_once 'includes/header.php';

// Lógica para obter produtos
$database = new Database();
$db = $database->getConnection();
$establishmentManager = new EstablishmentManager($database);

$establishment_id = $admin_establishment_id;

// Obter categorias para o dropdown de filtro/adição
$categories_query = "SELECT id, name FROM categories WHERE establishment_id = :establishment_id ORDER BY name ASC";
$categories_stmt = $db->prepare($categories_query);
$categories_stmt->bindParam(':establishment_id', $establishment_id);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);

// Filtro por categoria (mas só se a categoria pertencer ao estabelecimento do admin)
$category_id = null;
if (isset($_GET['category_id']) && ctype_digit($_GET['category_id'])) {
    foreach ($categories as $cat) {
        if ($cat['id'] == $_GET['category_id']) {
            $category_id = $cat['id'];
            break;
        }
    }
}

if ($category_id) {
    $products_query = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.establishment_id = :establishment_id AND p.category_id = :category_id ORDER BY p.name ASC";
    $products_stmt = $db->prepare($products_query);
    $products_stmt->bindParam(':establishment_id', $establishment_id);
    $products_stmt->bindParam(':category_id', $category_id);
    $products_stmt->execute();
    $products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $products_query = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.establishment_id = :establishment_id ORDER BY p.name ASC";
    $products_stmt = $db->prepare($products_query);
    $products_stmt->bindParam(':establishment_id', $establishment_id);
    $products_stmt->execute();
    $products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);
}

$uploadBaseUrl = getUploadBaseUrl(); // Obter a URL base para exibir imagens

?>

<div class="p-3 p-md-4">
  <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
      <h5 class="fw-semibold text-dark mb-0">Produtos</h5>
      <button id="addProductBtn" class="btn btn-outline-secondary d-flex align-items-center gap-2 py-2 px-2 mb-0">
          <i class="bi bi-plus-lg fs-5"></i>
          <span class="d-none d-sm-inline">Adicionar</span>
      </button>
  </div>
        <!-- Tabela de Produtos -->
        <div class="overflow-x-auto bg-white rounded-lg shadow-md p-3 mb-4">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                    <thead>
                        <tr class="bg-gray-100 text-left text-gray-600 uppercase text-sm leading-normal">
                            <th class="py-3 px-6 border-b border-gray-200">ID</th>
                            <th class="py-3 px-6 border-b border-gray-200">Imagem</th>
                            <th class="py-3 px-6 border-b border-gray-200">Nome</th>
                            <th class="py-3 px-6 border-b border-gray-200">Categoria</th>
                            <th class="py-3 px-6 border-b border-gray-200">Preço</th>
                            <th class="py-3 px-6 border-b border-gray-200">Ativo</th>
                            <th class="py-3 px-6 border-b border-gray-200">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700 text-sm">
                        <?php if (empty($products)): ?>
                            <tr>
                                <td colspan="7" class="py-3 px-6 text-center border-b border-gray-200">Nenhum produto encontrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="py-3 px-6 border-b border-gray-200"><?php echo htmlspecialchars($product['id']); ?></td>
                                    <td class="py-3 px-6 border-b border-gray-200">
                                        <?php if (!empty($product['image'])): ?>
                                            <img src="<?php echo htmlspecialchars($uploadBaseUrl . $product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="w-16 h-16 object-cover rounded-md">
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-6 border-b border-gray-200"><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td class="py-3 px-6 border-b border-gray-200"><?php echo htmlspecialchars($product['category_name']); ?></td>
                                    <td class="py-3 px-6 border-b border-gray-200">R$ <?php echo number_format($product['price'], 2, ',', '.'); ?></td>
                                    <td class="py-3 px-6 border-b border-gray-200">
                                        <span class="px-2 py-1 rounded-full text-xs font-semibold <?php echo $product['active'] ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'; ?>">
                                            <?php echo $product['active'] ? 'Sim' : 'Não'; ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-6 border-b border-gray-200">
                                        <button class="editProductBtn bg-yellow-500 text-white px-3 py-1 rounded-md hover:bg-yellow-600 mr-2" data-id="<?php echo $product['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="deleteProductBtn bg-red-600 text-white px-3 py-1 rounded-md hover:bg-red-700" data-id="<?php echo $product['id']; ?>">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <!-- Modal para Adicionar/Editar Produto -->
        <div id="productModal" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden">
            <div class="bg-white p-8 rounded-lg shadow-xl w-full max-w-lg">
                <h2 id="modalTitle" class="text-2xl font-bold mb-6 text-gray-800">Adicionar Produto</h2>
                <form id="productForm" enctype="multipart/form-data">
                    <input type="hidden" id="productId" name="id">
                    <input type="hidden" id="currentImagePath" name="current_image_path"> <!-- Para manter o caminho da imagem existente -->

                    <div class="mb-4">
                        <label for="productName" class="block text-gray-700 text-sm font-bold mb-2">Nome do Produto:</label>
                        <input type="text" id="productName" name="name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="productDescription" class="block text-gray-700 text-sm font-bold mb-2">Descrição:</label>
                        <textarea id="productDescription" name="description" rows="3" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                    </div>
                    <div class="mb-4">
                        <label for="productPrice" class="block text-gray-700 text-sm font-bold mb-2">Preço:</label>
                        <input type="number" step="0.01" id="productPrice" name="price" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                    </div>
                    <div class="mb-4">
                        <label for="productCategory" class="block text-gray-700 text-sm font-bold mb-2">Categoria:</label>
                        <select id="productCategory" name="category_id" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                            <option value="">Selecione uma Categoria</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo htmlspecialchars($category['id']); ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label for="productImage" class="block text-gray-700 text-sm font-bold mb-2">Imagem do Produto:</label>
                        <input type="file" id="productImage" name="image" accept="image/*" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <p class="text-xs text-gray-500 mt-1">Selecione uma nova imagem para fazer upload. Deixe em branco para manter a imagem atual.</p>
                        <div id="imagePreviewContainer" class="mt-2 hidden">
                            <img id="imagePreview" src="#" alt="Pré-visualização da Imagem" class="w-32 h-32 object-cover rounded-md border border-gray-300">
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="productSortOrder" class="block text-gray-700 text-sm font-bold mb-2">Ordem de Exibição:</label>
                        <input type="number" id="productSortOrder" name="sort_order" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="0">
                    </div>
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2">Ativo:</label>
                        <input type="checkbox" id="productActive" name="active" class="mr-2 leading-tight">
                        <span class="text-sm">Produto ativo no menu</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">Salvar Produto</button>
                        <button type="button" id="closeProductModal" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
      </div>
    </div>

<?php include_once 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const productModal = document.getElementById('productModal');
    const addProductBtn = document.getElementById('addProductBtn');
    const closeProductModal = document.getElementById('closeProductModal');
    const productForm = document.getElementById('productForm');
    const modalTitle = document.getElementById('modalTitle');
    const productId = document.getElementById('productId');
    const productName = document.getElementById('productName');
    const productDescription = document.getElementById('productDescription');
    const productPrice = document.getElementById('productPrice');
    const productCategory = document.getElementById('productCategory');
    const productImageInput = document.getElementById('productImage');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const currentImagePath = document.getElementById('currentImagePath');
    const productSortOrder = document.getElementById('productSortOrder');
    const productActive = document.getElementById('productActive');

    const uploadBaseUrl = "<?php echo $uploadBaseUrl; ?>";
    const ESTABLISHMENT_ID = <?php echo json_encode($establishment_id); ?>;

    // Função para abrir o modal no modo de adição
    addProductBtn.addEventListener('click', function() {
        modalTitle.textContent = 'Adicionar Novo Produto';
        productForm.reset(); // Limpa o formulário
        productId.value = '';
        currentImagePath.value = '';
        imagePreview.src = '#';
        imagePreviewContainer.classList.add('hidden');
        productActive.checked = true; // Padrão para ativo
        productSortOrder.value = 0; // Padrão para 0
        productModal.classList.remove('hidden');
    });

    // Função para fechar o modal
    closeProductModal.addEventListener('click', function() {
        productModal.classList.add('hidden');
    });

    // Pré-visualização da imagem ao selecionar um arquivo
    productImageInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreviewContainer.classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        } else {
            imagePreview.src = '#';
            imagePreviewContainer.classList.add('hidden');
        }
    });

    // Lógica para editar produto
    document.querySelectorAll('.editProductBtn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.dataset.id;
            modalTitle.textContent = 'Editar Produto';
            productForm.reset(); // Limpa o formulário
            productId.value = id;
            imagePreview.src = '#';
            imagePreviewContainer.classList.add('hidden');

            // Buscar dados do produto
            fetch(`../api/admin/products/get.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const product = data.product;
                        productName.value = product.name;
                        productDescription.value = product.description;
                        productPrice.value = parseFloat(product.price).toFixed(2);
                        productCategory.value = product.category_id;
                        productSortOrder.value = product.sort_order;
                        productActive.checked = product.active == 1; // Converter para booleano

                        if (product.image_url) {
                            imagePreview.src = uploadBaseUrl + product.image_url;
                            imagePreviewContainer.classList.remove('hidden');
                            currentImagePath.value = product.image_url; // Salva o caminho atual
                        } else {
                            currentImagePath.value = '';
                        }
                        productModal.classList.remove('hidden');
                    } else {
                        alert('Erro ao carregar dados do produto: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro de rede ao carregar dados do produto.');
                });
        });
    });

    // Lógica para submeter o formulário (Adicionar/Editar)
    productForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const formData = new FormData(productForm);
        const id = productId.value;
        const isEditing = id !== '';

        let imageUrl = currentImagePath.value; // Começa com a imagem atual

        // Se uma nova imagem foi selecionada, faça o upload primeiro
        if (productImageInput.files.length > 0) {
            const imageFile = productImageInput.files[0];
            const imageFormData = new FormData();
            imageFormData.append('image', imageFile);

            try {
                const uploadResponse = await fetch('../api/admin/upload-image.php', {
                    method: 'POST',
                    body: imageFormData
                });
                const uploadData = await uploadResponse.json();

                if (uploadData.success) {
                    imageUrl = uploadData.image_path; // Atualiza com o novo caminho da imagem
                } else {
                    alert('Erro no upload da imagem: ' + uploadData.message);
                    return; // Interrompe o processo se o upload falhar
                }
            } catch (error) {
                console.error('Erro no upload da imagem:', error);
                alert('Erro de rede ao fazer upload da imagem.');
                return;
            }
        }

        // Adiciona o caminho da imagem (novo ou existente) ao formData principal
        formData.set('image_url', imageUrl);
        // Remove o campo de arquivo, pois já lidamos com ele
        formData.delete('image'); 
        
        // Adiciona o ID do estabelecimento
        formData.append('establishment_id', ESTABLISHMENT_ID);

        const url = isEditing ? '../api/admin/products/update.php' : '../api/admin/products/add.php';
        const method = 'POST'; // Ambos usam POST

        fetch(url, {
            method: method,
            body: formData // FormData é enviado diretamente
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
                productModal.classList.add('hidden');
                location.reload(); // Recarrega a página para ver as atualizações
            } else {
                alert('Erro: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro de rede ao salvar produto.');
        });
    });

    // Lógica para deletar produto
    document.querySelectorAll('.deleteProductBtn').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.dataset.id;
            if (confirm('Tem certeza que deseja deletar este produto?')) {
                fetch('../api/admin/products/delete.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload(); // Recarrega a página para ver as atualizações
                    } else {
                        alert('Erro: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    alert('Erro de rede ao deletar produto.');
                });
            }
        });
    });
});
</script>
