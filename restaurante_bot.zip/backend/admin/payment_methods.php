<?php
require_once 'includes/header.php';

// Processar ativação/desativação
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['method_id'])) {
    $method_id = intval($_POST['method_id']);
    $active = isset($_POST['active']) ? 1 : 0;
    // Só permite alterar métodos do próprio estabelecimento, exceto superadmin
    if ($admin_role === 'super_admin') {
        $query = "UPDATE payment_methods SET active=? WHERE id=?";
        $stmt = $db->prepare($query);
        $stmt->execute([$active, $method_id]);
    } else {
        $query = "UPDATE payment_methods SET active=? WHERE id=? AND establishment_id=?";
        $stmt = $db->prepare($query);
        $stmt->execute([$active, $method_id, $admin_establishment_id]);
    }
    echo "<script>window.location.href='payment_methods.php';</script>";
    exit;
}

// Buscar métodos de pagamento
if ($admin_role === 'super_admin' && isset($_GET['establishment_id'])) {
    $establishment_id = intval($_GET['establishment_id']);
} else {
    $establishment_id = $admin_establishment_id;
}
$query = "SELECT * FROM payment_methods WHERE establishment_id = :establishment_id ORDER BY id ASC";
$stmt = $db->prepare($query);
$stmt->bindParam(':establishment_id', $establishment_id);
$stmt->execute();
$methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="p-3 p-md-4">
    <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
        <h2 class="fw-semibold text-dark mb-0">Formas de Pagamento</h2>
    </div>
    <div class="table-responsive bg-white rounded-lg shadow-md p-3 mb-4">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tipo</th>
                    <th>Nome</th>
                    <th>Ícone</th>
                    <th>Ativo</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($methods)): ?>
                    <tr><td colspan="6" class="text-center">Nenhuma forma de pagamento encontrada.</td></tr>
                <?php else: ?>
                    <?php foreach ($methods as $method): ?>
                        <tr>
                            <td><?= $method['id'] ?></td>
                            <td><?= ucfirst($method['method_type']) ?></td>
                            <td><?= htmlspecialchars($method['name']) ?></td>
                            <td><?= htmlspecialchars($method['icon']) ?></td>
                            <td>
                                <span class="badge bg-<?= $method['active'] ? 'success' : 'danger' ?>">
                                    <?= $method['active'] ? 'Sim' : 'Não' ?>
                                </span>
                            </td>
                            <td>
                                <form method="post" style="display:inline-block">
                                    <input type="hidden" name="method_id" value="<?= $method['id'] ?>">
                                    <input type="checkbox" name="active" value="1" <?= $method['active'] ? 'checked' : '' ?> onchange="this.form.submit()">
                                    <span class="ms-1">Ativar</span>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="text-muted">Marque ou desmarque para ativar/desativar cada forma de pagamento. As alterações são salvas imediatamente.</p>
</div>
<?php require_once 'includes/footer.php'; ?> 