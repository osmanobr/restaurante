<?php
require_once __DIR__ . '/../../config/paths.php';
session_start();
require_once PROJECT_ROOT . '/backend/config/database.php';
require_once PROJECT_ROOT . '/backend/config/establishment.php';

// Verifica se o usuário está logado e é um administrador
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$establishmentManager = new EstablishmentManager($database);

// Obter informações do admin logado
$admin_id = $_SESSION['admin_id'];
$stmt = $db->prepare("SELECT username, role, establishment_id FROM admin_users WHERE id = :id");
$stmt->bindParam(':id', $admin_id);
$stmt->execute();
$admin_user = $stmt->fetch(PDO::FETCH_ASSOC);

// Definir variáveis globais para uso nas páginas
$admin_role = $admin_user['role'];
$admin_establishment_id = $admin_user['establishment_id'];

// Se não for superadmin, só pode acessar o próprio estabelecimento
if ($admin_role !== 'super_admin') {
    // Forçar o uso do establishment_id do admin em todas as operações
    // (as páginas devem usar $admin_establishment_id para filtrar dados)
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo - Restaurante Bot</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        .sidebar-fixed {
            width: 250px;
            min-height: 100vh;
        }
        @media (max-width: 991px) {
            .sidebar-fixed {
                display: none !important;
            }
        }
        @media (min-width: 992px) {
            .offcanvas {
                display: none !important;
            }
            main {
                margin-left: 250px !important;
            }
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Botão para abrir o menu (mobile) -->
    <nav class="navbar navbar-light bg-white shadow-sm d-lg-none">
        <div class="container-fluid">
            <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarOffcanvas">
                <i class="fas fa-bars"></i>
            </button>
            <span class="navbar-brand mb-0 h1">Painel Administrativo</span>
        </div>
    </nav>
    <!-- Sidebar fixo (desktop) -->
    <div class="d-none d-lg-flex flex-column bg-dark text-white position-fixed h-100 p-0" style="width:250px;z-index:1030;">
        <div class="p-4 border-bottom border-secondary">
            <h1 class="h4 mb-0">Admin Panel</h1>
        </div>
        <nav class="flex-grow-1 mt-3">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                <li class="nav-item"><a href="orders.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i>Pedidos</a></li>
                <li class="nav-item"><a href="customers.php" class="nav-link text-white"><i class="fas fa-users me-2"></i>Clientes</a></li>
                <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-list me-2"></i>Categorias</a></li>
                <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box-open me-2"></i>Produtos</a></li>
                <li class="nav-item"><a href="coupons.php" class="nav-link text-white"><i class="fas fa-tags me-2"></i>Cupons</a></li>
                <li class="nav-item"><a href="establishments.php" class="nav-link text-white"><i class="fas fa-store me-2"></i>Estabelecimentos</a></li>
                <li class="nav-item"><a href="payment_methods.php" class="nav-link text-white"><i class="fas fa-credit-card me-2"></i>Formas de Pagamento</a></li>
                <li class="nav-item"><a href="vagas.php" class="nav-link text-white"><i class="fas fa-briefcase me-2"></i>Vagas</a></li>
                <li class="nav-item"><a href="mensagens.php" class="nav-link text-white"><i class="fas fa-comments me-2"></i>Mensagens</a></li>
                <?php if ($admin_user['role'] === 'super_admin'): ?>
                <li class="nav-item"><a href="admin_users.php" class="nav-link text-white"><i class="fas fa-user-shield me-2"></i>Usuários Admin</a></li>
                <?php endif; ?>
            </ul>
        </nav>
        <div class="p-4 border-top border-secondary mt-auto">
            <a href="#" id="logoutBtn" class="nav-link text-white"><i class="fas fa-sign-out-alt me-2"></i>Sair</a>
        </div>
    </div>
    <!-- Sidebar Offcanvas (mobile) -->
    <div class="offcanvas offcanvas-start bg-dark text-white" tabindex="-1" id="sidebarOffcanvas">
        <div class="offcanvas-header border-bottom border-secondary">
            <h5 class="offcanvas-title">Admin Panel</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body d-flex flex-column p-0">
            <nav class="flex-grow-1 mt-3">
                <ul class="nav flex-column">
                    <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                    <li class="nav-item"><a href="orders.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i>Pedidos</a></li>
                    <li class="nav-item"><a href="customers.php" class="nav-link text-white"><i class="fas fa-users me-2"></i>Clientes</a></li>
                    <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-list me-2"></i>Categorias</a></li>
                    <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box-open me-2"></i>Produtos</a></li>
                    <li class="nav-item"><a href="coupons.php" class="nav-link text-white"><i class="fas fa-tags me-2"></i>Cupons</a></li>
                    <li class="nav-item"><a href="establishments.php" class="nav-link text-white"><i class="fas fa-store me-2"></i>Estabelecimentos</a></li>
                    <li class="nav-item"><a href="payment_methods.php" class="nav-link text-white"><i class="fas fa-credit-card me-2"></i>Formas de Pagamento</a></li>
                    <li class="nav-item"><a href="vagas.php" class="nav-link text-white"><i class="fas fa-briefcase me-2"></i>Vagas</a></li>
                    <li class="nav-item"><a href="mensagens.php" class="nav-link text-white"><i class="fas fa-comments me-2"></i>Mensagens</a></li>
                    <?php if ($admin_user['role'] === 'super_admin'): ?>
                    <li class="nav-item"><a href="admin_users.php" class="nav-link text-white"><i class="fas fa-user-shield me-2"></i>Usuários Admin</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <div class="p-4 border-top border-secondary mt-auto">
                <a href="#" id="logoutBtnMobile" class="nav-link text-white"><i class="fas fa-sign-out-alt me-2"></i>Sair</a>
            </div>
        </div>
    </div>
    <!-- Grid Bootstrap para layout responsivo -->
    <div class="container-fluid">
      <div class="row flex-nowrap">
        <!-- Espaço da sidebar desktop -->
        <div class="d-none d-lg-block col-lg-2 p-0"></div>
        <!-- Conteúdo principal -->
        <main class="col-12 col-lg-10 ms-auto px-0" style="min-height:100vh;">
          <div class="container-fluid p-0">
            <header class="bg-white shadow-md rounded-lg p-4 mb-6 d-flex justify-content-between align-items-center">
                <h2 class="h4 mb-0">Bem-vindo, <?php echo htmlspecialchars($admin_user['username']); ?>!</h2>
                <div>
                    <span class="text-gray-600">Role: <?php echo htmlspecialchars($admin_user['role']); ?></span>
                </div>
            </header>
