<script>
  function doLogout() {
    fetch('../api/admin/logout.php', { method: 'POST' })
      .then(() => {
        window.location.href = 'login.php';
      })
      .catch(() => {
        window.location.href = 'login.php';
      });
  }
  document.addEventListener('DOMContentLoaded', function() {
    var btn = document.getElementById('logoutBtn');
    if (btn) btn.addEventListener('click', function(e) { e.preventDefault(); doLogout(); });
    var btnMobile = document.getElementById('logoutBtnMobile');
    if (btnMobile) btnMobile.addEventListener('click', function(e) { e.preventDefault(); doLogout(); });
  });
</script>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
