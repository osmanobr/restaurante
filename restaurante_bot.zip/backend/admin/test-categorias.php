<?php
require_once 'includes/header.php';
$establishment_id = isset($admin_establishment_id) ? $admin_establishment_id : (isset($_SESSION['admin_establishment_id']) ? $_SESSION['admin_establishment_id'] : 0);

// Mostra o valor do establishment_id
 echo "<h3>ESTABLISHMENT_ID: <span style='color:blue'>" . htmlspecialchars($establishment_id) . "</span></h3>";

// Faz a requisição para o endpoint de categorias
$url = "../api/admin/categories/get.php?establishment_id=" . urlencode($establishment_id);
$response = @file_get_contents($url);

if ($response === false) {
    echo "<div style='color:red'>Erro ao acessar o endpoint: $url</div>";
} else {
    echo "<h4>Resposta do endpoint:</h4>";
    echo "<pre style='background:#eee;padding:10px;border-radius:5px'>" . htmlspecialchars($response) . "</pre>";
    $json = json_decode($response, true);
    if ($json && isset($json['categories'])) {
        echo "<h4>Categorias encontradas:</h4>";
        echo "<ul>";
        foreach ($json['categories'] as $cat) {
            echo "<li>ID: ".$cat['id']." | Nome: ".htmlspecialchars($cat['name'])." | Ativo: ".($cat['active'] ? 'Sim' : 'Não')."</li>";
        }
        echo "</ul>";
    } else {
        echo "<div style='color:orange'>Nenhuma categoria encontrada ou resposta inválida.</div>";
    }
}
require_once 'includes/footer.php'; 