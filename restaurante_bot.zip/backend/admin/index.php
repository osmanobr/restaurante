<?php
// Redirect to dashboard.php by default
$establishment_id = isset($_GET['establishment_id']) ? intval($_GET['establishment_id']) : 1; // Default to 1 for testing
header("Location: dashboard.php?establishment_id=" . $establishment_id);
exit();
?>
