<?php
require_once 'includes/header.php';

// Processar cadastro/edição/fechamento de vaga
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['vaga_id']) ? intval($_POST['vaga_id']) : null;
    $titulo = trim($_POST['titulo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $tipo_vaga = trim($_POST['tipo_vaga'] ?? '');
    $cidade = trim($_POST['cidade'] ?? '');
    $quantidade = intval($_POST['quantidade'] ?? 1);
    $status = isset($_POST['fechar']) ? 'FECHADA' : 'ABERTA';
    $establishment_id = $admin_role === 'super_admin' && isset($_POST['establishment_id']) ? intval($_POST['establishment_id']) : $admin_establishment_id;

    if ($id) {
        // Editar ou fechar vaga
        $query = "UPDATE vagas SET titulo=?, descricao=?, tipo_vaga=?, cidade=?, quantidade=?, status=? WHERE id=? AND establishment_id=?";
        $stmt = $db->prepare($query);
        $stmt->execute([$titulo, $descricao, $tipo_vaga, $cidade, $quantidade, $status, $id, $establishment_id]);
    } else {
        // Nova vaga
        $query = "INSERT INTO vagas (establishment_id, titulo, descricao, tipo_vaga, cidade, quantidade, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        $stmt->execute([$establishment_id, $titulo, $descricao, $tipo_vaga, $cidade, $quantidade, $status]);
    }
    echo "<script>window.location.href='vagas.php';</script>";
    exit;
}

// Buscar vagas do estabelecimento
if ($admin_role === 'super_admin' && isset($_GET['establishment_id'])) {
    $establishment_id = intval($_GET['establishment_id']);
} else {
    $establishment_id = $admin_establishment_id;
}
$query = "SELECT v.*, (SELECT COUNT(*) FROM vagas_interessados vi WHERE vi.vaga_id = v.id) as interessados FROM vagas v WHERE v.establishment_id = :establishment_id ORDER BY v.data_criacao DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':establishment_id', $establishment_id);
$stmt->execute();
$vagas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="p-3 p-md-4">
    <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
        <h2 class="fw-semibold text-dark mb-0">Vagas de Emprego</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#vagaModal" onclick="resetVagaForm()">Nova Vaga</button>
    </div>
    <p class="text-muted mb-4">Cadastre oportunidades de emprego para o seu estabelecimento e gerencie os candidatos interessados em cada vaga.</p>
    <div class="table-responsive bg-white rounded-lg shadow-md p-3 mb-4">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Tipo</th>
                    <th>Cidade</th>
                    <th>Qtd</th>
                    <th>Status</th>
                    <th>Interessados</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($vagas)): ?>
                    <tr><td colspan="8" class="text-center">Nenhuma vaga encontrada.</td></tr>
                <?php else: ?>
                    <?php foreach ($vagas as $vaga): ?>
                        <tr>
                            <td><?= $vaga['id'] ?></td>
                            <td><?= htmlspecialchars($vaga['titulo']) ?></td>
                            <td><?= htmlspecialchars($vaga['tipo_vaga']) ?></td>
                            <td><?= htmlspecialchars($vaga['cidade']) ?></td>
                            <td><?= $vaga['quantidade'] ?></td>
                            <td><span class="badge bg-<?= $vaga['status'] === 'ABERTA' ? 'success' : 'danger' ?>"><?= $vaga['status'] ?></span></td>
                            <td><a href="vaga_interessados.php?vaga_id=<?= $vaga['id'] ?>" class="btn btn-sm btn-info">Ver (<?= $vaga['interessados'] ?>)</a></td>
                            <td>
                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#vagaModal" onclick='editVaga(<?= json_encode($vaga) ?>)'>Editar</button>
                                <?php if ($vaga['status'] === 'ABERTA'): ?>
                                <form method="post" style="display:inline-block">
                                    <input type="hidden" name="vaga_id" value="<?= $vaga['id'] ?>">
                                    <input type="hidden" name="titulo" value="<?= htmlspecialchars($vaga['titulo'], ENT_QUOTES) ?>">
                                    <input type="hidden" name="descricao" value="<?= htmlspecialchars($vaga['descricao'], ENT_QUOTES) ?>">
                                    <input type="hidden" name="tipo_vaga" value="<?= htmlspecialchars($vaga['tipo_vaga'], ENT_QUOTES) ?>">
                                    <input type="hidden" name="cidade" value="<?= htmlspecialchars($vaga['cidade'], ENT_QUOTES) ?>">
                                    <input type="hidden" name="quantidade" value="<?= $vaga['quantidade'] ?>">
                                    <input type="hidden" name="fechar" value="1">
                                    <button type="submit" class="btn btn-sm btn-warning">Fechar</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <!-- Modal de cadastro/edição de vaga -->
    <div class="modal fade" id="vagaModal" tabindex="-1" aria-labelledby="vagaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="vagaModalLabel">Nova Vaga</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="vagaForm" method="post">
                        <input type="hidden" id="vaga_id" name="vaga_id">
                        <div class="mb-3">
                            <label for="titulo" class="form-label">Título *</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" required>
                        </div>
                        <div class="mb-3">
                            <label for="descricao" class="form-label">Descrição</label>
                            <textarea class="form-control" id="descricao" name="descricao" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="tipo_vaga" class="form-label">Tipo de Vaga</label>
                            <input type="text" class="form-control" id="tipo_vaga" name="tipo_vaga">
                        </div>
                        <div class="mb-3">
                            <label for="cidade" class="form-label">Cidade *</label>
                            <input type="text" class="form-control" id="cidade" name="cidade" required>
                        </div>
                        <div class="mb-3">
                            <label for="quantidade" class="form-label">Quantidade</label>
                            <input type="number" class="form-control" id="quantidade" name="quantidade" value="1" min="1">
                        </div>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function resetVagaForm() {
    document.getElementById('vagaForm').reset();
    document.getElementById('vaga_id').value = '';
    document.getElementById('vagaModalLabel').textContent = 'Nova Vaga';
}
function editVaga(vaga) {
    document.getElementById('vaga_id').value = vaga.id;
    document.getElementById('titulo').value = vaga.titulo;
    document.getElementById('descricao').value = vaga.descricao;
    document.getElementById('tipo_vaga').value = vaga.tipo_vaga;
    document.getElementById('cidade').value = vaga.cidade;
    document.getElementById('quantidade').value = vaga.quantidade;
    document.getElementById('vagaModalLabel').textContent = 'Editar Vaga';
}
</script>
<?php require_once 'includes/footer.php'; ?> 