<?php
// AJAX para atualização da lista de conversas (deve ser antes de qualquer require ou HTML)
if (isset($_GET['ajax'])) {
    require_once '../config/database.php';
    session_start();
    $admin_id = $_SESSION['admin_id'] ?? 0;
    $db = (new Database())->getConnection();
    // Função utilitária para buscar nome do usuário
    if (!function_exists('getNome')) {
        function getNome($id, $tipo, $db) {
            if ($tipo === 'cliente') {
                $stmt = $db->prepare('SELECT name FROM customers WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                return $row ? $row['name'] : 'Cliente #' . $id;
            } elseif ($tipo === 'admin') {
                $stmt = $db->prepare('SELECT username FROM admin_users WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                return $row ? $row['username'] : 'Admin #' . $id;
            } elseif ($tipo === 'entregador') {
                $stmt = $db->prepare('SELECT nome FROM entregadores WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                return $row ? $row['nome'] : 'Entregador #' . $id;
            } elseif ($tipo === 'estabelecimento') {
                $stmt = $db->prepare('SELECT name FROM establishments WHERE id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                return $row ? $row['name'] : 'Estabelecimento #' . $id;
            }
            return $tipo . ' #' . $id;
        }
    }
    // Repetir a query de conversas
    $query = "SELECT destinatario_id, destinatario_tipo, remetente_id, remetente_tipo, MAX(data_envio) as ultima, COUNT(*) as total, SUM(NOT lida AND destinatario_id = :admin_id AND destinatario_tipo = 'admin') as nao_lidas
              FROM mensagens
              WHERE (remetente_id = :admin_id AND remetente_tipo = 'admin') OR (destinatario_id = :admin_id AND destinatario_tipo = 'admin')
              GROUP BY destinatario_id, destinatario_tipo, remetente_id, remetente_tipo
              ORDER BY ultima DESC";
    $stmt = $db->prepare($query);
    $stmt->execute(['admin_id' => $admin_id]);
    $conversas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $mostrados = [];
    if (empty($conversas)) {
        echo '<li class="list-group-item">Nenhuma conversa encontrada.</li>';
    } else {
        foreach ($conversas as $conv) {
            if ($conv['remetente_id'] == $admin_id && $conv['remetente_tipo'] == 'admin') {
                $other_id = $conv['destinatario_id'];
                $other_tipo = $conv['destinatario_tipo'];
            } else {
                $other_id = $conv['remetente_id'];
                $other_tipo = $conv['remetente_tipo'];
            }
            $chave = $other_tipo . '-' . $other_id;
            if (isset($mostrados[$chave])) continue;
            $mostrados[$chave] = true;
            $nome = getNome($other_id, $other_tipo, $db);
            echo '<li class="list-group-item d-flex justify-content-between align-items-center">';
            echo '<a href="mensagens.php?chat_with=' . $other_id . '&tipo=' . $other_tipo . '">' . htmlspecialchars($nome) . ' <span class="badge bg-secondary ms-2">' . $other_tipo . '</span></a>';
            if ($conv['nao_lidas'] > 0) {
                echo '<span class="badge bg-danger">' . $conv['nao_lidas'] . ' nova(s)</span>';
            }
            echo '</li>';
        }
    }
    exit;
}
require_once 'includes/header.php';

// Função utilitária para buscar nome do usuário
if (!function_exists('getNome')) {
    function getNome($id, $tipo, $db) {
        if ($tipo === 'cliente') {
            $stmt = $db->prepare('SELECT name FROM customers WHERE id = ?');
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            return $row ? $row['name'] : 'Cliente #' . $id;
        } elseif ($tipo === 'admin') {
            $stmt = $db->prepare('SELECT username FROM admin_users WHERE id = ?');
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            return $row ? $row['username'] : 'Admin #' . $id;
        } elseif ($tipo === 'entregador') {
            $stmt = $db->prepare('SELECT nome FROM entregadores WHERE id = ?');
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            return $row ? $row['nome'] : 'Entregador #' . $id;
        } elseif ($tipo === 'estabelecimento') {
            $stmt = $db->prepare('SELECT name FROM establishments WHERE id = ?');
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            return $row ? $row['name'] : 'Estabelecimento #' . $id;
        }
        return $tipo . ' #' . $id;
    }
}

// Processar envio de mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['destinatario_id'], $_POST['destinatario_tipo'], $_POST['mensagem'])) {
    $remetente_id = $admin_id;
    $remetente_tipo = 'admin';
    $destinatario_id = intval($_POST['destinatario_id']);
    $destinatario_tipo = $_POST['destinatario_tipo'];
    $mensagem = trim($_POST['mensagem']);
    if ($mensagem !== '') {
        $stmt = $db->prepare('INSERT INTO mensagens (remetente_id, remetente_tipo, destinatario_id, destinatario_tipo, mensagem) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$remetente_id, $remetente_tipo, $destinatario_id, $destinatario_tipo, $mensagem]);
    }
    echo "<script>window.location.href='mensagens.php?chat_with=$destinatario_id&tipo=$destinatario_tipo';</script>";
    exit;
}

// Listar conversas recentes (agrupadas por par destinatario/remetente)
$query = "SELECT destinatario_id, destinatario_tipo, remetente_id, remetente_tipo, MAX(data_envio) as ultima, COUNT(*) as total, SUM(NOT lida AND destinatario_id = :admin_id AND destinatario_tipo = 'admin') as nao_lidas
          FROM mensagens
          WHERE (remetente_id = :admin_id AND remetente_tipo = 'admin') OR (destinatario_id = :admin_id AND destinatario_tipo = 'admin')
          GROUP BY destinatario_id, destinatario_tipo, remetente_id, remetente_tipo
          ORDER BY ultima DESC";
$stmt = $db->prepare($query);
$stmt->execute(['admin_id' => $admin_id]);
$conversas = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Se for um chat específico
$chat_with = isset($_GET['chat_with']) ? intval($_GET['chat_with']) : null;
$tipo = $_GET['tipo'] ?? null;
$chat = [];
if ($chat_with && $tipo) {
    $stmt = $db->prepare('SELECT * FROM mensagens WHERE ((remetente_id = :admin_id AND remetente_tipo = "admin" AND destinatario_id = :chat_with AND destinatario_tipo = :tipo) OR (remetente_id = :chat_with AND remetente_tipo = :tipo AND destinatario_id = :admin_id AND destinatario_tipo = "admin")) ORDER BY data_envio ASC');
    $stmt->execute([
        'admin_id' => $admin_id,
        'chat_with' => $chat_with,
        'tipo' => $tipo
    ]);
    $chat = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // Marcar como lidas as mensagens recebidas
    $db->prepare('UPDATE mensagens SET lida=1 WHERE destinatario_id = :admin_id AND destinatario_tipo = "admin" AND remetente_id = :chat_with AND remetente_tipo = :tipo AND lida=0')->execute([
        'admin_id' => $admin_id,
        'chat_with' => $chat_with,
        'tipo' => $tipo
    ]);
}
?>
<div class="p-3 p-md-4">
    <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
        <h2 class="fw-semibold text-dark mb-0">Mensagens</h2>
    </div>
    <div class="row g-3">
        <div class="col-12 col-md-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h5 class="mb-0">Conversas Recentes</h5>
                <button class="btn btn-outline-secondary btn-sm" onclick="atualizarConversas()">Atualizar</button>
            </div>
            <ul class="list-group mb-3" id="conversasList">
                <?php
                // Mostrar só uma conversa por participante (última)
                $mostrados = [];
                if (empty($conversas)):
                ?>
                    <li class="list-group-item">Nenhuma conversa encontrada.</li>
                <?php else:
                    foreach ($conversas as $conv):
                        if ($conv['remetente_id'] == $admin_id && $conv['remetente_tipo'] == 'admin') {
                            $other_id = $conv['destinatario_id'];
                            $other_tipo = $conv['destinatario_tipo'];
                        } else {
                            $other_id = $conv['remetente_id'];
                            $other_tipo = $conv['remetente_tipo'];
                        }
                        $chave = $other_tipo . '-' . $other_id;
                        if (isset($mostrados[$chave])) continue;
                        $mostrados[$chave] = true;
                        $nome = getNome($other_id, $other_tipo, $db);
                ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <a href="mensagens.php?chat_with=<?= $other_id ?>&tipo=<?= $other_tipo ?>">
                            <?= htmlspecialchars($nome) ?> <span class="badge bg-secondary ms-2"><?= $other_tipo ?></span>
                        </a>
                        <?php if ($conv['nao_lidas'] > 0): ?>
                            <span class="badge bg-danger"><?= $conv['nao_lidas'] ?> nova(s)</span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
            </ul>
            <h6>Nova Conversa</h6>
            <form method="get" action="mensagens.php" autocomplete="off">
                <div class="mb-2">
                    <select name="tipo" class="form-select" id="tipoBusca" required>
                        <option value="">Selecione o tipo</option>
                        <option value="cliente">Cliente</option>
                        <option value="entregador">Entregador</option>
                        <option value="estabelecimento">Estabelecimento</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>
                <div class="mb-2 position-relative">
                    <input type="text" id="buscaUsuario" class="form-control" placeholder="Nome ou telefone" autocomplete="off">
                    <input type="hidden" name="chat_with" id="chatWithId">
                    <div id="autocompleteUsuarios" class="list-group position-absolute w-100" style="z-index:10;"></div>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Iniciar</button>
                <small class="text-muted d-block mt-1">Busque por nome ou telefone e selecione o usuário.</small>
            </form>
        </div>
        <div class="col-12 col-md-8">
            <?php if ($chat_with && $tipo): ?>
                <h5>Chat com <?= htmlspecialchars(getNome($chat_with, $tipo, $db)) ?> <span class="badge bg-secondary ms-2"><?= $tipo ?></span></h5>
                <div class="border rounded p-3 mb-3 bg-light" style="min-height:300px; max-height:60vh; overflow-y:auto;">
                    <?php if (empty($chat)): ?>
                        <div class="text-center text-muted">Nenhuma mensagem.</div>
                    <?php else: ?>
                        <?php foreach ($chat as $msg): ?>
                            <div class="mb-2 <?= $msg['remetente_tipo'] === 'admin' && $msg['remetente_id'] == $admin_id ? 'text-end' : 'text-start' ?>">
                                <span class="small text-muted"><?= date('d/m H:i', strtotime($msg['data_envio'])) ?></span><br>
                                <span class="p-2 rounded <?= $msg['remetente_tipo'] === 'admin' && $msg['remetente_id'] == $admin_id ? 'bg-primary text-white' : 'bg-white border' ?> d-inline-block">
                                    <?= nl2br(htmlspecialchars($msg['mensagem'])) ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <form method="post" class="d-flex gap-2">
                    <input type="hidden" name="destinatario_id" value="<?= $chat_with ?>">
                    <input type="hidden" name="destinatario_tipo" value="<?= $tipo ?>">
                    <textarea name="mensagem" class="form-control" rows="2" placeholder="Digite sua mensagem..." required></textarea>
                    <button type="submit" class="btn btn-success">Enviar</button>
                </form>
            <?php else: ?>
                <div class="alert alert-info">Selecione uma conversa ou inicie uma nova.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?> 
<script>
// Atualização automática da lista de conversas
function atualizarConversas() {
    fetch('mensagens.php?ajax=1')
        .then(r => r.text())
        .then(html => {
            document.getElementById('conversasList').innerHTML = html;
            // Não limpa busca nem chatWithId!
        });
}
setInterval(atualizarConversas, 10000);

// Autocomplete de usuários
const buscaInput = document.getElementById('buscaUsuario');
const tipoBusca = document.getElementById('tipoBusca');
const autocompleteDiv = document.getElementById('autocompleteUsuarios');
const chatWithId = document.getElementById('chatWithId');

buscaInput.addEventListener('input', function() {
    const termo = this.value.trim();
    const tipo = tipoBusca.value;
    chatWithId.value = '';
    if (termo.length < 4 || !tipo) {
        autocompleteDiv.innerHTML = '';
        return;
    }
    if (tipo === 'cliente') {
        fetch('autocomplete_clientes.php?q=' + encodeURIComponent(termo))
            .then(r => r.json())
            .then(lista => {
                autocompleteDiv.innerHTML = '';
                lista.forEach((u, idx) => {
                    const item = document.createElement('button');
                    item.type = 'button';
                    item.className = 'list-group-item list-group-item-action';
                    item.textContent = u.label;
                    item.dataset.id = u.id;
                    item.onclick = function() {
                        buscaInput.value = u.label;
                        chatWithId.value = u.id;
                        autocompleteDiv.innerHTML = '';
                    };
                    autocompleteDiv.appendChild(item);
                });
            });
    } else {
        autocompleteDiv.innerHTML = '<div class="list-group-item list-group-item-warning">Só é possível buscar clientes por enquanto.</div>';
    }
});
// Se pressionar Enter no campo de busca, seleciona o primeiro item do autocomplete
buscaInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const items = autocompleteDiv.querySelectorAll('button');
        if (items.length === 1) {
            e.preventDefault();
            items[0].click();
        } else if (items.length > 1) {
            // Não seleciona automaticamente se houver mais de um
        }
    }
});
// Bloquear submit se não selecionar usuário
const novaConversaForm = document.querySelector('form[method="get"][action="mensagens.php"]');
novaConversaForm.addEventListener('submit', function(e) {
    if (!chatWithId.value) {
        // Se houver sugestões, selecione a primeira automaticamente
        const first = autocompleteDiv.querySelector('button');
        if (first) {
            first.click();
            if (!chatWithId.value) {
                e.preventDefault();
                buscaInput.focus();
                autocompleteDiv.innerHTML = '<div class="list-group-item list-group-item-danger">Selecione um usuário da lista!</div>';
            }
        } else {
            e.preventDefault();
            buscaInput.focus();
            autocompleteDiv.innerHTML = '<div class="list-group-item list-group-item-danger">Selecione um usuário da lista!</div>';
        }
    }
});
</script>
<?php
// Autocomplete AJAX
if (isset($_GET['autocomplete'], $_GET['tipo'], $_GET['q'])) {
    $tipo = $_GET['tipo'];
    $q = '%' . $_GET['q'] . '%';
    $res = [];
    if ($tipo === 'cliente') {
        // Busca flexível por telefone (remover espaços, traços, parênteses)
        $termo = preg_replace('/\D/', '', $_GET['q']);
        $stmt = $db->prepare('SELECT id, name, phone FROM customers WHERE name LIKE ? OR REPLACE(REPLACE(REPLACE(REPLACE(phone, "-", ""), "(", ""), ")", ""), " ", "") LIKE ? LIMIT 10');
        $stmt->execute([$q, "%$termo%"]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
            $res[] = ['id' => $u['id'], 'label' => $u['name'] . ' (' . $u['phone'] . ')'];
        }
    } elseif ($tipo === 'admin') {
        $stmt = $db->prepare('SELECT id, username FROM admin_users WHERE username LIKE ? LIMIT 10');
        $stmt->execute([$q]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
            $res[] = ['id' => $u['id'], 'label' => $u['username']];
        }
    } elseif ($tipo === 'entregador') {
        $stmt = $db->prepare('SELECT id, nome, cidade FROM entregadores WHERE nome LIKE ? LIMIT 10');
        $stmt->execute([$q]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
            $res[] = ['id' => $u['id'], 'label' => $u['nome'] . ' (' . $u['cidade'] . ')'];
        }
    } elseif ($tipo === 'estabelecimento') {
        $stmt = $db->prepare('SELECT id, name FROM establishments WHERE name LIKE ? LIMIT 10');
        $stmt->execute([$q]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
            $res[] = ['id' => $u['id'], 'label' => $u['name']];
        }
    }
    header('Content-Type: application/json');
    echo json_encode($res);
    exit;
}
?> 