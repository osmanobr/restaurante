<?php
require_once 'includes/header.php'; // Includes header and sets $admin_establishment_id

function formatPhone($phone) {
    $phone = preg_replace('/\D/', '', $phone);
    if (strlen($phone) === 11) {
        return sprintf('(%s) %s-%s', substr($phone, 0, 2), substr($phone, 2, 5), substr($phone, 7));
    } elseif (strlen($phone) === 10) {
        return sprintf('(%s) %s-%s', substr($phone, 0, 2), substr($phone, 2, 4), substr($phone, 6));
    }
    return $phone;
}

$establishment_id = $admin_establishment_id;

// Buscar todos os clientes para o estabelecimento atual
$query = "SELECT id, phone, name, address, created_at FROM customers WHERE establishment_id = :establishment_id ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':establishment_id', $establishment_id);
$stmt->execute();
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="p-3 p-md-4">
  <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
      <h5 class="fw-semibold text-dark mb-0">Clientes</h5>
      <button class="btn btn-outline-secondary d-flex align-items-center gap-2 py-2 px-2" onclick="location.reload()">
          <i class="bi bi-arrow-clockwise fs-5"></i>
          <span class="d-none d-sm-inline">Atualizar</span>
      </button>
  </div>
            <div class="table-responsive bg-white rounded-lg shadow-md p-3 mb-4">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Telefone</th>
                            <th>Endereço</th>
                            <th>Membro Desde</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($customers)): ?>
                            <tr>
                                <td colspan="6" class="text-center">Nenhum cliente encontrado para este estabelecimento.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($customers as $customer): ?>
                                <tr>
                                    <td><?= $customer['id'] ?></td>
                                    <td><?= htmlspecialchars($customer['name']) ?></td>
                                    <td><?= formatPhone($customer['phone']) ?></td>
                                    <td><?= htmlspecialchars($customer['address']) ?></td>
                                    <td><?= date('d/m/Y', strtotime($customer['created_at'])) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info" onclick="viewCustomerOrders(<?= $customer['id'] ?>)">
                                            <i class="bi bi-receipt"></i> Pedidos
                                        </button>
                                        <!-- Add edit/delete buttons if needed -->
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
  </div>
</div>

<script>
    function viewCustomerOrders(customerId) {
        // This would ideally open a modal or redirect to a page showing orders filtered by customer
        alert('Funcionalidade "Ver Pedidos" para o cliente ID: ' + customerId + ' (a ser implementada)');
        // Example: window.location.href = 'orders.php?establishment_id=<?= $admin_establishment_id ?>&customer_id=' + customerId;
    }
</script>

<?php require_once 'includes/footer.php'; // Includes footer ?>
