<?php
require_once 'includes/header.php';

// Processar formulário de adição/edição (deve ser feito após o header, usando variáveis já disponíveis)
if ($admin_role === 'super_admin' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['establishmentId']) ? intval($_POST['establishmentId']) : null;
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $logo = trim($_POST['logo'] ?? '');
    $primary_color = trim($_POST['primary_color'] ?? '');
    $secondary_color = trim($_POST['secondary_color'] ?? '');
    $delivery_fee = floatval($_POST['delivery_fee'] ?? 0);
    $min_order = floatval($_POST['min_order'] ?? 0);
    $pix_key = trim($_POST['pix_key'] ?? '');
    $pix_name = trim($_POST['pix_name'] ?? '');
    $pix_city = trim($_POST['pix_city'] ?? '');
    if ($id) {
        $query = "UPDATE establishments SET name=?, description=?, address=?, phone=?, whatsapp=?, email=?, logo=?, primary_color=?, secondary_color=?, delivery_fee=?, min_order=?, pix_key=?, pix_name=?, pix_city=? WHERE id=?";
        $stmt = $db->prepare($query);
        $stmt->execute([$name, $description, $address, $phone, $whatsapp, $email, $logo, $primary_color, $secondary_color, $delivery_fee, $min_order, $pix_key, $pix_name, $pix_city, $id]);
    } else {
        $query = "INSERT INTO establishments (name, description, address, phone, whatsapp, email, logo, primary_color, secondary_color, delivery_fee, min_order, pix_key, pix_name, pix_city) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        $stmt->execute([$name, $description, $address, $phone, $whatsapp, $email, $logo, $primary_color, $secondary_color, $delivery_fee, $min_order, $pix_key, $pix_name, $pix_city]);
    }
    echo "<script>window.location.href='establishments.php';</script>";
    exit;
} else if ($admin_role !== 'super_admin' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['establishmentId']) ? intval($_POST['establishmentId']) : null;
    if ($id == $admin_establishment_id) {
        $logo = trim($_POST['logo'] ?? '');
        $delivery_fee = floatval($_POST['delivery_fee'] ?? 0);
        $min_order = floatval($_POST['min_order'] ?? 0);
        $pix_key = trim($_POST['pix_key'] ?? '');
        $pix_name = trim($_POST['pix_name'] ?? '');
        $pix_city = trim($_POST['pix_city'] ?? '');
        $query = "UPDATE establishments SET logo=?, delivery_fee=?, min_order=?, pix_key=?, pix_name=?, pix_city=? WHERE id=?";
        $stmt = $db->prepare($query);
        $stmt->execute([$logo, $delivery_fee, $min_order, $pix_key, $pix_name, $pix_city, $id]);
    }
    echo "<script>window.location.href='establishments.php';</script>";
    exit;
}


if ($admin_role === 'super_admin') {
    // Superadmin vê todos
    $query = "SELECT * FROM establishments ORDER BY name ASC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $establishments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Admin comum só vê o próprio
    $query = "SELECT * FROM establishments WHERE id = :id ORDER BY name ASC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $admin_establishment_id);
    $stmt->execute();
    $establishments = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<div class="p-3 p-md-4">

<?php if ($admin_role === 'super_admin'): ?>
<div class="d-flex justify-content-between align-items-center gap-2 mb-3">
    <h5 class="fw-semibold text-dark mb-0">Estabelecimentos</h5>
    <button class="btn btn-outline-secondary d-flex align-items-center gap-2 py-2 px-2 mb-0" data-bs-toggle="modal" data-bs-target="#establishmentModal" onclick="resetForm()">
        <i class="bi bi-plus-lg fs-5"></i>
        <span class="d-none d-sm-inline">Adicionar</span>
    </button>
</div>
<?php else: ?>
<div class="d-flex justify-content-between align-items-center gap-2 mb-3">
    <h5 class="fw-semibold text-dark mb-0">Meu Estabelecimento</h5>
</div>
<?php endif; ?>

<div class="table-responsive bg-white rounded-lg shadow-md p-3 mb-4">
<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Telefone</th>
            <th>Endereço</th>
            <th>Ativo</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody id="establishmentsTableBody">
        <?php if (empty($establishments)): ?>
            <tr><td colspan="6" class="text-center">Nenhum estabelecimento encontrado.</td></tr>
        <?php else: ?>
            <?php foreach ($establishments as $est): ?>
                <tr>
                    <td><?= $est['id'] ?></td>
                    <td><?= htmlspecialchars($est['name']) ?></td>
                    <td><?= htmlspecialchars($est['phone']) ?></td>
                    <td><?= htmlspecialchars($est['address']) ?></td>
                    <td><span class="badge bg-<?= $est['active'] ? 'success' : 'danger' ?>"><?= $est['active'] ? 'Ativo' : 'Inativo' ?></span></td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="editEstablishment(<?= $est['id'] ?>)">Editar</button>
                        <button class="btn btn-sm btn-<?= $est['active'] ? 'warning' : 'success' ?>" onclick="toggleActiveStatus(<?= $est['id'] ?>, <?= $est['active'] ? 'false' : 'true' ?>)">
                            <?= $est['active'] ? 'Desativar' : 'Ativar' ?>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
</div>

<?php if ($admin_role === 'super_admin'): ?>
<!-- Modal para Adicionar/Editar Estabelecimento -->
<div class="modal fade" id="establishmentModal" tabindex="-1" aria-labelledby="establishmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="establishmentModalLabel">Adicionar/Editar Estabelecimento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="establishmentForm" method="post">
                    <input type="hidden" id="establishmentId" name="establishmentId">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Descrição</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">Endereço</label>
                        <input type="text" class="form-control" id="address" name="address" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Telefone (apenas números, ex: 5511987654321)</label>
                        <input type="text" class="form-control" id="phone" name="phone" pattern="[0-9]{10,13}" title="Apenas números, 10 a 13 dígitos" required>
                    </div>
                    <div class="mb-3">
                        <label for="whatsapp" class="form-label">WhatsApp (apenas números)</label>
                        <input type="text" class="form-control" id="whatsapp" name="whatsapp" pattern="[0-9]{10,13}" title="Apenas números, 10 a 13 dígitos">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="logo" class="form-label">URL do Logo</label>
                        <input type="url" class="form-control" id="logo" name="logo">
                    </div>
                    <div class="mb-3">
                        <label for="primary_color" class="form-label">Cor Primária (Hex)</label>
                        <input type="text" class="form-control" id="primary_color" name="primary_color">
                    </div>
                    <div class="mb-3">
                        <label for="secondary_color" class="form-label">Cor Secundária (Hex)</label>
                        <input type="text" class="form-control" id="secondary_color" name="secondary_color">
                    </div>
                    <div class="mb-3">
                        <label for="delivery_fee" class="form-label">Taxa de Entrega</label>
                        <input type="number" step="0.01" class="form-control" id="delivery_fee" name="delivery_fee" value="0.00">
                    </div>
                    <div class="mb-3">
                        <label for="min_order" class="form-label">Pedido Mínimo</label>
                        <input type="number" step="0.01" class="form-control" id="min_order" name="min_order" value="0.00">
                    </div>
                    <div class="mb-3">
                        <label for="pix_key" class="form-label">Chave PIX</label>
                        <input type="text" class="form-control" id="pix_key" name="pix_key">
                    </div>
                    <div class="mb-3">
                        <label for="pix_name" class="form-label">Nome PIX</label>
                        <input type="text" class="form-control" id="pix_name" name="pix_name">
                    </div>
                    <div class="mb-3">
                        <label for="pix_city" class="form-label">Cidade PIX</label>
                        <input type="text" class="form-control" id="pix_city" name="pix_city">
                    </div>
                    <button type="submit" class="btn btn-primary">Salvar Estabelecimento</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php elseif ($admin_role !== 'super_admin'): ?>
<!-- Modal restrito para admin comum -->
<div class="modal fade" id="establishmentModal" tabindex="-1" aria-labelledby="establishmentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="establishmentModalLabel">Editar Dados do Estabelecimento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="establishmentForm" method="post">
                    <input type="hidden" id="establishmentId" name="establishmentId">
                    <div class="mb-3">
                        <label for="logo" class="form-label">URL do Logo</label>
                        <input type="url" class="form-control" id="logo" name="logo">
                    </div>
                    <div class="mb-3">
                        <label for="delivery_fee" class="form-label">Taxa de Entrega</label>
                        <input type="number" step="0.01" class="form-control" id="delivery_fee" name="delivery_fee" value="0.00">
                    </div>
                    <div class="mb-3">
                        <label for="min_order" class="form-label">Pedido Mínimo</label>
                        <input type="number" step="0.01" class="form-control" id="min_order" name="min_order" value="0.00">
                    </div>
                    <div class="mb-3">
                        <label for="pix_key" class="form-label">Chave PIX</label>
                        <input type="text" class="form-control" id="pix_key" name="pix_key">
                    </div>
                    <div class="mb-3">
                        <label for="pix_name" class="form-label">Nome PIX</label>
                        <input type="text" class="form-control" id="pix_name" name="pix_name">
                    </div>
                    <div class="mb-3">
                        <label for="pix_city" class="form-label">Cidade PIX</label>
                        <input type="text" class="form-control" id="pix_city" name="pix_city">
                    </div>
                    <button type="submit" class="btn btn-primary">Salvar Dados</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>

<script>
    // Função para preencher o formulário ao editar
    function editEstablishment(id) {
        const est = <?= json_encode($establishments) ?>;
        const estToEdit = est.find(e => e.id == id);
        if (estToEdit) {
            document.getElementById('establishmentId').value = estToEdit.id;
            <?php if ($admin_role === 'super_admin'): ?>
            // Preencher todos os campos normalmente
            document.getElementById('name').value = estToEdit.name;
            document.getElementById('description').value = estToEdit.description || '';
            document.getElementById('address').value = estToEdit.address;
            document.getElementById('phone').value = estToEdit.phone;
            document.getElementById('whatsapp').value = estToEdit.whatsapp || '';
            document.getElementById('email').value = estToEdit.email || '';
            document.getElementById('logo').value = estToEdit.logo || '';
            document.getElementById('primary_color').value = estToEdit.primary_color || '';
            document.getElementById('secondary_color').value = estToEdit.secondary_color || '';
            document.getElementById('delivery_fee').value = estToEdit.delivery_fee;
            document.getElementById('min_order').value = estToEdit.min_order;
            document.getElementById('pix_key').value = estToEdit.pix_key || '';
            document.getElementById('pix_name').value = estToEdit.pix_name || '';
            document.getElementById('pix_city').value = estToEdit.pix_city || '';
            <?php else: ?>
            // Preencher apenas os campos permitidos
            document.getElementById('logo').value = estToEdit.logo || '';
            document.getElementById('delivery_fee').value = estToEdit.delivery_fee;
            document.getElementById('min_order').value = estToEdit.min_order;
            document.getElementById('pix_key').value = estToEdit.pix_key || '';
            document.getElementById('pix_name').value = estToEdit.pix_name || '';
            document.getElementById('pix_city').value = estToEdit.pix_city || '';
            <?php endif; ?>
            document.getElementById('establishmentModalLabel').innerText = 'Editar Dados do Estabelecimento';
            const modal = new bootstrap.Modal(document.getElementById('establishmentModal'));
            modal.show();
        } else {
            alert('Estabelecimento não encontrado.');
        }
    }

    function resetForm() {
        document.getElementById('establishmentForm').reset();
        document.getElementById('establishmentId').value = '';
        document.getElementById('establishmentModalLabel').innerText = 'Editar Dados do Estabelecimento';
    }
</script>
