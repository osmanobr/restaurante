<?php
require_once 'includes/header.php'; // Includes header and sets $admin_establishment_id

function formatPhone($phone) {
    $phone = preg_replace('/\D/', '', $phone);
    if (strlen($phone) === 11) {
        return sprintf('(%s) %s-%s', substr($phone, 0, 2), substr($phone, 2, 5), substr($phone, 7));
    } elseif (strlen($phone) === 10) {
        return sprintf('(%s) %s-%s', substr($phone, 0, 2), substr($phone, 2, 4), substr($phone, 6));
    }
    return $phone;
}

$establishment_id = $admin_establishment_id;

// Buscar todos os pedidos para o estabelecimento atual
$query = "SELECT o.*, c.name as customer_name, c.phone, c.address 
          FROM orders o 
          JOIN customers c ON o.customer_id = c.id 
          WHERE o.establishment_id = :establishment_id
          ORDER BY o.created_at DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':establishment_id', $establishment_id);
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="p-3 p-md-4">
  <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
      <h5 class="fw-semibold text-dark mb-0">Pedidos</h5>
      <button class="btn btn-outline-secondary d-flex align-items-center gap-2 py-2 px-2" onclick="location.reload()">
          <i class="bi bi-arrow-clockwise fs-5"></i>
          <span class="d-none d-sm-inline">Atualizar</span>
      </button>
  </div>
  <div class="row">
      <?php if (empty($orders)): ?>
          <div class="col-12">
              <div class="alert alert-info">Nenhum pedido encontrado para este estabelecimento.</div>
          </div>
      <?php else: ?>
          <?php foreach ($orders as $order): ?>
              <?php $items = json_decode($order['items'], true); ?>
              <div class="col-md-6 col-lg-4 mb-4">
                  <div class="card">
                      <div class="card-header d-flex justify-content-between align-items-center">
                          <h6 class="mb-0">Pedido #<?= $order['order_number'] ?></h6>
                          <span class="badge bg-status-<?= $order['status'] ?>">
                              <?= getStatusText($order['status']) ?>
                          </span>
                      </div>
                      <div class="card-body">
                          <p class="mb-1"><strong>Cliente:</strong> <?= $order['customer_name'] ?></p>
                          <p class="mb-1"><strong>Telefone:</strong> <?= formatPhone($order['phone']) ?></p>
                          
                          <?php if ($order['delivery_method'] === 'delivery'): ?>
                              <p class="mb-2"><strong>Endereço:</strong> <?= $order['address'] ?></p>
                          <?php endif; ?>

                          <hr>
                          <h6>Itens:</h6>
                          <?php foreach ($items as $item): ?>
                              <div class="d-flex justify-content-between small">
                                  <span><?= $item['quantity'] ?>x <?= $item['name'] ?></span>
                                  <span>R$ <?= number_format($item['item_total'], 2, ',', '.') ?></span>
                              </div>
                              <?php if (!empty($item['options'])): ?>
                                  <ul class="list-unstyled small ms-3 mb-1">
                                      <?php foreach ($item['options'] as $option): ?>
                                          <li>- <?= $option['name'] ?> (<?= $option['group_name'] ?>) <?= $option['price_adjustment'] > 0 ? '(+R$ ' . number_format($option['price_adjustment'], 2, ',', '.') . ')' : '' ?></li>
                                      <?php endforeach; ?>
                                  </ul>
                              <?php endif; ?>
                          <?php endforeach; ?>

                          <hr>
                          <div class="d-flex justify-content-between">
                              <span>Subtotal:</span>
                              <span>R$ <?= number_format($order['subtotal'] + $order['discount_amount'], 2, ',', '.') ?></span>
                          </div>
                          <?php if ($order['discount_amount'] > 0): ?>
                              <div class="d-flex justify-content-between text-success">
                                  <span>Desconto (<?= $order['coupon_code'] ?>):</span>
                                  <span>- R$ <?= number_format($order['discount_amount'], 2, ',', '.') ?></span>
                              </div>
                          <?php endif; ?>
                          <?php if ($order['delivery_fee'] > 0): ?>
                              <div class="d-flex justify-content-between">
                                  <span>Taxa de entrega:</span>
                                  <span>R$ <?= number_format($order['delivery_fee'], 2, ',', '.') ?></span>
                              </div>
                          <?php endif; ?>
                          <div class="d-flex justify-content-between font-weight-bold">
                              <strong>Total:</strong>
                              <strong>R$ <?= number_format($order['total'], 2, ',', '.') ?></strong>
                          </div>

                          <div class="mt-3">
                              <small class="text-muted">
                                  Pagamento: <?= ucfirst($order['payment_method']) ?>
                                  <?php if ($order['payment_method'] === 'pix'): ?>
                                      - <?= $order['pix_paid'] ? 'Pago' : 'Pendente' ?>
                                  <?php endif; ?>
                              </small>
                          </div>

                          <div class="mt-3">
                              <select class="form-select form-select-sm" onchange="updateOrderStatus(<?= $order['id'] ?>, this.value)">
                                  <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Pendente</option>
                                  <option value="confirmed" <?= $order['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmado</option>
                                  <option value="preparing" <?= $order['status'] === 'preparing' ? 'selected' : '' ?>>Preparando</option>
                                  <option value="ready" <?= $order['status'] === 'ready' ? 'selected' : '' ?>>Pronto</option>
                                  <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : '' ?>>Entregue</option>
                                  <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelado</option>
                              </select>
                          </div>
                      </div>
                      <div class="card-footer small text-muted">
                          Criado em: <?= date('d/m/Y H:i', strtotime($order['created_at'])) ?>
                      </div>
                  </div>
              </div>
          <?php endforeach; ?>
      <?php endif; ?>
  </div>
  <script>
      async function updateOrderStatus(orderId, status) {
          try {
              const response = await fetch('../api/update-order-status.php', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({
                      order_id: orderId,
                      status: status
                  })
              });

              const result = await response.json();
              
              if (result.success) {
                  location.reload();
              } else {
                  alert('Erro ao atualizar status: ' + result.error);
              }
          } catch (error) {
              console.error('Erro:', error);
              alert('Erro de conexão');
          }
      }
  </script>
</div>

<?php require_once 'includes/footer.php'; // Includes footer ?>
