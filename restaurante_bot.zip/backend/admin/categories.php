<?php
require_once 'includes/header.php';

$establishment_id = $admin_establishment_id;

// Buscar categorias diretamente do banco
$categories_query = "SELECT * FROM categories WHERE establishment_id = :establishment_id ORDER BY sort_order, name";
$categories_stmt = $db->prepare($categories_query);
$categories_stmt->bindParam(':establishment_id', $establishment_id);
$categories_stmt->execute();
$categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="p-3 p-md-4">
<div class="d-flex justify-content-between align-items-center gap-2 mb-3">
    <h5 class="fw-semibold text-dark mb-0">Categorias</h5>
    <button class="btn btn-outline-secondary d-flex align-items-center gap-2 py-2 px-2 mb-0" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="resetCategoryForm()">
        <i class="bi bi-plus-lg fs-5"></i>
        <span class="d-none d-sm-inline">Adicionar</span>
    </button>
</div>
<div class="table-responsive bg-white rounded-lg shadow-md p-3 mb-4">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Ícone</th>
                <th>Ordem</th>
                <th>Ativo</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody id="categoriesTableBody">
            <?php if (empty($categories)): ?>
                <tr><td colspan="6" class="text-center">Nenhuma categoria encontrada.</td></tr>
            <?php else: ?>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?= htmlspecialchars($category['id']) ?></td>
                        <td><?= htmlspecialchars($category['name']) ?></td>
                        <td><?= htmlspecialchars($category['icon']) ?></td>
                        <td><?= htmlspecialchars($category['sort_order']) ?></td>
                        <td><span class="badge bg-<?= $category['active'] ? 'success' : 'danger' ?>"><?= $category['active'] ? 'Sim' : 'Não' ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick='editCategory(<?= json_encode($category) ?>)'>
                                <i class="bi bi-pencil"></i> Editar
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteCategory(<?= $category['id'] ?>)">
                                <i class="bi bi-trash"></i> Excluir
                            </button>
                            <a href="products.php?establishment_id=<?= $establishment_id ?>&category_id=<?= $category['id'] ?>" class="btn btn-sm btn-info">
                                <i class="bi bi-box-seam"></i> Produtos
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<!-- O restante do HTML e JS para modal e edição permanece, mas remova o fetchCategories e a chamada AJAX -->

<!-- Category Modal -->
<div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="categoryModalLabel">Adicionar/Editar Categoria</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="categoryForm">
                    <input type="hidden" id="categoryId" name="id">
                    <input type="hidden" id="establishmentId" name="establishment_id" value="<?= $establishment_id ?>">
                    
                    <div class="mb-3">
                        <label for="categoryName" class="form-label">Nome da Categoria *</label>
                        <input type="text" class="form-control" id="categoryName" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="categoryIcon" class="form-label">Ícone (Emoji ou URL de Imagem)</label>
                        <input type="text" class="form-control" id="categoryIcon" name="icon" placeholder="Ex: 🍔 ou https://example.com/icon.png">
                    </div>
                    <div class="mb-3">
                        <label for="categorySortOrder" class="form-label">Ordem de Exibição</label>
                        <input type="number" class="form-control" id="categorySortOrder" name="sort_order" value="0">
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="categoryActive" name="active" checked>
                        <label class="form-check-label" for="categoryActive">
                            Ativo
                        </label>
                    </div>
                    <div id="categoryFormMessage" class="alert" style="display:none;"></div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="saveCategory()">Salvar Categoria</button>
            </div>
        </div>
    </div>
</div>

<script>
    const API_BASE_URL = '../api/admin/categories'; // Adjust if your API is in a different path
    const ESTABLISHMENT_ID = <?php echo json_encode($establishment_id); ?>;

    document.addEventListener('DOMContentLoaded', fetchCategories);

    async function fetchCategories() {
        try {
            const response = await fetch(`${API_BASE_URL}/get.php?establishment_id=${ESTABLISHMENT_ID}`);
            const result = await response.json();
            const tableBody = document.getElementById('categoriesTableBody');
            tableBody.innerHTML = ''; // Clear existing rows

            if (result.success && result.categories.length > 0) {
                result.categories.forEach(category => {
                    const row = `
                        <tr>
                            <td>${category.id}</td>
                            <td>${category.name}</td>
                            <td>${category.icon}</td>
                            <td>${category.sort_order}</td>
                            <td><span class="badge bg-${category.active ? 'success' : 'danger'}">${category.active ? 'Sim' : 'Não'}</span></td>
                            <td>
                                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick='editCategory(${JSON.stringify(category)})'>
                                    <i class="bi bi-pencil"></i> Editar
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteCategory(${category.id})">
                                    <i class="bi bi-trash"></i> Excluir
                                </button>
                                <a href="products.php?establishment_id=${ESTABLISHMENT_ID}&category_id=${category.id}" class="btn btn-sm btn-info">
                                    <i class="bi bi-box-seam"></i> Produtos
                                </a>
                            </td>
                        </tr>
                    `;
                    tableBody.innerHTML += row;
                });
            } else {
                tableBody.innerHTML = `<tr><td colspan="6" class="text-center">${result.error || 'Nenhuma categoria encontrada.'}</td></tr>`;
            }
        } catch (error) {
            console.error('Error fetching categories:', error);
            document.getElementById('categoriesTableBody').innerHTML = `<tr><td colspan="6" class="text-center text-danger">Erro ao carregar categorias.</td></tr>`;
        }
    }

    function resetCategoryForm() {
        document.getElementById('categoryForm').reset();
        document.getElementById('categoryId').value = '';
        document.getElementById('categoryModalLabel').textContent = 'Adicionar Categoria';
        document.getElementById('categoryActive').checked = true;
        document.getElementById('categorySortOrder').value = 0;
        document.getElementById('categoryFormMessage').style.display = 'none';
    }

    function editCategory(category) {
        document.getElementById('categoryId').value = category.id;
        document.getElementById('categoryName').value = category.name;
        document.getElementById('categoryIcon').value = category.icon;
        document.getElementById('categorySortOrder').value = category.sort_order;
        document.getElementById('categoryActive').checked = category.active;
        document.getElementById('categoryModalLabel').textContent = 'Editar Categoria';
        document.getElementById('categoryFormMessage').style.display = 'none';
    }

    async function saveCategory() {
        const form = document.getElementById('categoryForm');
        const formData = new FormData(form);
        const categoryId = formData.get('id');
        const url = categoryId ? `${API_BASE_URL}/update.php` : `${API_BASE_URL}/add.php`;

        const data = {
            id: categoryId ? parseInt(categoryId) : undefined,
            establishment_id: ESTABLISHMENT_ID,
            name: formData.get('name'),
            icon: formData.get('icon'),
            sort_order: parseInt(formData.get('sort_order')),
            active: formData.get('active') === 'on' ? true : false
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });

            const result = await response.json();
            const messageDiv = document.getElementById('categoryFormMessage');
            messageDiv.style.display = 'block';

            if (result.success) {
                messageDiv.className = 'alert alert-success';
                messageDiv.textContent = result.message;
                setTimeout(() => {
                    const modal = bootstrap.Modal.getInstance(document.getElementById('categoryModal'));
                    modal.hide();
                    fetchCategories(); // Reload categories
                }, 1000);
            } else {
                messageDiv.className = 'alert alert-danger';
                messageDiv.textContent = result.error;
            }
        } catch (error) {
            console.error('Error saving category:', error);
            const messageDiv = document.getElementById('categoryFormMessage');
            messageDiv.className = 'alert alert-danger';
            messageDiv.textContent = 'Erro de conexão. Tente novamente.';
        }
    }

    async function deleteCategory(categoryId) {
        if (!confirm('Tem certeza que deseja excluir esta categoria? Todos os produtos associados a ela devem ser excluídos ou reatribuídos primeiro.')) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/delete.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: categoryId,
                    establishment_id: ESTABLISHMENT_ID
                }),
            });

            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                fetchCategories(); // Reload categories
            } else {
                alert('Erro ao excluir categoria: ' + result.error);
            }
        } catch (error) {
            console.error('Error deleting category:', error);
            alert('Erro de conexão');
        }
    }
</script>

<?php require_once 'includes/footer.php'; // Includes footer ?>
      </div>
    </main>
  </div>
</div>
