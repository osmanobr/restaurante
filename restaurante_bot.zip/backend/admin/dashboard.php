<?php
require_once 'includes/header.php'; // Includes header and sets $admin_establishment_id

// Buscar dados de resumo
// Total de pedidos
$stmt = $db->prepare("SELECT COUNT(*) as total FROM orders WHERE establishment_id = :establishment_id");
$stmt->bindParam(':establishment_id', $admin_establishment_id);
$stmt->execute();
$total_orders = $stmt->fetchColumn();

// Total de clientes
$stmt = $db->prepare("SELECT COUNT(*) as total FROM customers WHERE establishment_id = :establishment_id");
$stmt->bindParam(':establishment_id', $admin_establishment_id);
$stmt->execute();
$total_customers = $stmt->fetchColumn();

// Total de cupons
$stmt = $db->prepare("SELECT COUNT(*) as total FROM coupons WHERE establishment_id = :establishment_id");
$stmt->bindParam(':establishment_id', $admin_establishment_id);
$stmt->execute();
$total_coupons = $stmt->fetchColumn();

// Pedidos por status
$stmt = $db->prepare("SELECT status, COUNT(*) as total FROM orders WHERE establishment_id = :establishment_id GROUP BY status");
$stmt->bindParam(':establishment_id', $admin_establishment_id);
$stmt->execute();
$status_data = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

?>
<div class="p-3 p-md-4">
    <div class="d-flex align-items-center mb-4">
        <h5 class="fw-semibold text-dark mb-0">Dashboard</h5>
    </div>
    <!-- Cards de Resumo -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow-md p-6 flex items-center">
            <i class="bi bi-receipt text-4xl text-blue-500 mr-4"></i>
            <div>
                <div class="text-2xl font-bold"><?php echo $total_orders; ?></div>
                <div class="text-gray-600">Pedidos</div>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow-md p-6 flex items-center">
            <i class="bi bi-people text-4xl text-green-500 mr-4"></i>
            <div>
                <div class="text-2xl font-bold"><?php echo $total_customers; ?></div>
                <div class="text-gray-600">Clientes</div>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow-md p-6 flex items-center">
            <i class="bi bi-tag text-4xl text-yellow-500 mr-4"></i>
            <div>
                <div class="text-2xl font-bold"><?php echo $total_coupons; ?></div>
                <div class="text-gray-600">Cupons</div>
            </div>
        </div>
    </div>
    <!-- Gráfico de Pedidos por Status -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 class="text-xl font-semibold mb-4 text-gray-800">Pedidos por Status</h2>
        <canvas id="ordersStatusChart" height="100"></canvas>
    </div>
    <!-- Últimos Pedidos (responsivo) -->
    <div class="bg-white rounded-lg shadow-md p-6 overflow-x-auto">
        <h2 class="text-xl font-semibold mb-4 text-gray-800">Últimos Pedidos</h2>
        <table class="min-w-full table-auto">
            <thead>
                <tr class="bg-gray-100 text-gray-600 uppercase text-sm">
                    <th class="py-2 px-4">ID</th>
                    <th class="py-2 px-4">Cliente</th>
                    <th class="py-2 px-4">Status</th>
                    <th class="py-2 px-4">Total</th>
                    <th class="py-2 px-4">Data</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $db->prepare("SELECT o.id, c.name as customer_name, o.status, o.total, o.created_at FROM orders o JOIN customers c ON o.customer_id = c.id WHERE o.establishment_id = :establishment_id ORDER BY o.created_at DESC LIMIT 10");
                $stmt->bindParam(':establishment_id', $admin_establishment_id);
                $stmt->execute();
                $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (empty($orders)) {
                    echo '<tr><td colspan="5" class="text-center py-4">Nenhum pedido encontrado.</td></tr>';
                } else {
                    foreach ($orders as $order) {
                        echo '<tr>';
                        echo '<td class="py-2 px-4">' . $order['id'] . '</td>';
                        echo '<td class="py-2 px-4">' . htmlspecialchars($order['customer_name']) . '</td>';
                        echo '<td class="py-2 px-4">' . ucfirst($order['status']) . '</td>';
                        echo '<td class="py-2 px-4">R$ ' . number_format($order['total'], 2, ',', '.') . '</td>';
                        echo '<td class="py-2 px-4">' . date('d/m/Y H:i', strtotime($order['created_at'])) . '</td>';
                        echo '</tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
<!-- Chart.js para o gráfico -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('ordersStatusChart').getContext('2d');
        const data = {
            labels: <?php echo json_encode(array_keys($status_data)); ?>,
            datasets: [{
                label: 'Pedidos',
                data: <?php echo json_encode(array_values($status_data)); ?>,
                backgroundColor: [
                    '#60a5fa', // azul
                    '#34d399', // verde
                    '#fbbf24', // amarelo
                    '#f87171', // vermelho
                    '#a78bfa', // roxo
                    '#f472b6', // rosa
                    '#facc15', // dourado
                ],
                borderRadius: 8,
            }]
        };
        new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false },
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    });
</script>
<?php require_once 'includes/footer.php'; ?>
