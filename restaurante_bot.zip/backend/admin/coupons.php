<?php
require_once 'includes/header.php'; // Includes header and sets $admin_establishment_id

$establishment_id = $admin_establishment_id;

// Fetch all coupons for the current establishment
$query = "SELECT * FROM coupons WHERE establishment_id = :establishment_id ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':establishment_id', $establishment_id);
$stmt->execute();
$coupons = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="p-3 p-md-4">
  <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
      <h5 class="fw-semibold text-dark mb-0">Cupons</h5>
      <button class="btn btn-outline-secondary d-flex align-items-center gap-2 py-2 px-2 mb-0" data-bs-toggle="modal" data-bs-target="#couponModal" onclick="resetCouponForm()">
          <i class="bi bi-plus-lg fs-5"></i>
          <span class="d-none d-sm-inline">Adicionar</span>
      </button>
  </div>
  <div class="table-responsive bg-white rounded-lg shadow-md p-3 mb-4">
      <table class="table table-striped table-hover">
          <thead>
              <tr>
                  <th>ID</th>
                  <th>Código</th>
                  <th>Descrição</th>
                  <th>Tipo</th>
                  <th>Valor</th>
                  <th>Min. Pedido</th>
                  <th>Usos (Max)</th>
                  <th>Expira Em</th>
                  <th>Ativo</th>
                  <th>Ações</th>
              </tr>
          </thead>
          <tbody>
              <?php if (empty($coupons)): ?>
                  <tr>
                      <td colspan="10" class="text-center">Nenhum cupom encontrado para este estabelecimento.</td>
                  </tr>
              <?php else: ?>
                  <?php foreach ($coupons as $coupon): ?>
                      <tr>
                          <td><?= $coupon['id'] ?></td>
                          <td><strong><?= htmlspecialchars($coupon['code']) ?></strong></td>
                          <td><?= htmlspecialchars($coupon['description']) ?></td>
                          <td><?= ucfirst($coupon['type']) ?></td>
                          <td>R$ <?= number_format($coupon['value'], 2, ',', '.') ?></td>
                          <td>R$ <?= number_format($coupon['min_order_value'], 2, ',', '.') ?></td>
                          <td><?= $coupon['uses_count'] ?> (<?= $coupon['max_uses'] ?? '∞' ?>)</td>
                          <td><?= $coupon['expiry_date'] ? date('d/m/Y', strtotime($coupon['expiry_date'])) : 'Nunca' ?></td>
                          <td>
                              <span class="badge bg-<?= $coupon['active'] ? 'success' : 'danger' ?>">
                                  <?= $coupon['active'] ? 'Sim' : 'Não' ?>
                              </span>
                          </td>
                          <td>
                              <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#couponModal" onclick="editCoupon(<?= htmlspecialchars(json_encode($coupon)) ?>)">
                                  <i class="bi bi-pencil"></i> Editar
                              </button>
                              <button class="btn btn-sm btn-danger" onclick="deleteCoupon(<?= $coupon['id'] ?>)">
                                  <i class="bi bi-trash"></i> Excluir
                              </button>
                          </td>
                      </tr>
                  <?php endforeach; ?>
              <?php endif; ?>
          </tbody>
      </table>
  </div>
  <!-- Coupon Modal -->
  <div class="modal fade" id="couponModal" tabindex="-1" aria-labelledby="couponModalLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="couponModalLabel">Adicionar/Editar Cupom</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <form id="couponForm">
                      <input type="hidden" id="couponId" name="id">
                      <input type="hidden" id="establishmentId" name="establishment_id" value="<?= $admin_establishment_id ?>">
                      
                      <div class="mb-3">
                          <label for="couponCode" class="form-label">Código do Cupom *</label>
                          <input type="text" class="form-control" id="couponCode" name="code" required>
                      </div>
                      <div class="mb-3">
                          <label for="couponDescription" class="form-label">Descrição</label>
                          <textarea class="form-control" id="couponDescription" name="description" rows="2"></textarea>
                      </div>
                      <div class="mb-3">
                          <label for="couponType" class="form-label">Tipo *</label>
                          <select class="form-select" id="couponType" name="type" required>
                              <option value="percentage">Porcentagem (%)</option>
                              <option value="fixed">Valor Fixo (R$)</option>
                          </select>
                      </div>
                      <div class="mb-3">
                          <label for="couponValue" class="form-label">Valor *</label>
                          <input type="number" step="0.01" class="form-control" id="couponValue" name="value" required>
                      </div>
                      <div class="mb-3">
                          <label for="couponMinOrderValue" class="form-label">Valor Mínimo do Pedido</label>
                          <input type="number" step="0.01" class="form-control" id="couponMinOrderValue" name="min_order_value" value="0.00">
                      </div>
                      <div class="mb-3">
                          <label for="couponMaxUses" class="form-label">Máximo de Usos (deixe em branco para ilimitado)</label>
                          <input type="number" class="form-control" id="couponMaxUses" name="max_uses">
                      </div>
                      <div class="mb-3">
                          <label for="couponExpiryDate" class="form-label">Data de Expiração (deixe em branco para nunca expirar)</label>
                          <input type="datetime-local" class="form-control" id="couponExpiryDate" name="expiry_date">
                      </div>
                      <div class="form-check mb-3">
                          <input class="form-check-input" type="checkbox" id="couponActive" name="active" checked>
                          <label class="form-check-label" for="couponActive">
                              Ativo
                          </label>
                      </div>
                      <div id="couponFormMessage" class="alert" style="display:none;"></div>
                  </form>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                  <button type="button" class="btn btn-primary" onclick="saveCoupon()">Salvar Cupom</button>
              </div>
          </div>
      </div>
  </div>
</div>

<script>
    const API_BASE_URL = '../api'; // Adjust if your API is in a different path

    function resetCouponForm() {
        document.getElementById('couponForm').reset();
        document.getElementById('couponId').value = '';
        document.getElementById('couponModalLabel').textContent = 'Adicionar Cupom';
        document.getElementById('couponActive').checked = true; // Default to active
        document.getElementById('couponFormMessage').style.display = 'none';
    }

    function editCoupon(coupon) {
        document.getElementById('couponId').value = coupon.id;
        document.getElementById('couponCode').value = coupon.code;
        document.getElementById('couponDescription').value = coupon.description;
        document.getElementById('couponType').value = coupon.type;
        document.getElementById('couponValue').value = coupon.value;
        document.getElementById('couponMinOrderValue').value = coupon.min_order_value;
        document.getElementById('couponMaxUses').value = coupon.max_uses !== null ? coupon.max_uses : '';
        document.getElementById('couponExpiryDate').value = coupon.expiry_date ? coupon.expiry_date.substring(0, 16) : ''; // Format for datetime-local
        document.getElementById('couponActive').checked = coupon.active;
        document.getElementById('couponModalLabel').textContent = 'Editar Cupom';
        document.getElementById('couponFormMessage').style.display = 'none';
    }

    async function saveCoupon() {
        const form = document.getElementById('couponForm');
        const formData = new FormData(form);
        const couponId = formData.get('id');
        const url = couponId ? `${API_BASE_URL}/update-coupon.php` : `${API_BASE_URL}/add-coupon.php`;

        const data = {
            id: couponId ? parseInt(couponId) : undefined,
            establishment_id: parseInt(formData.get('establishment_id')),
            code: formData.get('code'),
            description: formData.get('description'),
            type: formData.get('type'),
            value: parseFloat(formData.get('value')),
            min_order_value: parseFloat(formData.get('min_order_value')),
            max_uses: formData.get('max_uses') !== '' ? parseInt(formData.get('max_uses')) : null,
            expiry_date: formData.get('expiry_date') !== '' ? formData.get('expiry_date') : null,
            active: formData.get('active') === 'on' ? true : false
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });

            const result = await response.json();
            const messageDiv = document.getElementById('couponFormMessage');
            messageDiv.style.display = 'block';

            if (result.success) {
                messageDiv.className = 'alert alert-success';
                messageDiv.textContent = result.message;
                setTimeout(() => {
                    const modal = bootstrap.Modal.getInstance(document.getElementById('couponModal'));
                    modal.hide();
                    location.reload();
                }, 1000);
            } else {
                messageDiv.className = 'alert alert-danger';
                messageDiv.textContent = result.error;
            }
        } catch (error) {
            console.error('Error:', error);
            const messageDiv = document.getElementById('couponFormMessage');
            messageDiv.className = 'alert alert-danger';
            messageDiv.textContent = 'Erro de conexão. Tente novamente.';
        }
    }

    async function deleteCoupon(couponId) {
        if (!confirm('Tem certeza que deseja excluir este cupom?')) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/delete-coupon.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: couponId,
                    establishment_id: <?= $admin_establishment_id ?>
                }),
            });

            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                location.reload();
            } else {
                alert('Erro ao excluir cupom: ' + result.error);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Erro de conexão');
        }
    }
</script>

<?php require_once 'includes/footer.php'; // Includes footer ?>
