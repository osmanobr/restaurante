<?php
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([]);
    exit;
}
require_once '../config/database.php';
$db = (new Database())->getConnection();

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$res = [];
if ($q !== '') {
    $termo = preg_replace('/\D/', '', $q);
    $stmt = $db->prepare('SELECT id, name, phone FROM customers WHERE name LIKE ? OR REPLACE(REPLACE(REPLACE(REPLACE(phone, "-", ""), "(", ""), ")", ""), " ", "") LIKE ? LIMIT 10');
    $stmt->execute(['%' . $q . '%', '%' . $termo . '%']);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
        $res[] = ['id' => $u['id'], 'label' => $u['name'] . ' (' . $u['phone'] . ')'];
    }
}
echo json_encode($res); 