<?php
class EstablishmentManager {
    private $db;
    
    public function __construct($database) {
        $this->db = $database->getConnection();
    }
    
    public function getEstablishmentByPhone($phone) {
        $query = "SELECT * FROM establishments WHERE phone = :phone AND active = 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':phone', $phone);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getEstablishmentById($id) {
        $query = "SELECT * FROM establishments WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllEstablishments() {
        $query = "SELECT * FROM establishments ORDER BY name ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addEstablishment($name, $description, $address, $phone, $whatsapp, $email, $logo, $primary_color, $secondary_color, $delivery_fee, $min_order, $pix_key, $pix_name, $pix_city) {
        $query = "INSERT INTO establishments (name, description, address, phone, whatsapp, email, logo, primary_color, secondary_color, delivery_fee, min_order, pix_key, pix_name, pix_city) 
                  VALUES (:name, :description, :address, :phone, :whatsapp, :email, :logo, :primary_color, :secondary_color, :delivery_fee, :min_order, :pix_key, :pix_name, :pix_city)";
        $stmt = $this->db->prepare($query);

        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':whatsapp', $whatsapp);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':logo', $logo);
        $stmt->bindParam(':primary_color', $primary_color);
        $stmt->bindParam(':secondary_color', $secondary_color);
        $stmt->bindParam(':delivery_fee', $delivery_fee);
        $stmt->bindParam(':min_order', $min_order);
        $stmt->bindParam(':pix_key', $pix_key);
        $stmt->bindParam(':pix_name', $pix_name);
        $stmt->bindParam(':pix_city', $pix_city);

        if ($stmt->execute()) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    public function updateEstablishment($id, $name, $description, $address, $phone, $whatsapp, $email, $logo, $primary_color, $secondary_color, $delivery_fee, $min_order, $pix_key, $pix_name, $pix_city) {
        $query = "UPDATE establishments SET 
                    name = :name, 
                    description = :description, 
                    address = :address, 
                    phone = :phone, 
                    whatsapp = :whatsapp, 
                    email = :email, 
                    logo = :logo, 
                    primary_color = :primary_color, 
                    secondary_color = :secondary_color, 
                    delivery_fee = :delivery_fee, 
                    min_order = :min_order, 
                    pix_key = :pix_key, 
                    pix_name = :pix_name, 
                    pix_city = :pix_city
                  WHERE id = :id";
        $stmt = $this->db->prepare($query);

        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':whatsapp', $whatsapp);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':logo', $logo);
        $stmt->bindParam(':primary_color', $primary_color);
        $stmt->bindParam(':secondary_color', $secondary_color);
        $stmt->bindParam(':delivery_fee', $delivery_fee);
        $stmt->bindParam(':min_order', $min_order);
        $stmt->bindParam(':pix_key', $pix_key);
        $stmt->bindParam(':pix_name', $pix_name);
        $stmt->bindParam(':pix_city', $pix_city);

        return $stmt->execute();
    }

    public function toggleEstablishmentActiveStatus($id, $active) {
        $query = "UPDATE establishments SET active = :active WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);
        return $stmt->execute();
    }
    
    public function getEstablishmentMenu($establishment_id) {
        // Buscar categorias
        $categories_query = "SELECT * FROM categories WHERE establishment_id = :establishment_id AND active = 1 ORDER BY sort_order";
        $categories_stmt = $this->db->prepare($categories_query);
        $categories_stmt->bindParam(':establishment_id', $establishment_id);
        $categories_stmt->execute();
        $categories = $categories_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $menu = [];
        foreach ($categories as $category) {
            // Buscar produtos da categoria
            $products_query = "SELECT * FROM products WHERE category_id = :category_id AND active = 1 ORDER BY sort_order";
            $products_stmt = $this->db->prepare($products_query);
            $products_stmt->bindParam(':category_id', $category['id']);
            $products_stmt->execute();
            $products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $products_with_options = [];
            foreach ($products as $product) {
                $product['price'] = floatval($product['price']);
                $product['options_groups'] = $this->getProductOptionGroups($product['id']);
                $products_with_options[] = $product;
            }

            $menu[] = [
                'id' => $category['id'],
                'name' => $category['name'],
                'icon' => $category['icon'],
                'products' => $products_with_options
            ];
        }
        
        return $menu;
    }
    
    public function getPaymentMethods($establishment_id) {
        $query = "SELECT * FROM payment_methods WHERE establishment_id = :establishment_id AND active = 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':establishment_id', $establishment_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getProduct($product_id, $establishment_id) {
        $query = "SELECT p.*, c.name as category_name 
                  FROM products p 
                  JOIN categories c ON p.category_id = c.id 
                  WHERE p.id = :product_id AND p.establishment_id = :establishment_id AND p.active = 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->bindParam(':establishment_id', $establishment_id);
        $stmt->execute();
        
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            $product['price'] = floatval($product['price']);
            $product['options_groups'] = $this->getProductOptionGroups($product['id']);
        }
        
        return $product;
    }

    public function getProductOptionGroups($product_id) {
        $groups_query = "SELECT * FROM product_option_groups WHERE product_id = :product_id AND active = 1 ORDER BY sort_order";
        $groups_stmt = $this->db->prepare($groups_query);
        $groups_stmt->bindParam(':product_id', $product_id);
        $groups_stmt->execute();
        $groups = $groups_stmt->fetchAll(PDO::FETCH_ASSOC);

        $groups_with_options = [];
        foreach ($groups as $group) {
            $options_query = "SELECT * FROM product_options WHERE group_id = :group_id AND active = 1 ORDER BY sort_order";
            $options_stmt = $this->db->prepare($options_query);
            $options_stmt->bindParam(':group_id', $group['id']);
            $options_stmt->execute();
            $options = $options_stmt->fetchAll(PDO::FETCH_ASSOC);

            $group['options'] = array_map(function($option) {
                $option['price_adjustment'] = floatval($option['price_adjustment']);
                return $option;
            }, $options);
            $groups_with_options[] = $group;
        }
        return $groups_with_options;
    }

    public function getOptionById($option_id) {
        $query = "SELECT po.*, pog.type as group_type, pog.name as group_name
                  FROM product_options po
                  JOIN product_option_groups pog ON po.group_id = pog.id
                  WHERE po.id = :option_id AND po.active = 1";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':option_id', $option_id);
        $stmt->execute();
        $option = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($option) {
            $option['price_adjustment'] = floatval($option['price_adjustment']);
        }
        return $option;
    }
}

// Função para obter o ID do estabelecimento
function getEstablishmentId() {
    // Implemente a lógica para obter o ID do estabelecimento
    // Isso pode vir de uma sessão, de um parâmetro de URL, de um subdomínio, etc.
    // Por enquanto, vamos usar um valor fixo para demonstração.
    // Em um ambiente real, você precisaria de uma lógica mais robusta.
    return 1; // Exemplo: Retorna o ID do primeiro estabelecimento
}

// Função para obter o caminho base para uploads
function getUploadBasePath() {
    // Retorna o caminho base onde as imagens serão salvas
    // Certifique-se de que esta pasta tenha permissões de escrita
    return dirname(__DIR__) . '/public/uploads/';
}

// Função para obter a URL base para acesso público às imagens
function getUploadBaseUrl() {
    // Retorna a URL base para acessar as imagens via web
    // Ajuste 'http://localhost/osmano/restaurante_bot/' para a URL base do seu projeto
    return 'http://localhost/osmano/restaurante_bot/backend/public/uploads/';
}

?>
