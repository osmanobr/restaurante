<?php
require_once __DIR__ . '/paths.php';
class Auth {
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }

    public function loginAdmin($username, $password) {
        $db = (new Database())->getConnection();
        $query = "SELECT * FROM admin_users WHERE username = :username";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && self::verifyPassword($password, $admin['password_hash'])) {
            return $admin;
        }
        return false;
    }
}
?>
