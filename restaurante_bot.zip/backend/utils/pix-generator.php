<?php
class PixGenerator {
    private $merchant_name = 'RESTAURANTE EXEMPLO LTDA';
    private $merchant_city = 'SAO PAULO';
    private $pix_key = '36c4b8c5-4c5e-4c5e-8c5e-4c5e4c5e4c5e'; // Chave PIX do restaurante

    public function generatePixCode($amount, $order_id) {
        // Payload do PIX seguindo o padrão EMV
        $payload = '';
        
        // Payload Format Indicator
        $payload .= $this->generateTLV('00', '01');
        
        // Point of Initiation Method (12 = dinâmico)
        $payload .= $this->generateTLV('01', '12');
        
        // Merchant Account Information
        $merchant_info = '';
        $merchant_info .= $this->generateTLV('00', 'BR.GOV.BCB.PIX');
        $merchant_info .= $this->generateTLV('01', $this->pix_key);
        $payload .= $this->generateTLV('26', $merchant_info);
        
        // Merchant Category Code
        $payload .= $this->generateTLV('52', '0000');
        
        // Transaction Currency (986 = BRL)
        $payload .= $this->generateTLV('53', '986');
        
        // Transaction Amount
        $amount_str = number_format($amount, 2, '.', '');
        $payload .= $this->generateTLV('54', $amount_str);
        
        // Country Code
        $payload .= $this->generateTLV('58', 'BR');
        
        // Merchant Name
        $payload .= $this->generateTLV('59', $this->merchant_name);
        
        // Merchant City
        $payload .= $this->generateTLV('60', $this->merchant_city);
        
        // Additional Data Field Template
        $additional_info = '';
        $additional_info .= $this->generateTLV('05', substr($order_id, 0, 25)); // Máximo 25 caracteres
        $payload .= $this->generateTLV('62', $additional_info);
        
        // CRC16 - adicionar placeholder
        $payload .= '6304';
        
        // Calcular CRC16
        $crc = $this->calculateCRC16($payload);
        $crc_hex = strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
        
        // Substituir placeholder pelo CRC real
        $payload = substr($payload, 0, -4) . $crc_hex;
        
        return $payload;
    }
    
    private function generateTLV($tag, $value) {
        $length = str_pad(strlen($value), 2, '0', STR_PAD_LEFT);
        return $tag . $length . $value;
    }
    
    private function calculateCRC16($data) {
        $crc = 0xFFFF;
        
        for ($i = 0; $i < strlen($data); $i++) {
            $crc ^= ord($data[$i]) << 8;
            
            for ($j = 0; $j < 8; $j++) {
                if ($crc & 0x8000) {
                    $crc = ($crc << 1) ^ 0x1021;
                } else {
                    $crc = $crc << 1;
                }
                $crc &= 0xFFFF;
            }
        }
        
        return $crc;
    }
}
?>
