<?php
// Arquivo para testar a geração de PIX
require_once '../utils/pix-generator.php';

$pix_generator = new PixGenerator();
$pix_code = $pix_generator->generatePixCode(25.90, 'TESTE123');

echo "Código PIX gerado:\n";
echo $pix_code . "\n\n";

echo "Tamanho: " . strlen($pix_code) . " caracteres\n";

// Verificar se o código está no formato correto
if (substr($pix_code, 0, 4) === '0001' && substr($pix_code, -4, 4) !== '6304') {
    echo "✅ Código PIX válido!\n";
} else {
    echo "❌ Código PIX pode ter problemas\n";
}

// Mostrar estrutura do código
echo "\nEstrutura do código:\n";
echo "Início: " . substr($pix_code, 0, 10) . "...\n";
echo "Final: ..." . substr($pix_code, -10) . "\n";
?>
