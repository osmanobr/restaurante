<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['customer_id']) || !isset($input['establishment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Customer ID and Establishment ID are required']);
    exit;
}

$customer_id = $input['customer_id'];
$establishment_id = $input['establishment_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT id, phone, name, address, created_at FROM customers WHERE id = :customer_id AND establishment_id = :establishment_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':customer_id', $customer_id);
    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->execute();

    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($customer) {
        echo json_encode([
            'found' => true,
            'customer' => [
                'id' => (int)$customer['id'],
                'phone' => $customer['phone'],
                'name' => $customer['name'],
                'address' => $customer['address'],
                'member_since' => date('d/m/Y', strtotime($customer['created_at']))
            ]
        ]);
    } else {
        echo json_encode([
            'found' => false,
            'message' => 'Sessão de cliente inválida ou expirada.'
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
