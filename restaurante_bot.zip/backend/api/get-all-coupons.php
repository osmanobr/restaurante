<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!isset($_GET['establishment_id']) || empty($_GET['establishment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Establishment ID is required']);
    exit;
}

$establishment_id = $_GET['establishment_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT * FROM coupons WHERE establishment_id = :establishment_id ORDER BY created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->execute();

    $coupons = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formatted_coupons = array_map(function($coupon) {
        return [
            'id' => $coupon['id'],
            'code' => $coupon['code'],
            'description' => $coupon['description'],
            'type' => $coupon['type'],
            'value' => floatval($coupon['value']),
            'min_order_value' => floatval($coupon['min_order_value']),
            'max_uses' => $coupon['max_uses'] !== null ? (int)$coupon['max_uses'] : null,
            'uses_count' => (int)$coupon['uses_count'],
            'expiry_date' => $coupon['expiry_date'],
            'active' => (bool)$coupon['active'],
            'created_at' => date('d/m/Y H:i', strtotime($coupon['created_at']))
        ];
    }, $coupons);

    echo json_encode([
        'success' => true,
        'coupons' => $formatted_coupons,
        'total' => count($formatted_coupons)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
