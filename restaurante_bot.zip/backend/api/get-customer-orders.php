<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/establishment.php'; // Para buscar detalhes de produtos e opções, se necessário

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['customer_id']) || !isset($input['establishment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Customer ID and Establishment ID are required']);
    exit;
}

$customer_id = $input['customer_id'];
$establishment_id = $input['establishment_id'];

try {
    $database = new Database();
    $db = $database->getConnection();
    $establishment_manager = new EstablishmentManager($database);

    // Mapear status para mensagens amigáveis
    $status_messages = [
        'pending' => 'Aguardando confirmação',
        'confirmed' => 'Pedido confirmado',
        'preparing' => 'Preparando seu pedido',
        'ready' => 'Pedido pronto para retirada/entrega',
        'delivered' => 'Pedido entregue',
        'cancelled' => 'Pedido cancelado'
    ];

    // Buscar pedidos do cliente para o estabelecimento específico
    $query = "SELECT o.*, c.name as customer_name, c.phone, c.address 
              FROM orders o 
              JOIN customers c ON o.customer_id = c.id 
              WHERE o.customer_id = :customer_id AND o.establishment_id = :establishment_id
              ORDER BY o.created_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':customer_id', $customer_id);
    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->execute();

    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formatted_orders = [];
    foreach ($orders as $order) {
        // Decodificar itens JSON
        $items = json_decode($order['items'], true);
        
        // Formatar itens para incluir detalhes das opções
        $formatted_items = [];
        foreach ($items as $item) {
            $formatted_item = [
                'product_id' => $item['product_id'],
                'name' => $item['name'],
                'base_price' => floatval($item['base_price']),
                'quantity' => $item['quantity'],
                'item_total' => floatval($item['item_total']),
                'options' => []
            ];
            if (isset($item['options']) && is_array($item['options'])) {
                foreach ($item['options'] as $option) {
                    $formatted_item['options'][] = [
                        'id' => $option['id'],
                        'name' => $option['name'],
                        'price_adjustment' => floatval($option['price_adjustment']),
                        'group_name' => $option['group_name'] ?? '', // Adicionado para compatibilidade
                        'group_type' => $option['group_type'] ?? '' // Adicionado para compatibilidade
                    ];
                }
            }
            $formatted_items[] = $formatted_item;
        }

        $formatted_orders[] = [
            'id' => $order['id'],
            'order_number' => $order['order_number'],
            'total' => floatval($order['total']),
            'status' => $order['status'],
            'status_message' => $status_messages[$order['status']] ?? 'Status desconhecido',
            'payment_method' => $order['payment_method'],
            'delivery_method' => $order['delivery_method'],
            'created_at' => date('d/m/Y H:i', strtotime($order['created_at'])),
            'items' => $formatted_items,
            'delivery_fee' => floatval($order['delivery_fee']),
            'subtotal' => floatval($order['subtotal']),
            'pix_paid' => $order['pix_paid'] == 1,
            'discount_amount' => floatval($order['discount_amount']),
            'coupon_code' => $order['coupon_code']
        ];
    }

    echo json_encode([
        'success' => true,
        'orders' => $formatted_orders,
        'total_orders' => count($formatted_orders)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
