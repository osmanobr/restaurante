<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/establishment.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!isset($_GET['phone']) || empty($_GET['phone'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Phone parameter is required']);
    exit;
}

$phone = preg_replace('/\D/', '', $_GET['phone']);

if (strlen($phone) !== 11) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid phone number format']);
    exit;
}

try {
    $database = new Database();
    $establishment_manager = new EstablishmentManager($database);
    
    $establishment = $establishment_manager->getEstablishmentByPhone($phone);
    
    if (!$establishment) {
        http_response_code(404);
        echo json_encode(['error' => 'Establishment not found']);
        exit;
    }
    
    // Buscar menu
    $menu = $establishment_manager->getEstablishmentMenu($establishment['id']);
    
    // Buscar métodos de pagamento
    $payment_methods = $establishment_manager->getPaymentMethods($establishment['id']);
    
    // Métodos de entrega (padrão para todos)
    $delivery_methods = [
        [
            'id' => 'delivery',
            'name' => 'Entrega',
            'description' => 'Entregamos em sua casa',
            'time' => $establishment['delivery_time'],
            'price' => floatval($establishment['delivery_fee']),
            'icon' => '🚚'
        ],
        [
            'id' => 'pickup',
            'name' => 'Retirada',
            'description' => 'Retire no balcão',
            'time' => $establishment['pickup_time'],
            'price' => 0,
            'icon' => '🏪'
        ]
    ];
    
    echo json_encode([
        'success' => true,
        'establishment' => [
            'id' => $establishment['id'],
            'name' => $establishment['name'],
            'description' => $establishment['description'],
            'address' => $establishment['address'],
            'phone' => $establishment['phone'],
            'whatsapp' => $establishment['whatsapp'],
            'email' => $establishment['email'],
            'logo' => $establishment['logo'],
            'primary_color' => $establishment['primary_color'],
            'secondary_color' => $establishment['secondary_color'],
            'delivery_fee' => floatval($establishment['delivery_fee']),
            'min_order' => floatval($establishment['min_order']),
            'pix_key' => $establishment['pix_key'],
            'pix_name' => $establishment['pix_name'],
            'pix_city' => $establishment['pix_city']
        ],
        'menu' => $menu,
        'payment_methods' => array_map(function($method) {
            return [
                'id' => $method['method_type'],
                'name' => $method['name'],
                'icon' => $method['icon']
            ];
        }, $payment_methods),
        'delivery_methods' => $delivery_methods
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
