<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['order_id']) || empty($input['order_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Order ID is required']);
    exit;
}

$order_id = $input['order_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT id, order_number, pix_paid, status FROM orders WHERE id = :order_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();

    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        http_response_code(404);
        echo json_encode(['error' => 'Order not found']);
        exit;
    }

    // Simular verificação de pagamento PIX
    // Em produção, aqui você consultaria a API do seu banco/gateway de pagamento
    $payment_confirmed = rand(1, 10) > 7; // 30% de chance de estar pago (para demonstração)

    if ($payment_confirmed && !$order['pix_paid']) {
        // Atualizar status do pagamento
        $update_query = "UPDATE orders SET pix_paid = 1, status = 'confirmed' WHERE id = :order_id";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->bindParam(':order_id', $order_id);
        $update_stmt->execute();

        echo json_encode([
            'paid' => true,
            'status' => 'confirmed',
            'message' => 'Pagamento confirmado! Seu pedido foi enviado para a cozinha.'
        ]);
    } else {
        echo json_encode([
            'paid' => $order['pix_paid'] == 1,
            'status' => $order['status'],
            'message' => $order['pix_paid'] ? 'Pagamento já confirmado' : 'Aguardando pagamento...'
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
