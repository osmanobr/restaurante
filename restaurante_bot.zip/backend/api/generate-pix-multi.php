<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../utils/pix-generator-multi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['amount']) || !isset($input['order_id']) || !isset($input['establishment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Amount, order_id and establishment_id are required']);
    exit;
}

$amount = floatval($input['amount']);
$order_id = $input['order_id'];
$establishment_id = $input['establishment_id'];

if ($amount <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid amount']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Buscar dados do estabelecimento
    $query = "SELECT * FROM establishments WHERE id = :establishment_id AND active = 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->execute();
    $establishment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$establishment) {
        http_response_code(404);
        echo json_encode(['error' => 'Establishment not found']);
        exit;
    }

    $pix_generator = new PixGeneratorMulti($establishment);
    $pix_code = $pix_generator->generatePixCode($amount, $order_id);

    echo json_encode([
        'success' => true,
        'pix_code' => $pix_code,
        'amount' => $amount,
        'order_id' => $order_id,
        'establishment' => $establishment['name']
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error generating PIX code: ' . $e->getMessage()]);
}
?>
