<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Buscar todos os clientes
    $query = "SELECT id, phone, name, address, created_at FROM customers ORDER BY created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();

    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Formatar dados para retorno
    $formatted_customers = array_map(function($customer) {
        return [
            'id' => $customer['id'],
            'phone' => $customer['phone'],
            'name' => $customer['name'],
            'address' => $customer['address'],
            'member_since' => date('d/m/Y', strtotime($customer['created_at']))
        ];
    }, $customers);

    echo json_encode([
        'success' => true,
        'customers' => $formatted_customers,
        'total' => count($formatted_customers)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
