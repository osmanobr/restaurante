<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, Session-ID');

session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    echo json_encode([
        'success' => true,
        'is_logged_in' => true,
        'admin_id' => $_SESSION['admin_id'],
        'admin_username' => $_SESSION['admin_username'],
        'admin_establishment_id' => $_SESSION['admin_establishment_id']
    ]);
} else {
    echo json_encode([
        'success' => true,
        'is_logged_in' => false
    ]);
}
?>
