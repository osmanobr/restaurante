<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Incluir arquivos de configuração e classes necessárias
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/auth.php'; // Para hash de senha

// Obter conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

// Verificar se a requisição é POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obter os dados enviados
    $data = json_decode(file_get_contents("php://input"));

    // Validar os dados
    if (
        !empty($data->username) &&
        !empty($data->email) &&
        !empty($data->password)
    ) {
        $username = htmlspecialchars(strip_tags($data->username));
        $email = htmlspecialchars(strip_tags($data->email));
        $password = htmlspecialchars(strip_tags($data->password));

        // Hash da senha
        $password_hash = Auth::hashPassword($password);

        // Preparar a query de inserção
        $query = "INSERT INTO admins (username, email, password_hash) VALUES (:username, :email, :password_hash)";
        $stmt = $db->prepare($query);

        // Bind dos parâmetros
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password_hash', $password_hash);

        // Executar a query
        try {
            if ($stmt->execute()) {
                http_response_code(201); // Created
                echo json_encode(array("message" => "Administrador criado com sucesso."));
            } else {
                http_response_code(500); // Internal Server Error
                echo json_encode(array("message" => "Não foi possível criar o administrador."));
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) { // Código de erro para entrada duplicada (UNIQUE constraint)
                http_response_code(409); // Conflict
                echo json_encode(array("message" => "Nome de usuário ou email já existem."));
            } else {
                http_response_code(500); // Internal Server Error
                echo json_encode(array("message" => "Erro no banco de dados: " . $e->getMessage()));
            }
        }
    } else {
        http_response_code(400); // Bad Request
        echo json_encode(array("message" => "Dados incompletos. Por favor, forneça username, email e password."));
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(array("message" => "Método não permitido."));
}
?>
