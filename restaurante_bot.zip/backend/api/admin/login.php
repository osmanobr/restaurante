<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Session-ID'); // Adicionado Session-ID

require_once '../../config/database.php';
require_once '../../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['username']) || !isset($input['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password are required']);
    exit;
}

$username = $input['username'];
$password = $input['password'];

try {
    $database = new Database();
    $auth = new Auth($database);

    $admin_user = $auth->loginAdmin($username, $password);

    if ($admin_user) {
        // Start a new session or resume existing one
        session_start();
        session_regenerate_id(true); // Regenerate session ID for security

        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $admin_user['id'];
        $_SESSION['admin_username'] = $admin_user['username'];
        $_SESSION['admin_establishment_id'] = $admin_user['establishment_id']; // Store establishment ID

        echo json_encode([
            'success' => true,
            'message' => 'Login successful',
            'admin_id' => $admin_user['id'],
            'admin_username' => $admin_user['username'],
            'admin_establishment_id' => $admin_user['establishment_id'],
            'session_id' => session_id() // Return session ID for client-side storage if needed
        ]);
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid username or password']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
?>
