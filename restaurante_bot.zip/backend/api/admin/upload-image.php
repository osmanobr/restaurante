<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/establishment.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileSize = $_FILES['image']['size'];
        $fileType = $_FILES['image']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = ['jpg', 'gif', 'png', 'jpeg'];
        if (in_array($fileExtension, $allowedfileExtensions)) {
            // Diretório de destino para uploads de produtos
            $uploadFileDir = getUploadBasePath() . 'products/';
            
            // Garante que o diretório exista
            if (!is_dir($uploadFileDir)) {
                mkdir($uploadFileDir, 0777, true); // Cria recursivamente com permissões de escrita
            }

            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $destPath = $uploadFileDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $response['success'] = true;
                // Retorna o caminho relativo para ser salvo no banco de dados
                $response['image_path'] = 'products/' . $newFileName; 
                $response['message'] = 'Imagem enviada com sucesso.';
            } else {
                $response['message'] = 'Houve um erro ao mover o arquivo para o diretório de destino.';
            }
        } else {
            $response['message'] = 'Tipo de arquivo não permitido. Apenas JPG, JPEG, PNG e GIF são aceitos.';
        }
    } else {
        $response['message'] = 'Erro no upload do arquivo: ' . $_FILES['image']['error'];
    }
} else {
    $response['message'] = 'Método de requisição inválido.';
}

echo json_encode($response);
?>
