<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id']) || !isset($input['establishment_id']) || !isset($input['product_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Group ID, Product ID and Establishment ID are required']);
    exit;
}

$id = $input['id'];
$establishment_id = $input['establishment_id'];
$product_id = $input['product_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    // Start transaction
    $db->beginTransaction();

    // Delete associated options first
    $delete_options_query = "DELETE FROM product_options WHERE group_id = :group_id";
    $delete_options_stmt = $db->prepare($delete_options_query);
    $delete_options_stmt->bindParam(':group_id', $id, PDO::PARAM_INT);
    $delete_options_stmt->execute();

    // Delete the group
    $delete_group_query = "DELETE FROM product_option_groups WHERE id = :id AND product_id = :product_id AND establishment_id = :establishment_id";
    $delete_group_stmt = $db->prepare($delete_group_query);
    $delete_group_stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $delete_group_stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $delete_group_stmt->bindParam(':establishment_id', $establishment_id);

    if ($delete_group_stmt->execute()) {
        $db->commit();
        if ($delete_group_stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Option group and its options deleted successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Option group not found or already deleted.']);
        }
    } else {
        $db->rollBack();
        throw new Exception('Failed to delete option group.');
    }

} catch (Exception $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
