<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['establishment_id', 'product_id', 'name', 'type'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$establishment_id = $input['establishment_id'];
$product_id = $input['product_id'];
$name = trim($input['name']);
$type = $input['type'];
$min_selection = isset($input['min_selection']) ? intval($input['min_selection']) : 0;
$max_selection = isset($input['max_selection']) ? intval($input['max_selection']) : 1;
$sort_order = isset($input['sort_order']) ? intval($input['sort_order']) : 0;
$active = isset($input['active']) ? (bool)$input['active'] : true;

if (!in_array($type, ['checkbox', 'radio'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid group type. Must be "checkbox" or "radio".']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify product belongs to establishment
    $check_product_query = "SELECT id FROM products WHERE id = :product_id AND establishment_id = :establishment_id";
    $check_product_stmt = $db->prepare($check_product_query);
    $check_product_stmt->bindParam(':product_id', $product_id);
    $check_product_stmt->bindParam(':establishment_id', $establishment_id);
    $check_product_stmt->execute();
    if (!$check_product_stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Product not found or does not belong to this establishment.']);
        exit;
    }

    $query = "INSERT INTO product_option_groups (establishment_id, product_id, name, type, min_selection, max_selection, sort_order, active) 
              VALUES (:establishment_id, :product_id, :name, :type, :min_selection, :max_selection, :sort_order, :active)";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':min_selection', $min_selection, PDO::PARAM_INT);
    $stmt->bindParam(':max_selection', $max_selection, PDO::PARAM_INT);
    $stmt->bindParam(':sort_order', $sort_order, PDO::PARAM_INT);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Option group added successfully.', 'group_id' => $db->lastInsertId()]);
    } else {
        throw new Exception('Failed to add option group.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
