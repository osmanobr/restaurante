<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['group_id', 'name', 'price_adjustment'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$group_id = $input['group_id'];
$name = trim($input['name']);
$price_adjustment = floatval($input['price_adjustment']);
$sort_order = isset($input['sort_order']) ? intval($input['sort_order']) : 0;
$active = isset($input['active']) ? (bool)$input['active'] : true;

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify group exists
    $check_group_query = "SELECT id FROM product_option_groups WHERE id = :group_id";
    $check_group_stmt = $db->prepare($check_group_query);
    $check_group_stmt->bindParam(':group_id', $group_id);
    $check_group_stmt->execute();
    if (!$check_group_stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Option group not found.']);
        exit;
    }

    $query = "INSERT INTO product_options (group_id, name, price_adjustment, sort_order, active) 
              VALUES (:group_id, :name, :price_adjustment, :sort_order, :active)";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':group_id', $group_id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':price_adjustment', $price_adjustment);
    $stmt->bindParam(':sort_order', $sort_order, PDO::PARAM_INT);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Option added successfully.', 'option_id' => $db->lastInsertId()]);
    } else {
        throw new Exception('Failed to add option.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
