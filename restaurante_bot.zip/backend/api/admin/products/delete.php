<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../../config/paths.php';
require_once PROJECT_ROOT . '/backend/config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id']) || !isset($input['establishment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Product ID and Establishment ID are required']);
    exit;
}

$id = $input['id'];
$establishment_id = $input['establishment_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    // Delete associated product options and option groups first
    $db->beginTransaction();

    $delete_options_query = "DELETE po FROM product_options po JOIN product_option_groups pog ON po.group_id = pog.id WHERE pog.product_id = :product_id AND pog.establishment_id = :establishment_id";
    $delete_options_stmt = $db->prepare($delete_options_query);
    $delete_options_stmt->bindParam(':product_id', $id, PDO::PARAM_INT);
    $delete_options_stmt->bindParam(':establishment_id', $establishment_id);
    $delete_options_stmt->execute();

    $delete_groups_query = "DELETE FROM product_option_groups WHERE product_id = :product_id AND establishment_id = :establishment_id";
    $delete_groups_stmt = $db->prepare($delete_groups_query);
    $delete_groups_stmt->bindParam(':product_id', $id, PDO::PARAM_INT);
    $delete_groups_stmt->bindParam(':establishment_id', $establishment_id);
    $delete_groups_stmt->execute();

    $delete_product_query = "DELETE FROM products WHERE id = :id AND establishment_id = :establishment_id";
    $delete_product_stmt = $db->prepare($delete_product_query);
    $delete_product_stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $delete_product_stmt->bindParam(':establishment_id', $establishment_id);

    if ($delete_product_stmt->execute()) {
        $db->commit();
        if ($delete_product_stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Product and its options deleted successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Product not found or already deleted.']);
        }
    } else {
        $db->rollBack();
        throw new Exception('Failed to delete product.');
    }

} catch (Exception $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
