<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../../config/paths.php';
require_once PROJECT_ROOT . '/backend/config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['establishment_id', 'category_id', 'name', 'price'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$establishment_id = $input['establishment_id'];
$category_id = $input['category_id'];
$name = trim($input['name']);
$description = isset($input['description']) ? trim($input['description']) : null;
$price = floatval($input['price']);
$image = isset($input['image']) ? trim($input['image']) : '/placeholder.svg';
$sort_order = isset($input['sort_order']) ? intval($input['sort_order']) : 0;
$active = isset($input['active']) ? (bool)$input['active'] : true;

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify category belongs to establishment
    $check_category_query = "SELECT id FROM categories WHERE id = :category_id AND establishment_id = :establishment_id";
    $check_category_stmt = $db->prepare($check_category_query);
    $check_category_stmt->bindParam(':category_id', $category_id);
    $check_category_stmt->bindParam(':establishment_id', $establishment_id);
    $check_category_stmt->execute();
    if (!$check_category_stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Category not found or does not belong to this establishment.']);
        exit;
    }

    $query = "INSERT INTO products (establishment_id, category_id, name, description, price, image, sort_order, active) 
              VALUES (:establishment_id, :category_id, :name, :description, :price, :image, :sort_order, :active)";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':image', $image);
    $stmt->bindParam(':sort_order', $sort_order, PDO::PARAM_INT);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product added successfully.', 'product_id' => $db->lastInsertId()]);
    } else {
        throw new Exception('Failed to add product.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
