<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../../config/paths.php';
require_once PROJECT_ROOT . '/backend/config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Aceita tanto JSON quanto FormData
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

file_put_contents(__DIR__ . '/debug_update.log', date('Y-m-d H:i:s') . "\nINPUT: " . print_r($input, true), FILE_APPEND);

$required_fields = ['id', 'establishment_id', 'category_id', 'name', 'price'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$id = $input['id'];
$establishment_id = $input['establishment_id'];
$category_id = $input['category_id'];
$name = trim($input['name']);
$description = isset($input['description']) ? trim($input['description']) : null;
$price = floatval($input['price']);
$image = isset($input['image']) ? trim($input['image']) : (isset($input['image_url']) ? trim($input['image_url']) : '/placeholder.svg');
$sort_order = isset($input['sort_order']) ? intval($input['sort_order']) : 0;
$active = isset($input['active']) ? (bool)$input['active'] : true;

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verify category belongs to establishment
    $check_category_query = "SELECT id FROM categories WHERE id = :category_id AND establishment_id = :establishment_id";
    $check_category_stmt = $db->prepare($check_category_query);
    $check_category_stmt->bindParam(':category_id', $category_id);
    $check_category_stmt->bindParam(':establishment_id', $establishment_id);
    $check_category_stmt->execute();
    if (!$check_category_stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Category not found or does not belong to this establishment.']);
        exit;
    }

    $query = "UPDATE products SET 
                category_id = :category_id, 
                name = :name, 
                description = :description, 
                price = :price, 
                image = :image, 
                sort_order = :sort_order, 
                active = :active,
                updated_at = CURRENT_TIMESTAMP
              WHERE id = :id AND establishment_id = :establishment_id";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':image', $image);
    $stmt->bindParam(':sort_order', $sort_order, PDO::PARAM_INT);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':establishment_id', $establishment_id);

    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            $resp = ['success' => true, 'message' => 'Product updated successfully.'];
            file_put_contents(__DIR__ . '/debug_update.log', "RESPONSE: " . print_r($resp, true) . "\n", FILE_APPEND);
            echo json_encode($resp);
        } else {
            http_response_code(404);
            $resp = ['error' => 'Product not found or no changes made.'];
            file_put_contents(__DIR__ . '/debug_update.log', "RESPONSE: " . print_r($resp, true) . "\n", FILE_APPEND);
            echo json_encode($resp);
        }
    } else {
        throw new Exception('Failed to update product.');
    }

} catch (Exception $e) {
    http_response_code(500);
    $resp = ['error' => 'Database error: ' . $e->getMessage()];
    file_put_contents(__DIR__ . '/debug_update.log', "RESPONSE: " . print_r($resp, true) . "\n", FILE_APPEND);
    echo json_encode($resp);
}
?>
