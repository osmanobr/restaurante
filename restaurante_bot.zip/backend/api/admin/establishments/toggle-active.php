<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';
require_once '../../../config/establishment.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id) || !isset($data->active)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields: id, active']);
    exit;
}

try {
    $database = new Database();
    $establishment_manager = new EstablishmentManager($database);
    
    $toggled = $establishment_manager->toggleEstablishmentActiveStatus($data->id, $data->active);
    
    if ($toggled) {
        echo json_encode(['success' => true, 'message' => 'Establishment status updated successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update establishment status']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
