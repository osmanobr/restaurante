<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';
require_once '../../../config/establishment.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id) || !isset($data->name) || !isset($data->phone) || !isset($data->address)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields: id, name, phone, address']);
    exit;
}

try {
    $database = new Database();
    $establishment_manager = new EstablishmentManager($database);
    
    $updated = $establishment_manager->updateEstablishment(
        $data->id,
        $data->name,
        $data->description ?? null,
        $data->address,
        $data->phone,
        $data->whatsapp ?? null,
        $data->email ?? null,
        $data->logo ?? null,
        $data->primary_color ?? null,
        $data->secondary_color ?? null,
        $data->delivery_fee ?? 0.0,
        $data->min_order ?? 0.0,
        $data->pix_key ?? null,
        $data->pix_name ?? null,
        $data->pix_city ?? null
    );
    
    if ($updated) {
        echo json_encode(['success' => true, 'message' => 'Establishment updated successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update establishment']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
