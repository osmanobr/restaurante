     <?php
     $file = __DIR__ . '/test_log.txt';
     file_put_contents($file, "Teste de escrita: " . date('Y-m-d H:i:s') . PHP_EOL, FILE_APPEND);
     echo "Arquivo criado? " . (file_exists($file) ? "SIM" : "NÃO");
     ?>