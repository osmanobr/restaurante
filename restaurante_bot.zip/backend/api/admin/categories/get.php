<?php
$log_file = __DIR__ . '/log_get_categories.txt';
file_put_contents($log_file, "\n==== " . date('Y-m-d H:i:s') . " ====".PHP_EOL, FILE_APPEND);
file_put_contents($log_file, "REQUEST_METHOD: " . json_encode($_SERVER['REQUEST_METHOD']) . PHP_EOL, FILE_APPEND);
file_put_contents($log_file, "_GET: " . print_r($_GET, true) . PHP_EOL, FILE_APPEND);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    file_put_contents($log_file, "Método inválido\n", FILE_APPEND);
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!isset($_GET['establishment_id']) || empty($_GET['establishment_id'])) {
    file_put_contents($log_file, "Establishment ID ausente\n", FILE_APPEND);
    http_response_code(400);
    echo json_encode(['error' => 'Establishment ID is required']);
    exit;
}

$establishment_id = $_GET['establishment_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT * FROM categories WHERE establishment_id = :establishment_id ORDER BY sort_order, name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->execute();

    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $response = [
        'success' => true,
        'categories' => $categories,
        'total' => count($categories)
    ];
    file_put_contents($log_file, "RESPONSE: " . print_r($response, true) . PHP_EOL, FILE_APPEND);
    echo json_encode($response);

} catch (Exception $e) {
    file_put_contents($log_file, "DB ERROR: " . $e->getMessage() . PHP_EOL, FILE_APPEND);
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
