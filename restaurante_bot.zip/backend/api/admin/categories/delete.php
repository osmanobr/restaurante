<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id']) || !isset($input['establishment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Category ID and Establishment ID are required']);
    exit;
}

$id = $input['id'];
$establishment_id = $input['establishment_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    // Check if there are products associated with this category
    $check_products_query = "SELECT COUNT(*) FROM products WHERE category_id = :id AND establishment_id = :establishment_id";
    $check_products_stmt = $db->prepare($check_products_query);
    $check_products_stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $check_products_stmt->bindParam(':establishment_id', $establishment_id);
    $check_products_stmt->execute();
    if ($check_products_stmt->fetchColumn() > 0) {
        http_response_code(409);
        echo json_encode(['error' => 'Cannot delete category: Products are associated with it. Please delete or reassign products first.']);
        exit;
    }

    $query = "DELETE FROM categories WHERE id = :id AND establishment_id = :establishment_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':establishment_id', $establishment_id);

    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Category deleted successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Category not found or already deleted.']);
        }
    } else {
        throw new Exception('Failed to delete category.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
