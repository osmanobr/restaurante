<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['id', 'establishment_id', 'name'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$id = $input['id'];
$establishment_id = $input['establishment_id'];
$name = trim($input['name']);
$icon = isset($input['icon']) ? trim($input['icon']) : '🍽️';
$sort_order = isset($input['sort_order']) ? intval($input['sort_order']) : 0;
$active = isset($input['active']) ? (bool)$input['active'] : true;

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "UPDATE categories SET 
                name = :name, 
                icon = :icon, 
                sort_order = :sort_order, 
                active = :active,
                updated_at = CURRENT_TIMESTAMP
              WHERE id = :id AND establishment_id = :establishment_id";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':icon', $icon);
    $stmt->bindParam(':sort_order', $sort_order, PDO::PARAM_INT);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':establishment_id', $establishment_id);

    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Category updated successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Category not found or no changes made.']);
        }
    } else {
        throw new Exception('Failed to update category.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
