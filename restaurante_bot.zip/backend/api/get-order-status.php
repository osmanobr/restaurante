<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Order ID is required']);
    exit;
}

$order_id = $_GET['order_id'];

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT o.*, c.name as customer_name, c.phone, c.address 
              FROM orders o 
              JOIN customers c ON o.customer_id = c.id 
              WHERE o.id = :order_id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':order_id', $order_id);
    $stmt->execute();

    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        http_response_code(404);
        echo json_encode(['error' => 'Order not found']);
        exit;
    }

    // Decodificar itens JSON
    $order['items'] = json_decode($order['items'], true);

    // Mapear status para mensagens amigáveis
    $status_messages = [
        'pending' => 'Aguardando confirmação',
        'confirmed' => 'Pedido confirmado',
        'preparing' => 'Preparando seu pedido',
        'ready' => 'Pedido pronto para retirada/entrega',
        'delivered' => 'Pedido entregue',
        'cancelled' => 'Pedido cancelado'
    ];

    $response = [
        'id' => $order['id'],
        'order_number' => $order['order_number'],
        'customer_name' => $order['customer_name'],
        'phone' => $order['phone'],
        'address' => $order['address'],
        'items' => $order['items'],
        'subtotal' => floatval($order['subtotal']),
        'delivery_fee' => floatval($order['delivery_fee']),
        'total' => floatval($order['total']),
        'payment_method' => $order['payment_method'],
        'delivery_method' => $order['delivery_method'],
        'status' => $order['status'],
        'status_message' => $status_messages[$order['status']] ?? 'Status desconhecido',
        'pix_paid' => $order['pix_paid'] == 1,
        'created_at' => $order['created_at'],
        'updated_at' => $order['updated_at']
    ];

    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
