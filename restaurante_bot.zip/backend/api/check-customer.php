<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['phone']) || empty($input['phone'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Phone number is required']);
    exit;
}

$phone = preg_replace('/\D/', '', $input['phone']); // Remove non-digits

if (strlen($phone) !== 11) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid phone number format']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT id, phone, name, address, created_at FROM customers WHERE phone = :phone";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':phone', $phone);
    $stmt->execute();

    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($customer) {
        echo json_encode([
            'found' => true,
            'customer' => [
                'id' => (int)$customer['id'],
                'phone' => $customer['phone'],
                'name' => $customer['name'],
                'address' => $customer['address'],
                'member_since' => date('d/m/Y', strtotime($customer['created_at']))
            ]
        ]);
    } else {
        echo json_encode([
            'found' => false,
            'message' => 'Cliente não encontrado em nossa base de dados'
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
