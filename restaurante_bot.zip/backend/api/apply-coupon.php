<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['code']) || !isset($input['establishment_id']) || !isset($input['subtotal'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Coupon code, establishment ID, and subtotal are required']);
    exit;
}

$code = trim($input['code']);
$establishment_id = $input['establishment_id'];
$subtotal = floatval($input['subtotal']);

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT * FROM coupons WHERE code = :code AND establishment_id = :establishment_id AND active = TRUE";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':code', $code);
    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->execute();

    $coupon = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$coupon) {
        http_response_code(404);
        echo json_encode(['error' => 'Cupom inválido ou não encontrado para este estabelecimento.']);
        exit;
    }

    // Verificar data de expiração
    if ($coupon['expiry_date'] && strtotime($coupon['expiry_date']) < time()) {
        http_response_code(400);
        echo json_encode(['error' => 'Cupom expirado.']);
        exit;
    }

    // Verificar usos máximos
    if ($coupon['max_uses'] !== null && $coupon['uses_count'] >= $coupon['max_uses']) {
        http_response_code(400);
        echo json_encode(['error' => 'Este cupom atingiu o limite máximo de usos.']);
        exit;
    }

    // Verificar valor mínimo do pedido
    if ($subtotal < $coupon['min_order_value']) {
        http_response_code(400);
        echo json_encode(['error' => 'Valor mínimo do pedido para este cupom é R$ ' . number_format($coupon['min_order_value'], 2, ',', '.') . '.']);
        exit;
    }

    $discount_amount = 0;
    if ($coupon['type'] === 'percentage') {
        $discount_amount = $subtotal * ($coupon['value'] / 100);
    } else { // 'fixed'
        $discount_amount = $coupon['value'];
    }

    // Garantir que o desconto não seja maior que o subtotal
    $discount_amount = min($discount_amount, $subtotal);

    echo json_encode([
        'success' => true,
        'coupon' => [
            'code' => $coupon['code'],
            'description' => $coupon['description'],
            'type' => $coupon['type'],
            'value' => floatval($coupon['value']),
            'discount_amount' => floatval($discount_amount)
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
