<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['id', 'establishment_id', 'code', 'type', 'value'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$id = $input['id'];
$establishment_id = $input['establishment_id'];
$code = strtoupper(trim($input['code']));
$description = isset($input['description']) ? trim($input['description']) : null;
$type = $input['type'];
$value = floatval($input['value']);
$min_order_value = isset($input['min_order_value']) ? floatval($input['min_order_value']) : 0.00;
$max_uses = isset($input['max_uses']) && $input['max_uses'] !== '' ? intval($input['max_uses']) : null;
$expiry_date = isset($input['expiry_date']) && $input['expiry_date'] !== '' ? $input['expiry_date'] : null;
$active = isset($input['active']) ? (bool)$input['active'] : true;

if (!in_array($type, ['percentage', 'fixed'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid coupon type. Must be "percentage" or "fixed".']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Check if coupon code already exists for another coupon (excluding current one)
    $check_query = "SELECT id FROM coupons WHERE code = :code AND establishment_id = :establishment_id AND id != :id";
    $check_stmt = $db->prepare($check_query);
    $check_stmt->bindParam(':code', $code);
    $check_stmt->bindParam(':establishment_id', $establishment_id);
    $check_stmt->bindParam(':id', $id);
    $check_stmt->execute();
    if ($check_stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Coupon code already exists for another coupon in this establishment.']);
        exit;
    }

    $query = "UPDATE coupons SET 
                code = :code, 
                description = :description, 
                type = :type, 
                value = :value, 
                min_order_value = :min_order_value, 
                max_uses = :max_uses, 
                expiry_date = :expiry_date, 
                active = :active,
                updated_at = CURRENT_TIMESTAMP
              WHERE id = :id AND establishment_id = :establishment_id";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':code', $code);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':value', $value);
    $stmt->bindParam(':min_order_value', $min_order_value);
    $stmt->bindParam(':max_uses', $max_uses, PDO::PARAM_INT);
    $stmt->bindParam(':expiry_date', $expiry_date);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':establishment_id', $establishment_id);

    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Coupon updated successfully.']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Coupon not found or no changes made.']);
        }
    } else {
        throw new Exception('Failed to update coupon.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
