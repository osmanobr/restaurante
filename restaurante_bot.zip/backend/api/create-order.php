<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../utils/pix-generator.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

// Validar dados obrigatórios
$required_fields = ['customer_id', 'items', 'payment_method', 'delivery_method'];
foreach ($required_fields as $field) {
    if (!isset($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$customer_id = $input['customer_id'];
$items = $input['items'];
$payment_method = $input['payment_method'];
$delivery_method = $input['delivery_method'];

// Validar itens
if (empty($items) || !is_array($items)) {
    http_response_code(400);
    echo json_encode(['error' => 'Items cannot be empty']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verificar se o cliente existe
    $customer_query = "SELECT id, name FROM customers WHERE id = :customer_id";
    $customer_stmt = $db->prepare($customer_query);
    $customer_stmt->bindParam(':customer_id', $customer_id);
    $customer_stmt->execute();
    $customer = $customer_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$customer) {
        http_response_code(404);
        echo json_encode(['error' => 'Customer not found']);
        exit;
    }

    // Calcular totais
    $subtotal = 0;
    $validated_items = [];

    foreach ($items as $item) {
        $product_query = "SELECT id, name, price FROM products WHERE id = :product_id AND active = 1";
        $product_stmt = $db->prepare($product_query);
        $product_stmt->bindParam(':product_id', $item['product_id']);
        $product_stmt->execute();
        $product = $product_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            http_response_code(400);
            echo json_encode(['error' => 'Product not found: ' . $item['product_id']]);
            exit;
        }

        $quantity = intval($item['quantity']);
        if ($quantity <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid quantity for product: ' . $product['name']]);
            exit;
        }

        $item_total = $product['price'] * $quantity;
        $subtotal += $item_total;

        $validated_items[] = [
            'product_id' => $product['id'],
            'name' => $product['name'],
            'price' => floatval($product['price']),
            'quantity' => $quantity,
            'total' => $item_total
        ];
    }

    // Calcular taxa de entrega
    $delivery_fee = ($delivery_method === 'delivery') ? 5.00 : 0.00;
    $total = $subtotal + $delivery_fee;

    // Gerar número do pedido
    $order_number = 'PED' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

    // Gerar código PIX se necessário
    $pix_code = null;
    if ($payment_method === 'pix') {
        $pix_generator = new PixGenerator();
        $pix_code = $pix_generator->generatePixCode($total, $order_number);
    }

    // Inserir pedido
    $order_query = "INSERT INTO orders (customer_id, order_number, items, subtotal, delivery_fee, total, payment_method, delivery_method, pix_code) 
                    VALUES (:customer_id, :order_number, :items, :subtotal, :delivery_fee, :total, :payment_method, :delivery_method, :pix_code)";
    
    $order_stmt = $db->prepare($order_query);
    $order_stmt->bindParam(':customer_id', $customer_id);
    $order_stmt->bindParam(':order_number', $order_number);
    $order_stmt->bindParam(':items', json_encode($validated_items));
    $order_stmt->bindParam(':subtotal', $subtotal);
    $order_stmt->bindParam(':delivery_fee', $delivery_fee);
    $order_stmt->bindParam(':total', $total);
    $order_stmt->bindParam(':payment_method', $payment_method);
    $order_stmt->bindParam(':delivery_method', $delivery_method);
    $order_stmt->bindParam(':pix_code', $pix_code);

    if ($order_stmt->execute()) {
        $order_id = $db->lastInsertId();

        $response = [
            'success' => true,
            'order' => [
                'id' => $order_id,
                'order_number' => $order_number,
                'customer_name' => $customer['name'],
                'items' => $validated_items,
                'subtotal' => $subtotal,
                'delivery_fee' => $delivery_fee,
                'total' => $total,
                'payment_method' => $payment_method,
                'delivery_method' => $delivery_method,
                'status' => 'pending'
            ]
        ];

        if ($pix_code) {
            $response['order']['pix_code'] = $pix_code;
        }

        echo json_encode($response);
    } else {
        throw new Exception('Failed to create order');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
