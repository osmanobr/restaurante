<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['phone', 'name', 'address', 'establishment_id', 'password'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$phone = preg_replace('/\D/', '', $input['phone']);
$name = trim($input['name']);
$address = trim($input['address']);
$establishment_id = $input['establishment_id'];
$password = $input['password'];
$password_hash = Auth::hashPassword($password);

if (strlen($phone) !== 11) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid phone number format']);
    exit;
}

if (strlen($name) < 2 || strlen($name) > 100) {
    http_response_code(400);
    echo json_encode(['error' => 'Name must be between 2 and 100 characters']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Verificar se o telefone já existe para este estabelecimento
    $check_query = "SELECT id FROM customers WHERE phone = :phone AND establishment_id = :establishment_id";
    $check_stmt = $db->prepare($check_query);
    $check_stmt->bindParam(':phone', $phone);
    $check_stmt->bindParam(':establishment_id', $establishment_id);
    $check_stmt->execute();

    if ($check_stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Phone number already registered for this establishment']);
        exit;
    }

    // Inserir novo cliente
    $insert_query = "INSERT INTO customers (phone, name, address, establishment_id, password_hash) VALUES (:phone, :name, :address, :establishment_id, :password_hash)";
    $insert_stmt = $db->prepare($insert_query);
    $insert_stmt->bindParam(':phone', $phone);
    $insert_stmt->bindParam(':name', $name);
    $insert_stmt->bindParam(':address', $address);
    $insert_stmt->bindParam(':establishment_id', $establishment_id);
    $insert_stmt->bindParam(':password_hash', $password_hash);

    if ($insert_stmt->execute()) {
        $customer_id = $db->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'customer' => [
                'id' => $customer_id,
                'phone' => $phone,
                'name' => $name,
                'address' => $address,
                'establishment_id' => $establishment_id
            ]
        ]);
    } else {
        throw new Exception('Failed to insert customer');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
