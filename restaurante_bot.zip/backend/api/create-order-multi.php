<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';
require_once '../config/establishment.php';
require_once '../utils/pix-generator-multi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

// Modificar para aceitar `coupon_code` e aplicar desconto
$coupon_code = isset($input['coupon_code']) ? trim($input['coupon_code']) : null;
$discount_amount = 0;

// Validar dados obrigatórios
$required_fields = ['establishment_id', 'customer_id', 'items', 'payment_method', 'delivery_method'];
foreach ($required_fields as $field) {
    if (!isset($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$establishment_id = $input['establishment_id'];
$customer_id = $input['customer_id'];
$items = $input['items'];
$payment_method = $input['payment_method'];
$delivery_method = $input['delivery_method'];

// Validar itens
if (empty($items) || !is_array($items)) {
    http_response_code(400);
    echo json_encode(['error' => 'Items cannot be empty']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    $establishment_manager = new EstablishmentManager($database);

    // Verificar se o estabelecimento existe
    $establishment_query = "SELECT * FROM establishments WHERE id = :establishment_id AND active = 1";
    $establishment_stmt = $db->prepare($establishment_query);
    $establishment_stmt->bindParam(':establishment_id', $establishment_id);
    $establishment_stmt->execute();
    $establishment = $establishment_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$establishment) {
        http_response_code(404);
        echo json_encode(['error' => 'Establishment not found']);
        exit;
    }

    // Verificar se o cliente existe
    $customer_query = "SELECT id, name FROM customers WHERE id = :customer_id AND establishment_id = :establishment_id";
    $customer_stmt = $db->prepare($customer_query);
    $customer_stmt->bindParam(':customer_id', $customer_id);
    $customer_stmt->bindParam(':establishment_id', $establishment_id);
    $customer_stmt->execute();
    $customer = $customer_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$customer) {
        http_response_code(404);
        echo json_encode(['error' => 'Customer not found']);
        exit;
    }

    // Calcular totais
    $subtotal = 0;
    $validated_items = [];

    foreach ($items as $item) {
        $product = $establishment_manager->getProduct($item['product_id'], $establishment_id);

        if (!$product) {
            http_response_code(400);
            echo json_encode(['error' => 'Product not found: ' . $item['product_id']]);
            exit;
        }

        $quantity = intval($item['quantity']);
        if ($quantity <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid quantity for product: ' . $product['name']]);
            exit;
        }

        $item_base_price = $product['price'];
        $item_options_total = 0;
        $selected_options_details = [];

        if (isset($item['options']) && is_array($item['options'])) {
            foreach ($item['options'] as $option_id) {
                $option_detail = $establishment_manager->getOptionById($option_id);
                if ($option_detail) {
                    $item_options_total += $option_detail['price_adjustment'];
                    $selected_options_details[] = [
                        'id' => $option_detail['id'],
                        'name' => $option_detail['name'],
                        'price_adjustment' => $option_detail['price_adjustment'],
                        'group_name' => $option_detail['group_name'],
                        'group_type' => $option_detail['group_type']
                    ];
                }
            }
        }

        $item_total = ($item_base_price + $item_options_total) * $quantity;
        $subtotal += $item_total;

        $validated_items[] = [
            'product_id' => $product['id'],
            'name' => $product['name'],
            'base_price' => floatval($product['price']),
            'quantity' => $quantity,
            'options' => $selected_options_details, // Armazenar detalhes das opções
            'item_total' => $item_total // Total do item com opções
        ];
    }

    if ($coupon_code) {
        // Validar e aplicar cupom
        $coupon_query = "SELECT * FROM coupons WHERE code = :code AND establishment_id = :establishment_id AND active = TRUE";
        $coupon_stmt = $db->prepare($coupon_query);
        $coupon_stmt->bindParam(':code', $coupon_code);
        $coupon_stmt->bindParam(':establishment_id', $establishment_id);
        $coupon_stmt->execute();
        $coupon = $coupon_stmt->fetch(PDO::FETCH_ASSOC);

        if ($coupon) {
            // Verificar data de expiração
            if ($coupon['expiry_date'] && strtotime($coupon['expiry_date']) < time()) {
                // Cupom expirado, não aplicar
                $coupon_code = null; // Invalidar cupom para este pedido
            }
            // Verificar usos máximos
            else if ($coupon['max_uses'] !== null && $coupon['uses_count'] >= $coupon['max_uses']) {
                // Cupom sem usos disponíveis, não aplicar
                $coupon_code = null;
            }
            // Verificar valor mínimo do pedido
            else if ($subtotal < $coupon['min_order_value']) {
                // Valor mínimo não atingido, não aplicar
                $coupon_code = null;
            } else {
                if ($coupon['type'] === 'percentage') {
                    $discount_amount = $subtotal * ($coupon['value'] / 100);
                } else { // 'fixed'
                    $discount_amount = $coupon['value'];
                }
                $discount_amount = min($discount_amount, $subtotal); // Desconto não pode ser maior que o subtotal

                // Incrementar contador de usos do cupom
                $update_coupon_query = "UPDATE coupons SET uses_count = uses_count + 1 WHERE id = :coupon_id";
                $update_coupon_stmt = $db->prepare($update_coupon_query);
                $update_coupon_stmt->bindParam(':coupon_id', $coupon['id']);
                $update_coupon_stmt->execute();
            }
        } else {
            $coupon_code = null; // Cupom não encontrado ou inativo
        }
    }

    // Calcular taxa de entrega
    $delivery_fee = ($delivery_method === 'delivery') ? floatval($establishment['delivery_fee']) : 0.00;
    $total = $subtotal + $delivery_fee - $discount_amount;

    // Verificar pedido mínimo
    $min_order = floatval($establishment['min_order']);
    if ($min_order > 0 && $subtotal < $min_order) {
        http_response_code(400);
        echo json_encode(['error' => "Minimum order value is R$ " . number_format($min_order, 2, ',', '.')]);
        exit;
    }

    // Gerar número do pedido
    $order_number = 'PED' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

    // Gerar código PIX se necessário
    $pix_code = null;
    if ($payment_method === 'pix') {
        $pix_generator = new PixGeneratorMulti($establishment);
        $pix_code = $pix_generator->generatePixCode($total, $order_number);
    }

    // Inserir pedido
    $order_query = "INSERT INTO orders (establishment_id, customer_id, order_number, items, subtotal, delivery_fee, total, payment_method, delivery_method, pix_code, discount_amount, coupon_code) 
                    VALUES (:establishment_id, :customer_id, :order_number, :items, :subtotal, :delivery_fee, :total, :payment_method, :delivery_method, :pix_code, :discount_amount, :coupon_code)";
    
    $order_stmt = $db->prepare($order_query);
    $order_stmt->bindParam(':establishment_id', $establishment_id);
    $order_stmt->bindParam(':customer_id', $customer_id);
    $order_stmt->bindParam(':order_number', $order_number);
    $order_stmt->bindParam(':items', json_encode($validated_items));
    $order_stmt->bindParam(':subtotal', $subtotal);
    $order_stmt->bindParam(':delivery_fee', $delivery_fee);
    $order_stmt->bindParam(':total', $total);
    $order_stmt->bindParam(':payment_method', $payment_method);
    $order_stmt->bindParam(':delivery_method', $delivery_method);
    $order_stmt->bindParam(':pix_code', $pix_code);
    $order_stmt->bindParam(':discount_amount', $discount_amount);
    $order_stmt->bindParam(':coupon_code', $coupon_code);

    if ($order_stmt->execute()) {
        $order_id = $db->lastInsertId();

        $response = [
            'success' => true,
            'order' => [
                'id' => $order_id,
                'order_number' => $order_number,
                'customer_name' => $customer['name'],
                'establishment_name' => $establishment['name'],
                'items' => $validated_items,
                'subtotal' => $subtotal,
                'delivery_fee' => $delivery_fee,
                'total' => $total,
                'payment_method' => $payment_method,
                'delivery_method' => $delivery_method,
                'status' => 'pending',
                'discount_amount' => $discount_amount,
                'coupon_code' => $coupon_code,
            ]
        ];

        if ($pix_code) {
            $response['order']['pix_code'] = $pix_code;
        }

        echo json_encode($response);
    } else {
        throw new Exception('Failed to create order');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
