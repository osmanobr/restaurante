<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$required_fields = ['establishment_id', 'code', 'type', 'value'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => "Field '$field' is required"]);
        exit;
    }
}

$establishment_id = $input['establishment_id'];
$code = strtoupper(trim($input['code']));
$description = isset($input['description']) ? trim($input['description']) : null;
$type = $input['type'];
$value = floatval($input['value']);
$min_order_value = isset($input['min_order_value']) ? floatval($input['min_order_value']) : 0.00;
$max_uses = isset($input['max_uses']) && $input['max_uses'] !== '' ? intval($input['max_uses']) : null;
$expiry_date = isset($input['expiry_date']) && $input['expiry_date'] !== '' ? $input['expiry_date'] : null;
$active = isset($input['active']) ? (bool)$input['active'] : true;

if (!in_array($type, ['percentage', 'fixed'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid coupon type. Must be "percentage" or "fixed".']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();

    // Check if coupon code already exists for this establishment
    $check_query = "SELECT id FROM coupons WHERE code = :code AND establishment_id = :establishment_id";
    $check_stmt = $db->prepare($check_query);
    $check_stmt->bindParam(':code', $code);
    $check_stmt->bindParam(':establishment_id', $establishment_id);
    $check_stmt->execute();
    if ($check_stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Coupon code already exists for this establishment.']);
        exit;
    }

    $query = "INSERT INTO coupons (establishment_id, code, description, type, value, min_order_value, max_uses, expiry_date, active) 
              VALUES (:establishment_id, :code, :description, :type, :value, :min_order_value, :max_uses, :expiry_date, :active)";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':establishment_id', $establishment_id);
    $stmt->bindParam(':code', $code);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':type', $type);
    $stmt->bindParam(':value', $value);
    $stmt->bindParam(':min_order_value', $min_order_value);
    $stmt->bindParam(':max_uses', $max_uses, PDO::PARAM_INT);
    $stmt->bindParam(':expiry_date', $expiry_date);
    $stmt->bindParam(':active', $active, PDO::PARAM_BOOL);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Coupon added successfully.']);
    } else {
        throw new Exception('Failed to add coupon.');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
