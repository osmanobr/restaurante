-- Usar o banco de dados existente
USE restaurant_bot_multi;

-- Tabela de grupos de opções de produtos
CREATE TABLE product_option_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    product_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    type ENUM('checkbox', 'radio') NOT NULL COMMENT 'checkbox para múltiplas seleções, radio para uma única',
    min_selection INT DEFAULT 0,
    max_selection INT DEFAULT 1,
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Tabela de opções de produtos
CREATE TABLE product_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    price_adjustment DECIMAL(10,2) DEFAULT 0.00,
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES product_option_groups(id) ON DELETE CASCADE
);

-- Inserir dados de exemplo para opções de personalização
-- Para Burger Clássico (product_id = 1, establishment_id = 1)
-- Grupo: Adicionais (checkbox)
INSERT INTO product_option_groups (establishment_id, product_id, name, type, min_selection, max_selection, sort_order) VALUES
(1, 1, 'Adicionais', 'checkbox', 0, 5, 1);

-- Opções para Adicionais (Grupo ID 1)
INSERT INTO product_options (group_id, name, price_adjustment, sort_order) VALUES
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Adicionais'), 'Bacon Extra', 4.00, 1),
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Adicionais'), 'Queijo Cheddar', 3.50, 2),
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Adicionais'), 'Cebola Caramelizada', 2.50, 3),
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Adicionais'), 'Molho Especial', 1.50, 4);

-- Grupo: Ponto da Carne (radio)
INSERT INTO product_option_groups (establishment_id, product_id, name, type, min_selection, max_selection, sort_order) VALUES
(1, 1, 'Ponto da Carne', 'radio', 1, 1, 2);

-- Opções para Ponto da Carne (Grupo ID 2)
INSERT INTO product_options (group_id, name, price_adjustment, sort_order) VALUES
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Ponto da Carne'), 'Mal Passado', 0.00, 1),
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Ponto da Carne'), 'Ao Ponto', 0.00, 2),
((SELECT id FROM product_option_groups WHERE product_id = 1 AND name = 'Ponto da Carne'), 'Bem Passado', 0.00, 3);

-- Para Pizza Margherita (product_id = 4, establishment_id = 2)
-- Grupo: Borda (radio)
INSERT INTO product_option_groups (establishment_id, product_id, name, type, min_selection, max_selection, sort_order) VALUES
(2, 4, 'Escolha a Borda', 'radio', 1, 1, 1);

-- Opções para Borda (Grupo ID 3)
INSERT INTO product_options (group_id, name, price_adjustment, sort_order) VALUES
((SELECT id FROM product_option_groups WHERE product_id = 4 AND name = 'Escolha a Borda'), 'Tradicional', 0.00, 1),
((SELECT id FROM product_option_groups WHERE product_id = 4 AND name = 'Escolha a Borda'), 'Recheada com Catupiry', 8.00, 2),
((SELECT id FROM product_option_groups WHERE product_id = 4 AND name = 'Escolha a Borda'), 'Recheada com Cheddar', 9.00, 3);

-- Grupo: Adicionais (checkbox)
INSERT INTO product_option_groups (establishment_id, product_id, name, type, min_selection, max_selection, sort_order) VALUES
(2, 4, 'Adicionais', 'checkbox', 0, 3, 2);

-- Opções para Adicionais (Grupo ID 4)
INSERT INTO product_options (group_id, name, price_adjustment, sort_order) VALUES
((SELECT id FROM product_option_groups WHERE product_id = 4 AND name = 'Adicionais'), 'Azeitona Extra', 2.00, 1),
((SELECT id FROM product_option_groups WHERE product_id = 4 AND name = 'Adicionais'), 'Manjericão Fresco', 1.50, 2),
((SELECT id FROM product_option_groups WHERE product_id = 4 AND name = 'Adicionais'), 'Tomate Cereja', 2.50, 3);
