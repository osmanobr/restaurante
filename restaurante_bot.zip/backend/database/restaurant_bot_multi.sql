-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22/07/2025 às 22:12
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `restaurant_bot_multi`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `establishment_id` int(11) DEFAULT NULL,
  `role` varchar(50) DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `email`, `password_hash`, `establishment_id`, `role`, `created_at`, `updated_at`) VALUES
(1, 'superadmin', 'superadmin@example.com', '$2y$10$OkCogBbAymjTzSvTzggfD.SFbSRBwlOtmgrGEOGgliz5OnrV4NmpS', 1, 'super_admin', '2025-07-16 18:31:22', '2025-07-16 18:51:49'),
(2, 'adminpizza', 'adminpizza@example.com', '$2y$10$OkCogBbAymjTzSvTzggfD.SFbSRBwlOtmgrGEOGgliz5OnrV4NmpS', 2, 'admin', '2025-07-17 11:41:04', '2025-07-17 11:43:40'),
(3, 'adminsushi', 'adminsushi@example.com', '$2y$10$OkCogBbAymjTzSvTzggfD.SFbSRBwlOtmgrGEOGgliz5OnrV4NmpS', 3, 'admin', '2025-07-17 11:41:04', '2025-07-17 11:43:44');

-- --------------------------------------------------------

--
-- Estrutura para tabela `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(10) DEFAULT '?️',
  `sort_order` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `categories`
--

INSERT INTO `categories` (`id`, `establishment_id`, `name`, `icon`, `sort_order`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 'Hambúrguers', '🍔', 1, 1, '2025-07-16 17:20:47', NULL),
(2, 1, 'Bebidas', '🥤', 2, 1, '2025-07-16 17:20:47', NULL),
(3, 1, 'Sobremesas', '🍰', 3, 1, '2025-07-16 17:20:47', NULL),
(4, 2, 'Pizzas Tradicionais', '🍕', 1, 1, '2025-07-16 17:20:47', NULL),
(5, 2, 'Pizzas Especiais', '🍕', 2, 1, '2025-07-16 17:20:47', NULL),
(6, 2, 'Bebidas', '🥤', 3, 1, '2025-07-16 17:20:47', NULL),
(7, 2, 'Sobremesas', '🧁', 4, 1, '2025-07-16 17:20:47', NULL),
(8, 3, 'Sushis', 'https://co', 1, 1, '2025-07-16 17:20:47', '2025-07-18 13:26:24'),
(9, 3, 'Sashimis', '🐟', 2, 1, '2025-07-16 17:20:47', NULL),
(10, 3, 'Hot Rolls', '🔥', 3, 1, '2025-07-16 17:20:47', NULL),
(11, 3, 'Bebidas', '🍵', 4, 1, '2025-07-16 17:20:47', NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('percentage','fixed') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `min_order_value` decimal(10,2) DEFAULT 0.00,
  `max_uses` int(11) DEFAULT NULL,
  `uses_count` int(11) DEFAULT 0,
  `expiry_date` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `coupons`
--

INSERT INTO `coupons` (`id`, `establishment_id`, `code`, `description`, `type`, `value`, `min_order_value`, `max_uses`, `uses_count`, `expiry_date`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 'PRIMEIRACOMPRA', '10% de desconto na primeira compra', 'percentage', 10.00, 30.00, 100, 0, '2025-12-31 23:59:59', 1, '2025-07-16 17:20:48', '2025-07-16 17:20:48'),
(2, 1, 'FRETEGRATIS', 'Frete grátis para pedidos acima de R$50', 'fixed', 5.00, 50.00, NULL, 0, '2025-12-31 23:59:59', 1, '2025-07-16 17:20:48', '2025-07-16 17:20:48'),
(3, 2, 'PIZZAOFF', 'R$15 de desconto em qualquer pizza', 'fixed', 15.00, 40.00, 50, 0, '2025-11-30 23:59:59', 1, '2025-07-16 17:20:48', '2025-07-16 17:20:48'),
(4, 3, 'SUSHI20', 'Entrega grátis para pedidos acima de 100 reais', 'fixed', 8.00, 100.00, NULL, 0, NULL, 1, '2025-07-16 17:20:48', '2025-07-18 16:49:48');

-- --------------------------------------------------------

--
-- Estrutura para tabela `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `establishment_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `customers`
--

INSERT INTO `customers` (`id`, `phone`, `name`, `address`, `password_hash`, `establishment_id`, `created_at`, `updated_at`) VALUES
(1, '11999999999', 'João Silva', 'Rua das Flores, 123, Centro, São Paulo - SP', NULL, 1, '2025-07-16 17:20:48', '2025-07-16 17:20:48'),
(2, '11888888888', 'Maria Santos', 'Av. Paulista, 456, Bela Vista, São Paulo - SP', NULL, 1, '2025-07-16 17:20:48', '2025-07-16 17:20:48'),
(3, '63991219187', 'Osmanito Torres de Brito', 'Rua Augusta, 789, Consolação, São Paulo - SP', NULL, 2, '2025-07-16 17:20:48', '2025-07-18 20:47:19'),
(4, '11666666666', 'Ana Costa', 'Rua da Liberdade, 321, Liberdade, São Paulo - SP', NULL, 3, '2025-07-16 17:20:48', '2025-07-16 17:20:48');

-- --------------------------------------------------------

--
-- Estrutura para tabela `establishments`
--

CREATE TABLE `establishments` (
  `id` int(11) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `primary_color` varchar(7) DEFAULT '#007bff',
  `secondary_color` varchar(7) DEFAULT '#28a745',
  `pix_key` varchar(255) DEFAULT NULL,
  `pix_name` varchar(100) DEFAULT NULL,
  `pix_city` varchar(50) DEFAULT NULL,
  `delivery_fee` decimal(10,2) DEFAULT 5.00,
  `min_order` decimal(10,2) DEFAULT 0.00,
  `delivery_time` varchar(20) DEFAULT '30-45 min',
  `pickup_time` varchar(20) DEFAULT '15-20 min',
  `whatsapp` varchar(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `establishments`
--

INSERT INTO `establishments` (`id`, `phone`, `name`, `description`, `address`, `logo`, `primary_color`, `secondary_color`, `pix_key`, `pix_name`, `pix_city`, `delivery_fee`, `min_order`, `delivery_time`, `pickup_time`, `whatsapp`, `email`, `active`, `created_at`, `updated_at`) VALUES
(1, '11999999999', 'Burger House', 'Os melhores hambúrguers da cidade!', 'Rua das Flores, 123 - Centro, São Paulo', NULL, '#FF6B6B', '#4ECDC4', '11999999999', 'BURGER HOUSE LTDA', 'SAO PAULO', 5.00, 0.00, '30-45 min', '15-20 min', NULL, NULL, 1, '2025-07-16 17:20:47', '2025-07-16 17:20:47'),
(2, '11888888888', 'Pizza Express', 'Pizzas artesanais com ingredientes frescos', 'Av. Paulista, 456 - Bela Vista, São Paulo', NULL, '#E74C3C', '#F39C12', '11888888888', 'PIZZA EXPRESS LTDA', 'SAO PAULO', 5.00, 0.00, '30-45 min', '15-20 min', NULL, NULL, 1, '2025-07-16 17:20:47', '2025-07-16 17:20:47'),
(3, '11777777777', 'Sushi Zen', 'Culinária japonesa autêntica', 'Rua da Liberdade, 789 - Liberdade, São Paulo', 'https://comidaspelomundo.com/wp-content/uploads/2023/06/sushi-2.jpg', '#2C3E50', '#E67E22', '63991219187', 'SUSHI ZEN LTDA', 'SAO PAULO', 8.00, 20.00, '30-45 min', '15-20 min', NULL, NULL, 1, '2025-07-16 17:20:47', '2025-07-18 16:40:25');

-- --------------------------------------------------------

--
-- Estrutura para tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` int(11) NOT NULL,
  `remetente_id` int(11) NOT NULL,
  `remetente_tipo` enum('admin','cliente','entregador','estabelecimento') NOT NULL,
  `destinatario_id` int(11) NOT NULL,
  `destinatario_tipo` enum('admin','cliente','entregador','estabelecimento') NOT NULL,
  `mensagem` text NOT NULL,
  `data_envio` datetime DEFAULT current_timestamp(),
  `lida` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `mensagens`
--

INSERT INTO `mensagens` (`id`, `remetente_id`, `remetente_tipo`, `destinatario_id`, `destinatario_tipo`, `mensagem`, `data_envio`, `lida`) VALUES
(1, 3, 'admin', 4, 'cliente', 'boa tarde ana como vai', '2025-07-18 14:15:23', 0),
(2, 4, 'cliente', 3, 'admin', 'pois não pode falar', '2025-07-18 14:16:45', 1),
(3, 3, 'admin', 4, 'cliente', 'algo a respeito do pedido?', '2025-07-18 16:56:26', 0),
(4, 3, 'admin', 1, 'cliente', 'Boa tarde jão', '2025-07-22 17:10:17', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_number` varchar(20) NOT NULL,
  `items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`items`)),
  `subtotal` decimal(10,2) NOT NULL,
  `delivery_fee` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `delivery_method` varchar(20) NOT NULL,
  `status` enum('pending','confirmed','preparing','ready','delivered','cancelled') DEFAULT 'pending',
  `pix_code` text DEFAULT NULL,
  `pix_paid` tinyint(1) DEFAULT 0,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `coupon_code` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `method_type` enum('credit','debit','pix','cash','voucher') NOT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(10) DEFAULT '?',
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `establishment_id`, `method_type`, `name`, `icon`, `active`, `created_at`) VALUES
(1, 1, 'credit', 'Cartão de Crédito', '💳', 1, '2025-07-16 17:20:48'),
(2, 1, 'debit', 'Cartão de Débito', '💳', 1, '2025-07-16 17:20:48'),
(3, 1, 'pix', 'PIX', '📱', 1, '2025-07-16 17:20:48'),
(4, 1, 'cash', 'Dinheiro', '💵', 1, '2025-07-16 17:20:48'),
(5, 2, 'credit', 'Cartão de Crédito', '💳', 1, '2025-07-16 17:20:48'),
(6, 2, 'pix', 'PIX', '📱', 1, '2025-07-16 17:20:48'),
(7, 2, 'cash', 'Dinheiro', '💵', 1, '2025-07-16 17:20:48'),
(8, 2, 'voucher', 'Vale Refeição', '🎫', 1, '2025-07-16 17:20:48'),
(9, 3, 'credit', 'Cartão de Crédito', '💳', 0, '2025-07-16 17:20:48'),
(10, 3, 'debit', 'Cartão de Débito', '💳', 0, '2025-07-16 17:20:48'),
(11, 3, 'pix', 'PIX', '📱', 1, '2025-07-16 17:20:48');

-- --------------------------------------------------------

--
-- Estrutura para tabela `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `products`
--

INSERT INTO `products` (`id`, `establishment_id`, `category_id`, `name`, `description`, `price`, `image`, `sort_order`, `active`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Burger Clássico', 'Pão, carne 180g, queijo, alface, tomate, cebola', 25.90, 'https://via.placeholder.com/100x100/FF6B6B/FFFFFF?text=🍔', 1, 1, '2025-07-16 17:20:47', '2025-07-16 20:45:59'),
(2, 1, 1, 'Bacon Burger2', 'Pão, carne 180g, bacon, queijo, alface, tomate', 29.90, '', 2, 1, '2025-07-16 17:20:47', '2025-07-16 20:46:19'),
(3, 1, 1, 'Veggie Burger', 'Pão integral, hambúrguer de grão-de-bico, queijo vegano', 27.90, 'https://via.placeholder.com/100x100/45B7D1/FFFFFF?text=🌱', 3, 1, '2025-07-16 17:20:47', '2025-07-16 20:45:59'),
(4, 1, 2, 'Coca-Cola 350ml', 'Refrigerante de cola gelado', 5.90, 'https://via.placeholder.com/100x100/8E44AD/FFFFFF?text=🥤', 1, 1, '2025-07-16 17:20:47', '2025-07-16 20:45:59'),
(5, 1, 2, 'Suco de Laranja', 'Suco natural de laranja 300ml', 8.90, 'https://via.placeholder.com/100x100/F39C12/FFFFFF?text=🍊', 2, 1, '2025-07-16 17:20:47', '2025-07-16 20:45:59'),
(6, 1, 3, 'Milkshake Chocolate', 'Milkshake cremoso de chocolate', 12.90, 'https://via.placeholder.com/100x100/8B4513/FFFFFF?text=🥤', 1, 1, '2025-07-16 17:20:47', '2025-07-16 20:45:59'),
(7, 2, 4, 'Pizza Margherita', 'Molho de tomate, mussarela, manjericão, azeite', 32.90, 'https://via.placeholder.com/100x100/FF6B6B/FFFFFF?text=🍕', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(8, 2, 4, 'Pizza Pepperoni', 'Molho de tomate, mussarela, pepperoni', 36.90, 'https://via.placeholder.com/100x100/E74C3C/FFFFFF?text=🌶️', 2, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(9, 2, 5, 'Pizza Quattro Formaggi', 'Mussarela, gorgonzola, parmesão, provolone', 42.90, 'https://via.placeholder.com/100x100/F39C12/FFFFFF?text=🧀', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(10, 2, 5, 'Pizza Portuguesa', 'Presunto, ovos, cebola, azeitona, ervilha', 38.90, 'https://via.placeholder.com/100x100/27AE60/FFFFFF?text=🇵🇹', 2, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(11, 2, 6, 'Refrigerante 2L', 'Coca-Cola, Guaraná ou Fanta', 8.90, 'https://via.placeholder.com/100x100/3498DB/FFFFFF?text=🥤', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(12, 2, 7, 'Pudim da Casa', 'Pudim de leite condensado', 9.90, 'https://via.placeholder.com/100x100/F1C40F/FFFFFF?text=🍮', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(13, 3, 8, 'Combo Sushi 10 peças', 'Salmão, atum, peixe branco', 28.90, 'https://via.placeholder.com/100x100/2C3E50/FFFFFF?text=🍣', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(14, 3, 8, 'Sushi Premium 15 peças', 'Seleção especial do chef', 45.90, 'https://via.placeholder.com/100x100/E67E22/FFFFFF?text=⭐', 2, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(15, 3, 9, 'Sashimi Salmão', '8 fatias de salmão fresco', 24.90, 'https://via.placeholder.com/100x100/E74C3C/FFFFFF?text=🐟', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(16, 3, 10, 'Hot Philadelphia', 'Salmão, cream cheese, empanado', 32.90, 'https://via.placeholder.com/100x100/9B59B6/FFFFFF?text=🔥', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59'),
(17, 3, 11, 'Chá Verde', 'Chá verde tradicional japonês', 6.90, 'https://via.placeholder.com/100x100/27AE60/FFFFFF?text=🍵', 1, 1, '2025-07-16 17:20:48', '2025-07-16 20:45:59');

-- --------------------------------------------------------

--
-- Estrutura para tabela `product_options`
--

CREATE TABLE `product_options` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price_adjustment` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `product_options`
--

INSERT INTO `product_options` (`id`, `group_id`, `name`, `price_adjustment`, `sort_order`, `active`, `created_at`) VALUES
(1, 1, 'Bacon Extra', 4.00, 1, 1, '2025-07-16 17:20:48'),
(2, 1, 'Queijo Cheddar', 3.50, 2, 1, '2025-07-16 17:20:48'),
(3, 1, 'Cebola Caramelizada', 2.50, 3, 1, '2025-07-16 17:20:48'),
(4, 1, 'Molho Especial', 1.50, 4, 1, '2025-07-16 17:20:48'),
(5, 2, 'Mal Passado', 0.00, 1, 1, '2025-07-16 17:20:48'),
(6, 2, 'Ao Ponto', 0.00, 2, 1, '2025-07-16 17:20:48'),
(7, 2, 'Bem Passado', 0.00, 3, 1, '2025-07-16 17:20:48'),
(8, 3, 'Tradicional', 0.00, 1, 1, '2025-07-16 17:20:48'),
(9, 3, 'Recheada com Catupiry', 8.00, 2, 1, '2025-07-16 17:20:48'),
(10, 3, 'Recheada com Cheddar', 9.00, 3, 1, '2025-07-16 17:20:48'),
(11, 4, 'Azeitona Extra', 2.00, 1, 1, '2025-07-16 17:20:48'),
(12, 4, 'Manjericão Fresco', 1.50, 2, 1, '2025-07-16 17:20:48'),
(13, 4, 'Tomate Cereja', 2.50, 3, 1, '2025-07-16 17:20:48');

-- --------------------------------------------------------

--
-- Estrutura para tabela `product_option_groups`
--

CREATE TABLE `product_option_groups` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('checkbox','radio') NOT NULL COMMENT 'checkbox para múltiplas seleções, radio para uma única',
  `min_selection` int(11) DEFAULT 0,
  `max_selection` int(11) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `product_option_groups`
--

INSERT INTO `product_option_groups` (`id`, `establishment_id`, `product_id`, `name`, `type`, `min_selection`, `max_selection`, `sort_order`, `active`, `created_at`) VALUES
(1, 1, 1, 'Adicionais', 'checkbox', 0, 5, 1, 1, '2025-07-16 17:20:48'),
(2, 1, 1, 'Ponto da Carne', 'radio', 1, 1, 2, 1, '2025-07-16 17:20:48'),
(3, 2, 7, 'Escolha a Borda', 'radio', 1, 1, 1, 1, '2025-07-16 17:20:48'),
(4, 2, 7, 'Adicionais', 'checkbox', 0, 3, 2, 1, '2025-07-16 17:20:48');

-- --------------------------------------------------------

--
-- Estrutura para tabela `vagas`
--

CREATE TABLE `vagas` (
  `id` int(11) NOT NULL,
  `establishment_id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `tipo_vaga` varchar(50) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `quantidade` int(11) DEFAULT 1,
  `data_criacao` datetime DEFAULT current_timestamp(),
  `status` enum('ABERTA','FECHADA') DEFAULT 'ABERTA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `vagas`
--

INSERT INTO `vagas` (`id`, `establishment_id`, `titulo`, `descricao`, `tipo_vaga`, `cidade`, `quantidade`, `data_criacao`, `status`) VALUES
(1, 3, 'Cozinheiro(a)', 'Vaga aberta para cozinheiro com experiencia em comida japonesa', 'Cozinheiro', 'Araguaína', 1, '2025-07-18 14:07:39', 'FECHADA');

-- --------------------------------------------------------

--
-- Estrutura para tabela `vagas_interessados`
--

CREATE TABLE `vagas_interessados` (
  `id` int(11) NOT NULL,
  `vaga_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `data_interesse` datetime DEFAULT current_timestamp(),
  `mensagem` text DEFAULT NULL,
  `contratado` tinyint(1) DEFAULT 0,
  `data_contratacao` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `establishment_id` (`establishment_id`);

--
-- Índices de tabela `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_establishment_id` (`establishment_id`),
  ADD KEY `idx_sort_order` (`sort_order`);

--
-- Índices de tabela `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `unique_coupon_code_establishment` (`code`,`establishment_id`),
  ADD KEY `idx_coupon_establishment_id` (`establishment_id`),
  ADD KEY `idx_coupon_code` (`code`);

--
-- Índices de tabela `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_customer_establishment` (`phone`,`establishment_id`),
  ADD KEY `establishment_id` (`establishment_id`),
  ADD KEY `idx_phone` (`phone`);

--
-- Índices de tabela `establishments`
--
ALTER TABLE `establishments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD KEY `idx_active` (`active`);

--
-- Índices de tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `idx_order_establishment_id` (`establishment_id`),
  ADD KEY `idx_customer_id` (`customer_id`),
  ADD KEY `idx_order_number` (`order_number`),
  ADD KEY `idx_order_status` (`status`);

--
-- Índices de tabela `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`),
  ADD KEY `establishment_id` (`establishment_id`);

--
-- Índices de tabela `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_establishment_id` (`establishment_id`),
  ADD KEY `idx_category_id` (`category_id`),
  ADD KEY `idx_product_sort_order` (`sort_order`);

--
-- Índices de tabela `product_options`
--
ALTER TABLE `product_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_group_id` (`group_id`),
  ADD KEY `idx_po_sort_order` (`sort_order`);

--
-- Índices de tabela `product_option_groups`
--
ALTER TABLE `product_option_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pog_establishment_id` (`establishment_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_pog_sort_order` (`sort_order`);

--
-- Índices de tabela `vagas`
--
ALTER TABLE `vagas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `establishment_id` (`establishment_id`);

--
-- Índices de tabela `vagas_interessados`
--
ALTER TABLE `vagas_interessados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vaga_id` (`vaga_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `establishments`
--
ALTER TABLE `establishments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `product_options`
--
ALTER TABLE `product_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `product_option_groups`
--
ALTER TABLE `product_option_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `vagas`
--
ALTER TABLE `vagas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `vagas_interessados`
--
ALTER TABLE `vagas_interessados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `admin_users`
--
ALTER TABLE `admin_users`
  ADD CONSTRAINT `admin_users_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE SET NULL;

--
-- Restrições para tabelas `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `coupons`
--
ALTER TABLE `coupons`
  ADD CONSTRAINT `coupons_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`);

--
-- Restrições para tabelas `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`);

--
-- Restrições para tabelas `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD CONSTRAINT `payment_methods_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `product_options`
--
ALTER TABLE `product_options`
  ADD CONSTRAINT `product_options_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `product_option_groups` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `product_option_groups`
--
ALTER TABLE `product_option_groups`
  ADD CONSTRAINT `product_option_groups_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_option_groups_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `vagas`
--
ALTER TABLE `vagas`
  ADD CONSTRAINT `vagas_ibfk_1` FOREIGN KEY (`establishment_id`) REFERENCES `establishments` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `vagas_interessados`
--
ALTER TABLE `vagas_interessados`
  ADD CONSTRAINT `vagas_interessados_ibfk_1` FOREIGN KEY (`vaga_id`) REFERENCES `vagas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vagas_interessados_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
