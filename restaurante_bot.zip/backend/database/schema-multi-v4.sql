-- Usar o banco de dados existente
USE restaurant_bot_multi;

-- Tabela de cupons
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    type ENUM('percentage', 'fixed') NOT NULL, -- 'percentage' para % de desconto, 'fixed' para valor fixo
    value DECIMAL(10,2) NOT NULL, -- Valor do desconto (ex: 10.00 para 10% ou R$10)
    min_order_value DECIMAL(10,2) DEFAULT 0.00, -- Valor mínimo do pedido para aplicar o cupom
    max_uses INT DEFAULT NULL, -- Número máximo de vezes que o cupom pode ser usado (NULL para ilimitado)
    uses_count INT DEFAULT 0, -- Contador de usos atuais
    expiry_date DATETIME NULL, -- Data de expiração do cupom (NULL para nunca expirar)
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE,
    UNIQUE KEY unique_coupon_code_establishment (code, establishment_id)
);

-- Inserir alguns cupons de exemplo
INSERT INTO coupons (establishment_id, code, description, type, value, min_order_value, max_uses, expiry_date, active) VALUES
(1, 'PRIMEIRACOMPRA', '10% de desconto na primeira compra', 'percentage', 10.00, 30.00, 100, '2025-12-31 23:59:59', TRUE),
(1, 'FRETEGRATIS', 'Frete grátis para pedidos acima de R$50', 'fixed', 5.00, 50.00, NULL, '2025-12-31 23:59:59', TRUE),
(2, 'PIZZAOFF', 'R$15 de desconto em qualquer pizza', 'fixed', 15.00, 40.00, 50, '2025-11-30 23:59:59', TRUE),
(3, 'SUSHI20', '20% de desconto em sushis', 'percentage', 20.00, 60.00, NULL, NULL, TRUE);
