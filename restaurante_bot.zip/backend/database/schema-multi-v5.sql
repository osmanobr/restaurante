-- Usar o banco de dados existente
USE restaurant_bot_multi;

-- Adicionar colunas para desconto e cupom na tabela orders
-- Verifique se estas colunas já existem antes de rodar.
-- Se não existirem, adicione-as.

ALTER TABLE orders
ADD COLUMN discount_amount DECIMAL(10,2) DEFAULT 0.00 AFTER pix_paid,
ADD COLUMN coupon_code VARCHAR(50) NULL AFTER discount_amount;
