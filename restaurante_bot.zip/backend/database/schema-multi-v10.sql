CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(255) NOT NULL UNIQUE,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `establishment_id` INT NULL, -- Pode ser NULL para um admin global ou FK para um estabelecimento específico
  `role` VARCHAR(50) DEFAULT 'admin', -- Ex: 'admin', 'super_admin', 'manager'
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`establishment_id`) REFERENCES `establishments`(`id`) ON DELETE SET NULL
);
