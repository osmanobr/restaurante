-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS restaurant_bot_multi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_bot_multi;

-- Tabela de estabelecimentos
CREATE TABLE establishments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(11) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    address TEXT,
    logo VARCHAR(255),
    primary_color VARCHAR(7) DEFAULT '#007bff',
    secondary_color VARCHAR(7) DEFAULT '#28a745',
    pix_key VARCHAR(255),
    pix_name VARCHAR(100),
    pix_city VARCHAR(50),
    delivery_fee DECIMAL(10,2) DEFAULT 5.00,
    min_order DECIMAL(10,2) DEFAULT 0.00,
    delivery_time VARCHAR(20) DEFAULT '30-45 min',
    pickup_time VARCHAR(20) DEFAULT '15-20 min',
    whatsapp VARCHAR(11),
    email VARCHAR(100),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de categorias por estabelecimento
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '🍽️',
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de produtos por estabelecimento
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    category_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255),
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Tabela de métodos de pagamento por estabelecimento
CREATE TABLE payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    method_type ENUM('credit', 'debit', 'pix', 'cash', 'voucher') NOT NULL,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '💳',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de clientes (global, mas com referência ao estabelecimento)
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(11) NOT NULL,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    establishment_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id),
    UNIQUE KEY unique_customer_establishment (phone, establishment_id)
);

-- Tabela de pedidos
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    customer_id INT NOT NULL,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    items JSON NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    delivery_fee DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(20) NOT NULL,
    delivery_method VARCHAR(20) NOT NULL,
    status ENUM('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    pix_code TEXT NULL,
    pix_paid BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id),
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Tabela de vagas de emprego
CREATE TABLE IF NOT EXISTS vagas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    titulo VARCHAR(100) NOT NULL,
    descricao TEXT,
    tipo_vaga VARCHAR(50),
    cidade VARCHAR(100) NOT NULL,
    quantidade INT DEFAULT 1,
    data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('ABERTA','FECHADA') DEFAULT 'ABERTA',
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de interessados em vagas
CREATE TABLE IF NOT EXISTS vagas_interessados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vaga_id INT NOT NULL,
    customer_id INT NOT NULL,
    data_interesse DATETIME DEFAULT CURRENT_TIMESTAMP,
    mensagem TEXT,
    contratado TINYINT(1) DEFAULT 0,
    data_contratacao DATETIME DEFAULT NULL,
    FOREIGN KEY (vaga_id) REFERENCES vagas(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Tabela de mensagens tipo chat
CREATE TABLE IF NOT EXISTS mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    remetente_id INT NOT NULL,
    remetente_tipo ENUM('admin','cliente','entregador','estabelecimento') NOT NULL,
    destinatario_id INT NOT NULL,
    destinatario_tipo ENUM('admin','cliente','entregador','estabelecimento') NOT NULL,
    mensagem TEXT NOT NULL,
    data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    lida TINYINT(1) DEFAULT 0
);

-- Inserir estabelecimentos de exemplo
INSERT INTO establishments (phone, name, description, address, pix_key, pix_name, pix_city, primary_color, secondary_color) VALUES
('11999999999', 'Burger House', 'Os melhores hambúrguers da cidade!', 'Rua das Flores, 123 - Centro, São Paulo', '11999999999', 'BURGER HOUSE LTDA', 'SAO PAULO', '#FF6B6B', '#4ECDC4'),
('11888888888', 'Pizza Express', 'Pizzas artesanais com ingredientes frescos', 'Av. Paulista, 456 - Bela Vista, São Paulo', '11888888888', 'PIZZA EXPRESS LTDA', 'SAO PAULO', '#E74C3C', '#F39C12'),
('11777777777', 'Sushi Zen', 'Culinária japonesa autêntica', 'Rua da Liberdade, 789 - Liberdade, São Paulo', '11777777777', 'SUSHI ZEN LTDA', 'SAO PAULO', '#2C3E50', '#E67E22');

-- Inserir categorias para Burger House (ID 1)
INSERT INTO categories (establishment_id, name, icon, sort_order) VALUES
(1, 'Hambúrguers', '🍔', 1),
(1, 'Bebidas', '🥤', 2),
(1, 'Sobremesas', '🍰', 3);

-- Inserir categorias para Pizza Express (ID 2)
INSERT INTO categories (establishment_id, name, icon, sort_order) VALUES
(2, 'Pizzas Tradicionais', '🍕', 1),
(2, 'Pizzas Especiais', '🍕', 2),
(2, 'Bebidas', '🥤', 3),
(2, 'Sobremesas', '🧁', 4);

-- Inserir categorias para Sushi Zen (ID 3)
INSERT INTO categories (establishment_id, name, icon, sort_order) VALUES
(3, 'Sushis', '🍣', 1),
(3, 'Sashimis', '🐟', 2),
(3, 'Hot Rolls', '🔥', 3),
(3, 'Bebidas', '🍵', 4);

-- Produtos para Burger House
INSERT INTO products (establishment_id, category_id, name, description, price, image, sort_order) VALUES
-- Hambúrguers
(1, 1, 'Burger Clássico', 'Pão, carne 180g, queijo, alface, tomate, cebola', 25.90, 'https://via.placeholder.com/100x100/FF6B6B/FFFFFF?text=🍔', 1),
(1, 1, 'Bacon Burger', 'Pão, carne 180g, bacon, queijo, alface, tomate', 29.90, 'https://via.placeholder.com/100x100/4ECDC4/FFFFFF?text=🥓', 2),
(1, 1, 'Veggie Burger', 'Pão integral, hambúrguer de grão-de-bico, queijo vegano', 27.90, 'https://via.placeholder.com/100x100/45B7D1/FFFFFF?text=🌱', 3),
-- Bebidas
(1, 2, 'Coca-Cola 350ml', 'Refrigerante de cola gelado', 5.90, 'https://via.placeholder.com/100x100/8E44AD/FFFFFF?text=🥤', 1),
(1, 2, 'Suco de Laranja', 'Suco natural de laranja 300ml', 8.90, 'https://via.placeholder.com/100x100/F39C12/FFFFFF?text=🍊', 2),
-- Sobremesas
(1, 3, 'Milkshake Chocolate', 'Milkshake cremoso de chocolate', 12.90, 'https://via.placeholder.com/100x100/8B4513/FFFFFF?text=🥤', 1);

-- Produtos para Pizza Express
INSERT INTO products (establishment_id, category_id, name, description, price, image, sort_order) VALUES
-- Pizzas Tradicionais
(2, 4, 'Pizza Margherita', 'Molho de tomate, mussarela, manjericão, azeite', 32.90, 'https://via.placeholder.com/100x100/FF6B6B/FFFFFF?text=🍕', 1),
(2, 4, 'Pizza Pepperoni', 'Molho de tomate, mussarela, pepperoni', 36.90, 'https://via.placeholder.com/100x100/E74C3C/FFFFFF?text=🌶️', 2),
-- Pizzas Especiais
(2, 5, 'Pizza Quattro Formaggi', 'Mussarela, gorgonzola, parmesão, provolone', 42.90, 'https://via.placeholder.com/100x100/F39C12/FFFFFF?text=🧀', 1),
(2, 5, 'Pizza Portuguesa', 'Presunto, ovos, cebola, azeitona, ervilha', 38.90, 'https://via.placeholder.com/100x100/27AE60/FFFFFF?text=🇵🇹', 2),
-- Bebidas
(2, 6, 'Refrigerante 2L', 'Coca-Cola, Guaraná ou Fanta', 8.90, 'https://via.placeholder.com/100x100/3498DB/FFFFFF?text=🥤', 1),
-- Sobremesas
(2, 7, 'Pudim da Casa', 'Pudim de leite condensado', 9.90, 'https://via.placeholder.com/100x100/F1C40F/FFFFFF?text=🍮', 1);

-- Produtos para Sushi Zen
INSERT INTO products (establishment_id, category_id, name, description, price, image, sort_order) VALUES
-- Sushis
(3, 8, 'Combo Sushi 10 peças', 'Salmão, atum, peixe branco', 28.90, 'https://via.placeholder.com/100x100/2C3E50/FFFFFF?text=🍣', 1),
(3, 8, 'Sushi Premium 15 peças', 'Seleção especial do chef', 45.90, 'https://via.placeholder.com/100x100/E67E22/FFFFFF?text=⭐', 2),
-- Sashimis
(3, 9, 'Sashimi Salmão', '8 fatias de salmão fresco', 24.90, 'https://via.placeholder.com/100x100/E74C3C/FFFFFF?text=🐟', 1),
-- Hot Rolls
(3, 10, 'Hot Philadelphia', 'Salmão, cream cheese, empanado', 32.90, 'https://via.placeholder.com/100x100/9B59B6/FFFFFF?text=🔥', 1),
-- Bebidas
(3, 11, 'Chá Verde', 'Chá verde tradicional japonês', 6.90, 'https://via.placeholder.com/100x100/27AE60/FFFFFF?text=🍵', 1);

-- Métodos de pagamento para cada estabelecimento
INSERT INTO payment_methods (establishment_id, method_type, name, icon) VALUES
-- Burger House
(1, 'credit', 'Cartão de Crédito', '💳'),
(1, 'debit', 'Cartão de Débito', '💳'),
(1, 'pix', 'PIX', '📱'),
(1, 'cash', 'Dinheiro', '💵'),
-- Pizza Express
(2, 'credit', 'Cartão de Crédito', '💳'),
(2, 'pix', 'PIX', '📱'),
(2, 'cash', 'Dinheiro', '💵'),
(2, 'voucher', 'Vale Refeição', '🎫'),
-- Sushi Zen
(3, 'credit', 'Cartão de Crédito', '💳'),
(3, 'debit', 'Cartão de Débito', '💳'),
(3, 'pix', 'PIX', '📱');

-- Inserir alguns clientes de exemplo
INSERT INTO customers (phone, name, address, establishment_id) VALUES
('11999999999', 'João Silva', 'Rua das Flores, 123, Centro, São Paulo - SP', 1),
('11888888888', 'Maria Santos', 'Av. Paulista, 456, Bela Vista, São Paulo - SP', 1),
('11777777777', 'Pedro Oliveira', 'Rua Augusta, 789, Consolação, São Paulo - SP', 2),
('11666666666', 'Ana Costa', 'Rua da Liberdade, 321, Liberdade, São Paulo - SP', 3);
