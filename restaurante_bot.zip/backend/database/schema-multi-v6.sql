-- Usar o banco de dados existente
USE restaurant_bot_multi;

-- Adicionar índices para otimizar buscas e junções
-- Clientes
ALTER TABLE customers ADD INDEX idx_phone (phone);

-- Categorias
ALTER TABLE categories ADD INDEX idx_establishment_id (establishment_id);
ALTER TABLE categories ADD INDEX idx_sort_order (sort_order);

-- Produtos
ALTER TABLE products ADD INDEX idx_product_establishment_id (establishment_id);
ALTER TABLE products ADD INDEX idx_category_id (category_id);
ALTER TABLE products ADD INDEX idx_product_sort_order (sort_order);

-- Grupos de Opções de Produtos
ALTER TABLE product_option_groups ADD INDEX idx_pog_establishment_id (establishment_id);
ALTER TABLE product_option_groups ADD INDEX idx_product_id (product_id);
ALTER TABLE product_option_groups ADD INDEX idx_pog_sort_order (sort_order);

-- Opções de Produtos
ALTER TABLE product_options ADD INDEX idx_group_id (group_id);
ALTER TABLE product_options ADD INDEX idx_po_sort_order (sort_order);

-- Cupons
ALTER TABLE coupons ADD INDEX idx_coupon_establishment_id (establishment_id);
ALTER TABLE coupons ADD INDEX idx_coupon_code (code);

-- Pedidos
ALTER TABLE orders ADD INDEX idx_order_establishment_id (establishment_id);
ALTER TABLE orders ADD INDEX idx_customer_id (customer_id);
ALTER TABLE orders ADD INDEX idx_order_number (order_number);
ALTER TABLE orders ADD INDEX idx_order_status (status);
