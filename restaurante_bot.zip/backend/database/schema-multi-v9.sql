-- Versão 9: Script SQL completo com todas as tabelas e índices consolidados.
-- Este script é projetado para ser executado em um ambiente MySQL.

-- 1. Remover o banco de dados existente (se houver) para uma instalação limpa
DROP DATABASE IF EXISTS restaurant_bot_multi;

-- 2. Criar o banco de dados
CREATE DATABASE restaurant_bot_multi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 3. Usar o banco de dados recém-criado
USE restaurant_bot_multi;

-- 4. Definição das tabelas (em ordem de dependência de chave estrangeira)

-- Tabela de estabelecimentos
CREATE TABLE IF NOT EXISTS establishments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    whatsapp VARCHAR(20),
    email VARCHAR(255),
    logo VARCHAR(255),
    primary_color VARCHAR(7),
    secondary_color VARCHAR(7),
    delivery_fee DECIMAL(10, 2) DEFAULT 0.00,
    min_order DECIMAL(10, 2) DEFAULT 0.00,
    pix_key VARCHAR(255),
    pix_name VARCHAR(255),
    pix_city VARCHAR(255),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de categorias por estabelecimento
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    icon VARCHAR(255), -- Stores emoji or URL
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_category_per_establishment (establishment_id, name),
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de produtos por estabelecimento
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    category_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255), -- URL to product image
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Tabela de grupos de opções de produtos
CREATE TABLE IF NOT EXISTS product_option_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    establishment_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    type ENUM('radio', 'checkbox') NOT NULL, -- radio for single choice, checkbox for multiple
    min_selection INT DEFAULT 0,
    max_selection INT DEFAULT 1, -- 1 for radio, >1 for checkbox
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de opções de produtos
CREATE TABLE IF NOT EXISTS product_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    price_adjustment DECIMAL(10, 2) DEFAULT 0.00, -- Price added to product if this option is selected
    sort_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id) REFERENCES product_option_groups(id) ON DELETE CASCADE
);

-- Tabela de métodos de pagamento por estabelecimento
CREATE TABLE IF NOT EXISTS payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    method_type ENUM('credit', 'debit', 'pix', 'cash', 'voucher') NOT NULL,
    name VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '💳',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de clientes (global, mas com referência ao estabelecimento)
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    phone VARCHAR(20) NOT NULL,
    name VARCHAR(255),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_customer_per_establishment (establishment_id, phone),
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de pedidos
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    customer_id INT NOT NULL,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    items JSON NOT NULL, -- Stores product details, quantities, options, etc.
    subtotal DECIMAL(10, 2) NOT NULL,
    delivery_fee DECIMAL(10, 2) DEFAULT 0.00,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    coupon_code VARCHAR(50),
    total DECIMAL(10, 2) NOT NULL,
    payment_method ENUM('pix', 'cash', 'card') NOT NULL,
    delivery_method ENUM('delivery', 'pickup') NOT NULL,
    status ENUM('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    pix_qr_code TEXT,
    pix_transaction_id VARCHAR(255),
    pix_paid BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Tabela de cupons
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    establishment_id INT NOT NULL,
    code VARCHAR(50) NOT NULL,
    description TEXT,
    type ENUM('percentage', 'fixed') NOT NULL,
    value DECIMAL(10, 2) NOT NULL,
    min_order_value DECIMAL(10, 2) DEFAULT 0.00,
    max_uses INT, -- NULL for unlimited uses
    uses_count INT DEFAULT 0,
    expiry_date DATETIME, -- NULL for no expiry
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_coupon_per_establishment (establishment_id, code),
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE CASCADE
);

-- Tabela de usuários admin
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    establishment_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE SET NULL
);

-- 5. Adicionar índices para otimizar buscas e junções
ALTER TABLE customers ADD INDEX idx_phone (phone);
ALTER TABLE categories ADD INDEX idx_establishment_id (establishment_id);
ALTER TABLE categories ADD INDEX idx_sort_order (sort_order);
ALTER TABLE products ADD INDEX idx_product_establishment_id (establishment_id);
ALTER TABLE products ADD INDEX idx_category_id (category_id);
ALTER TABLE products ADD INDEX idx_product_sort_order (sort_order);
ALTER TABLE product_option_groups ADD INDEX idx_pog_establishment_id (establishment_id);
ALTER TABLE product_option_groups ADD INDEX idx_product_id (product_id);
ALTER TABLE product_option_groups ADD INDEX idx_pog_sort_order (sort_order);
ALTER TABLE product_options ADD INDEX idx_group_id (group_id);
ALTER TABLE product_options ADD INDEX idx_po_sort_order (sort_order);
ALTER TABLE coupons ADD INDEX idx_coupon_establishment_id (establishment_id);
ALTER TABLE coupons ADD INDEX idx_coupon_code (code);
ALTER TABLE orders ADD INDEX idx_order_establishment_id (establishment_id);
ALTER TABLE orders ADD INDEX idx_customer_id (customer_id);
ALTER TABLE orders ADD INDEX idx_order_number (order_number);
ALTER TABLE orders ADD INDEX idx_order_status (status);
ALTER TABLE establishments ADD INDEX idx_active (active);
