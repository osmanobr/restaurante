-- Usar o banco de dados existente
USE restaurant_bot_multi;

-- Adicionar a coluna 'active' à tabela 'establishments' se ela não existir
ALTER TABLE establishments
ADD COLUMN active BOOLEAN NOT NULL DEFAULT TRUE;

-- Opcional: Adicionar um índice na coluna 'active' para otimizar buscas por estabelecimentos ativos
ALTER TABLE establishments ADD INDEX idx_active (active);
