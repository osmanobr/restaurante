-- Usar o banco de dados existente
USE restaurant_bot_multi;

-- Adicionar coluna para senha hash na tabela customers
-- Antes de rodar, verifique se a tabela customers já existe.
-- Se já existir, use ALTER TABLE. Se não, crie a tabela completa.

-- Se a coluna password_hash não existir, adicione-a
ALTER TABLE customers
ADD COLUMN password_hash VARCHAR(255) NULL AFTER address;

-- Opcional: Adicionar um índice para a coluna phone se ainda não existir
ALTER TABLE customers ADD UNIQUE INDEX idx_phone_establishment (phone, establishment_id);
