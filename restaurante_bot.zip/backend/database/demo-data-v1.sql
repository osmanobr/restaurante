-- Insert a demo establishment
INSERT INTO establishments (name, description, address, phone, whatsapp, email, logo, primary_color, secondary_color, delivery_fee, min_order, pix_key, pix_name, pix_city, active) VALUES
('Restaurante Demo', 'O melhor da culinária local!', 'Rua Exemplo, 123, Centro', '5511987654321', '5511987654321', 'contato@restaurantedemo.com', '/placeholder.svg', '#FF5733', '#33FF57', 5.00, 20.00, '12345678901', 'Restaurante Demo LTDA', 'São Paulo', TRUE);

-- Insert a demo admin user
-- Password for 'adminuser' is 'adminpassword'
-- IMPORTANT: In a real application, generate this hash securely on the server.
-- Example hash for 'adminpassword' (you can generate your own using PHP's password_hash('adminpassword', PASSWORD_BCRYPT);)
INSERT INTO admin_users (username, password_hash, establishment_id) VALUES
('adminuser', '$2y$10$E.g.a.valid.bcrypt.hash.here.for.adminpassword', 1); -- Replace with a real hash!

-- Insert demo categories for Establishment 1
INSERT INTO categories (establishment_id, name, icon, sort_order, active) VALUES
(1, 'Pizzas', '🍕', 10, TRUE),
(1, 'Hambúrgueres', '🍔', 20, TRUE),
(1, 'Bebidas', '🥤', 30, TRUE),
(1, 'Sobremesas', '🍰', 40, TRUE);

-- Insert demo products for Establishment 1
INSERT INTO products (establishment_id, category_id, name, description, price, image, sort_order, active) VALUES
(1, 1, 'Pizza Calabresa', 'Deliciosa pizza de calabresa com cebola e queijo.', 45.00, '/placeholder.svg?height=100&width=100', 10, TRUE),
(1, 1, 'Pizza Margherita', 'Clássica pizza de molho de tomate, mussarela e manjericão.', 40.00, '/placeholder.svg?height=100&width=100', 20, TRUE),
(1, 2, 'X-Burger', 'Hambúrguer de carne, queijo, alface e tomate.', 25.00, '/placeholder.svg?height=100&width=100', 10, TRUE),
(1, 2, 'X-Salada', 'Hambúrguer de carne, queijo, alface, tomate e maionese.', 28.00, '/placeholder.svg?height=100&width=100', 20, TRUE),
(1, 3, 'Coca-Cola Lata', 'Refrigerante Coca-Cola 350ml.', 7.00, '/placeholder.svg?height=100&width=100', 10, TRUE),
(1, 3, 'Água Mineral', 'Água mineral sem gás 500ml.', 5.00, '/placeholder.svg?height=100&width=100', 20, TRUE),
(1, 4, 'Pudim de Leite', 'Pudim cremoso de leite condensado.', 12.00, '/placeholder.svg?height=100&width=100', 10, TRUE);

-- Insert demo product option groups
INSERT INTO product_option_groups (product_id, establishment_id, name, type, min_selection, max_selection, sort_order, active) VALUES
(3, 1, 'Ponto da Carne', 'radio', 1, 1, 10, TRUE), -- For X-Burger (product_id 3)
(3, 1, 'Adicionais', 'checkbox', 0, 3, 20, TRUE); -- For X-Burger (product_id 3)

-- Insert demo product options
INSERT INTO product_options (group_id, name, price_adjustment, sort_order, active) VALUES
(1, 'Mal Passado', 0.00, 10, TRUE), -- For 'Ponto da Carne' group (group_id 1)
(1, 'Ao Ponto', 0.00, 20, TRUE),
(1, 'Bem Passado', 0.00, 30, TRUE),
(2, 'Bacon', 5.00, 10, TRUE), -- For 'Adicionais' group (group_id 2)
(2, 'Ovo', 3.00, 20, TRUE),
(2, 'Cheddar', 4.00, 30, TRUE);

-- Insert demo coupons
INSERT INTO coupons (establishment_id, code, description, type, value, min_order_value, max_uses, uses_count, expiry_date, active) VALUES
(1, 'PRIMEIRACOMPRA', '10% de desconto na primeira compra', 'percentage', 10.00, 30.00, 100, 0, '2025-12-31 23:59:59', TRUE),
(1, 'FRETEGRATIS', 'Frete grátis para pedidos acima de R$50', 'fixed', 5.00, 50.00, NULL, 0, NULL, TRUE);

-- Insert demo customers
INSERT INTO customers (establishment_id, phone, name, address) VALUES
(1, '5511999998888', 'João Silva', 'Rua das Flores, 100, Apto 10, Centro'),
(1, '5511977776666', 'Maria Souza', 'Av. Principal, 500, Casa 2, Bairro Novo');

-- Insert demo orders
INSERT INTO orders (establishment_id, customer_id, order_number, items, subtotal, delivery_fee, discount_amount, total, payment_method, delivery_method, status, pix_paid) VALUES
(1, 1, 'ORD001', '[{"id":3,"name":"X-Burger","quantity":1,"price":25.00,"item_total":25.00,"options":[{"id":1,"name":"Mal Passado","group_id":1,"group_name":"Ponto da Carne","price_adjustment":0.00}]}]', 25.00, 5.00, 0.00, 30.00, 'pix', 'delivery', 'pending', FALSE),
(1, 2, 'ORD002', '[{"id":5,"name":"Coca-Cola Lata","quantity":2,"price":7.00,"item_total":14.00}]', 14.00, 0.00, 0.00, 14.00, 'cash', 'pickup', 'confirmed', FALSE);
