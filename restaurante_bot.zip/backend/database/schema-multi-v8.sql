CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    establishment_id INT, -- Nullable if a user can manage multiple or all establishments
    role VARCHAR(50) DEFAULT 'admin', -- e.g., 'admin', 'manager', 'super_admin'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (establishment_id) REFERENCES establishments(id) ON DELETE SET NULL
);

-- Adicionar um usuário admin de exemplo (senha: admin123)
-- Lembre-se de mudar esta senha em produção!
INSERT INTO admin_users (username, password_hash, establishment_id, role) VALUES
('admin', '$2y$10$2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/2/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y/y
