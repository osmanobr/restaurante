-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS restaurant_bot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_bot;

-- Tabela de clientes
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(11) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de pedidos
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    items JSON NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    delivery_fee DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(20) NOT NULL,
    delivery_method VARCHAR(20) NOT NULL,
    status ENUM('pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled') DEFAULT 'pending',
    pix_code TEXT NULL,
    pix_paid BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- Tabela de produtos (para controle de estoque)
CREATE TABLE products (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    image VARCHAR(255),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir produtos de exemplo
INSERT INTO products (id, name, description, price, category, image) VALUES
('classic-burger', 'Hambúrguer Clássico', 'Pão, carne 180g, queijo, alface, tomate, cebola', 25.90, 'burgers', 'https://via.placeholder.com/100x100/FF6B6B/FFFFFF?text=🍔'),
('bacon-burger', 'Bacon Burger', 'Pão, carne 180g, bacon, queijo, alface, tomate', 29.90, 'burgers', 'https://via.placeholder.com/100x100/4ECDC4/FFFFFF?text=🥓'),
('veggie-burger', 'Veggie Burger', 'Pão integral, hambúrguer de grão-de-bico, queijo vegano', 27.90, 'burgers', 'https://via.placeholder.com/100x100/45B7D1/FFFFFF?text=🌱'),
('margherita', 'Pizza Margherita', 'Molho de tomate, mussarela, manjericão, azeite', 32.90, 'pizzas', 'https://via.placeholder.com/100x100/FF6B6B/FFFFFF?text=🍕'),
('pepperoni', 'Pizza Pepperoni', 'Molho de tomate, mussarela, pepperoni', 36.90, 'pizzas', 'https://via.placeholder.com/100x100/E74C3C/FFFFFF?text=🌶️'),
('quattro-formaggi', 'Quattro Formaggi', 'Mussarela, gorgonzola, parmesão, provolone', 38.90, 'pizzas', 'https://via.placeholder.com/100x100/F39C12/FFFFFF?text=🧀'),
('coca-cola', 'Coca-Cola 350ml', 'Refrigerante de cola gelado', 5.90, 'drinks', 'https://via.placeholder.com/100x100/8E44AD/FFFFFF?text=🥤'),
('orange-juice', 'Suco de Laranja', 'Suco natural de laranja 300ml', 8.90, 'drinks', 'https://via.placeholder.com/100x100/F39C12/FFFFFF?text=🍊'),
('water', 'Água Mineral', 'Água mineral sem gás 500ml', 3.90, 'drinks', 'https://via.placeholder.com/100x100/3498DB/FFFFFF?text=💧'),
('chocolate-cake', 'Bolo de Chocolate', 'Fatia de bolo de chocolate com cobertura', 12.90, 'desserts', 'https://via.placeholder.com/100x100/8B4513/FFFFFF?text=🍰'),
('ice-cream', 'Sorvete 2 Bolas', 'Escolha 2 sabores: chocolate, baunilha, morango', 9.90, 'desserts', 'https://via.placeholder.com/100x100/FF69B4/FFFFFF?text=🍨');

-- Inserir alguns clientes de exemplo
INSERT INTO customers (phone, name, address) VALUES
('11999999999', 'João Silva', 'Rua das Flores, 123, Centro, São Paulo - SP, CEP: 01234-567'),
('11888888888', 'Maria Santos', 'Av. Paulista, 456, Bela Vista, São Paulo - SP, CEP: 01310-100'),
('11777777777', 'Pedro Oliveira', 'Rua Augusta, 789, Consolação, São Paulo - SP, CEP: 01305-000');
